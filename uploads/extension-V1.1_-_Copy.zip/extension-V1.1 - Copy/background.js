// background.js

import {
  enhancePromptRequest,
  promptAnalysis,
  validateCredits,
  deductCredits,
  savePromptToHistory,
  saveResponseToHistory,
  fetchUserOnboardingData,
  streamEnhancePrompt,
  addContext
} from "./api.js";
// import { checkAuthState } from "./services.js";

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: "https://thinkvelocity.in/register" });
  }
  chrome.storage.local.get("enabled", ({ enabled }) => {
    if (enabled === undefined) {
      chrome.storage.local.set({ enabled: true }); // Default to enabled
    }
  });
});

chrome.runtime.setUninstallURL("https://thinkvelocity.in/reviews", () => {
  if (chrome.runtime.lastError) {
    // console.error("Error setting uninstall URL:", chrome.runtime.lastError);
  }
});
// console.log("Background script loaded!");

// Enhance Prompt API call
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "enhancePrompt") {
    validateCredits(message)
      .then((creditValidation) => {
        if (creditValidation.success) {
          fetchUserOnboardingData()
            .then((onboardingData) => {
              if (onboardingData.success) {
                const role =
                  onboardingData.data.fetchedOnboardingData?.occupation ||
                  "user";
                enhancePromptRequest(message, role)
                  .then((data) => {
                    // console.log(
                    //   "API response from enhancePromptRequest:",
                    //   data
                    // );
                    if (data.success) {
                      deductCredits(creditValidation.requiredCredits)
                        .then(async () => {
                          try {
                            const promptData = await savePromptToHistory(
                              message
                            );
                            const originalPromptId = promptData.data.history_id;
                            await saveResponseToHistory(
                              data.data.enhanced_prompt,
                              originalPromptId,
                              message
                            );
                            sendResponse({
                              success: true,
                              data,
                              platform: message.platform,
                            });
                          } catch (error) {
                            // console.error(
                            //   "Error saving prompt/response to history:",
                            //   error
                            // );
                            sendResponse({
                              success: false,
                              error: error.message,
                            });
                          }
                        })
                        .catch((error) => {
                          // console.error("Error deducting credits:", error);
                          sendResponse({
                            success: false,
                            error: error.message,
                          });
                        });
                    } else {
                      sendResponse({ success: false, error: data.error });
                    }
                  })
                  .catch((error) => {
                    // console.error("API Error in background:", error);
                    sendResponse({ success: false, error: error.message });
                  });
              } else {
                sendResponse({ success: false, error: onboardingData.error });
              }
            })
            .catch((error) => {
              // console.error("User onboarding data error:", error);
              sendResponse({ success: false, error: error.message });
            });
        } else {
          sendResponse({ success: false, error: "Insufficient credits" });
        }
      })
      .catch((error) => {
        // console.error("Credit validation error:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Indicates asynchronous response
  }

  if (message.action === "addContext") {
    addContext(message)
      .then((data) => {
        // console.log("API response from addContext:", data);
        sendResponse({ success: true, data });
      })
      .catch((error) => {
        // console.error("API Error in addContext:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Indicates asynchronous response
  }

  if (message.action === "promptAnalysis") {
    promptAnalysis(message)
      .then((data) => {
        // console.log("API response from AnalysisPromptRequest:", data);
        // console.log("analysisResponse in background.js:", data); // Added log to verify the response
        sendResponse({ success: true, data });
      })
      .catch((error) => {
        // console.error("API Error in background:", error);
        sendResponse({ success: false, error: error.message });
      });

    return true; // Indicates asynchronous response
  }

  if (message.action === "streamEnhancePrompt") {
    // Add the sender's tab ID to the message
    message.sourceTabId = sender.tab?.id;
    
    validateCredits(message)
      .then((creditValidation) => {
        if (creditValidation.success) {
          fetchUserOnboardingData()
            .then((onboardingData) => {
              if (onboardingData.success) {
                const role =
                  onboardingData.data.fetchedOnboardingData?.occupation ||
                  "user";

                const port = chrome.runtime.connect({
                  name: "streamEnhancePrompt",
                });
                port.onDisconnect.addListener(() => {
                  // console.log("[BACKGROUND] Port disconnected");
                });

                // Initial response to start the process
                sendResponse({ success: true, streaming: true });

                // Save prompt to history first
                savePromptToHistory(message)
                  .then((promptData) => {
                    const originalPromptId = promptData.data.history_id;

                    // Start streaming process
                    streamEnhancePrompt(message)
                      .then((streamResult) => {
                        // Save the complete response at the end
                        if (streamResult.success) {
                          deductCredits(creditValidation.requiredCredits)
                            .then(() => {
                              // console.log("Stream result:", streamResult.data);
                              saveResponseToHistory(
                                streamResult.data,
                                originalPromptId,
                                message
                              );
                            })
                            // .catch((error) =>
                            //   // console.error(
                            //   //   "[BACKGROUND] Error deducting credits:",
                            //   //   error
                            //   // )
                            // );
                        }
                      })
                      // .catch((error) =>
                      //   // console.error("[BACKGROUND] Stream error:", error)
                      // );
                  })
                  // .catch((error) =>
                  //   // console.error("[BACKGROUND] Error saving prompt:", error)
                  // );
              } else {
                // console.error(
                //   "[BACKGROUND] Onboarding data error:",
                //   onboardingData.error
                // );
                sendResponse({ success: false, error: onboardingData.error });
              }
            })
            .catch((error) => {
              // console.error("[BACKGROUND] User onboarding data error:", error);
              sendResponse({ success: false, error: error.message });
            });
        } else {
          // console.error("[BACKGROUND] Insufficient credits for streaming");
          sendResponse({ success: false, error: "Insufficient credits" });
        }
      })
      .catch((error) => {
        // console.error("[BACKGROUND] Credit validation error:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Indicates asynchronous response
  }

  // Receive user data from content script and store it in chrome.storage.local
  if (message.action === "storeUserData") {
    chrome.storage.local.set(
      {
        token: message.token,
        userName: message.userName,
        userId: message.userId,
        userEmail: message.userEmail,
      },
      () => {
        // console.log("User data stored in chrome.storage.local:", message);
        // Inject content script into all matching tabs
        chrome.tabs.query(
          {
            url: [
              "*://chat.openai.com/*",
              "*://claude.ai/*",
              "*://gemini.google.com/*",
              "*://mistral.ai/chat/*",
              "*://deepseek.com/*",
              "*://app.leonardo.ai/image-generation/*",
              "*://runwayml.com/*"
            ],
          },
          (tabs) => {
            tabs.forEach((tab) => {
              chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ["content-script.js"],
              });
            });
          }
        );
        sendResponse({ success: true });
      }
    );
    return true;
  }
});

// Re-inject content script when the page refreshes
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (
    changeInfo.status === "complete" &&
    (/^https:\/\/chatgpt\.com/.test(tab.url) ||
      /^https:\/\/claude\.ai/.test(tab.url) ||
      /^https:\/\/thinkvelocity\.in/.test(tab.url) ||
      /^https:\/\/gemini\.google\.com/.test(tab.url) ||
      /^https:\/\/mistral\.ai\/chat/.test(tab.url) ||
      /^https:\/\/deepseek\.com/.test(tab.url) ||
      /^https:\/\/app\.leonardo\.ai\/image-generation/.test(tab.url) ||
      /^https:\/\/runwayml\.com/.test(tab.url))
  ) {
    chrome.storage.local.get(
      ["enabled", "token", "userName", "userId", "userEmail"],
      ({ enabled, token, userName, userId, userEmail }) => {
        if (enabled && token && userName && userId && userEmail) {
          chrome.scripting.executeScript({
            target: { tabId },
            files: ["promptReview.js", "promptGoodReview.js", "content.js"],
          });
        } else {
          // console.log(
          //   "Scripts not injected: User not authenticated or disabled."
          // );
        }
      }
    );
  }
});

// Listen for changes in storage and re-inject content script
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "local" && "enabled" in changes) {
    chrome.tabs.query(
      {
        url: [
          "https://chatgpt.com/*",
          "https://claude.ai/*",
          "https://gemini.google.com/*",
          "https://mistral.ai/chat/*",
          "https://deepseek.com/*",
          "https://app.leonardo.ai/image-generation/*",
          "https://runwayml.com/*"
        ],
      },
      (tabs) => {
        tabs.forEach((tab) => {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content-script.js"],
          });
        });
      }
    );
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "open_extension_popup") {
    chrome.action.openPopup();
  }
});