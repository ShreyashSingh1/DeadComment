// export async function enhancePromptRequest(message, authToken) {
  export async function fetchUserOnboardingData() {
    try {
      const storage = await chrome.storage.local.get(["userId"]);
      const userId = storage.userId;
  
      const response = await fetch(
        `https://thinkvelocity.in/api/api/users/fetchOnboardingData/${userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      // console.error("onboardingData error:", error);
      return { success: false, error: error.message };
    }
  }
  
  export async function enhancePromptRequest(message, role) {
    // console.log("Enhance Prompt Request:", message);
    try {
      const response = await fetch(
        "https://thinkvelocity.in/python-api/enhance",
        // "http://127.0.0.1:2000/enhance",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            prompt: message.prompt,
            style: message.style,
            role: role || "user",
          }),
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      // console.error("Enhance prompt error:", error);
      return { success: false, error: error.message };
    }
  }
  
  // This is a portion of the streamEnhancePrompt function in api.js
  // that has been updated to better log context suggestions
  
  export async function streamEnhancePrompt(message) {
    // console.log("[API] streamEnhancePrompt called with:", message);
    const data = {
      prompt: message.prompt,
      style: message.style,
      stream: true,
      conversation_id: null,
      is_context_addition: false,
      suggestion_index: -1,
    };
  
    // console.log("[API] Request data prepared:", data);
    // Get the source tab ID from the message
    const sourceTabId = message.sourceTabId;
  
    try {
      // console.log("[API] Sending request to enhance1 endpoint...");
      const response = await fetch("https://thinkvelocity.in/dev/enhance1", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorText = await response.text();
        // console.error("[API] HTTP error response:", errorText);
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      // console.log("[API] Stream response received, starting to read...");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedData = "";
      let contextSuggestions = [];
      let conversationId = null;
      let chunkCount = 0;
  
      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          // console.log("[API] Stream reading complete");
          break;
        }
  
        const text = decoder.decode(value);
        // console.log("[API] Raw response text:", text);
        
        // Simple string extraction approach
        if (text.includes('"enhanced_prompt": "')) {
          // console.log("[API] Found enhanced_prompt pattern in text");
  
          // Extract just the content between "enhanced_prompt": " and ", "
          const startMarker = '"enhanced_prompt": "';
          const endMarker = '", "';
  
          const startIndex = text.indexOf(startMarker) + startMarker.length;
          const endIndex = text.indexOf(endMarker, startIndex);
  
          if (startIndex >= 0 && endIndex >= 0) {
            const extractedContent = text.substring(startIndex, endIndex);
            accumulatedData = extractedContent;
  
            // Enhanced logging for context suggestions
            // console.log("[API] Looking for context_suggestions in API response");
            const suggestionsMarker = '"context_suggestions": [';
            const suggestionsEndMarker = ']';
            const suggestionsStartIndex = text.indexOf(suggestionsMarker);
            
            if (suggestionsStartIndex !== -1) {
              // console.log("[API] Found context_suggestions in response");
              const suggestionsEndIndex = text.indexOf(suggestionsEndMarker, suggestionsStartIndex);
              if (suggestionsEndIndex !== -1) {
                const suggestionsText = text.substring(
                  suggestionsStartIndex + suggestionsMarker.length,
                  suggestionsEndIndex
                );
                try {
                  contextSuggestions = JSON.parse(`[${suggestionsText}]`);
                  // console.log("[API] Successfully parsed context suggestions:", contextSuggestions);
                } catch (e) {
                  // console.error("[API] Error parsing context_suggestions:", e);
                  // console.log("[API] Raw suggestions text:", suggestionsText);
                }
              }
            } else {
              // console.log("[API] No context_suggestions found in response");
            }
  
            // Enhanced logging for conversation ID
            // console.log("[API] Looking for conversation_id in API response");
            const conversationIdMarker = '"conversation_id": "';
            const conversationIdStartIndex = text.indexOf(conversationIdMarker);
            
            if (conversationIdStartIndex !== -1) {
              // console.log("[API] Found conversation_id in response");
              const conversationIdEndIndex = text.indexOf('"', conversationIdStartIndex + conversationIdMarker.length);
              if (conversationIdEndIndex !== -1) {
                conversationId = text.substring(
                  conversationIdStartIndex + conversationIdMarker.length,
                  conversationIdEndIndex
                );
                // console.log("[API] Successfully extracted conversation ID:", conversationId);
              }
            } else {
              // console.log("[API] No conversation_id found in response");
            }
  
            if (sourceTabId) {
              // Send directly to source tab if available
              chrome.tabs.sendMessage(
                sourceTabId,
                {
                  action: "streamChunk",
                  chunk: extractedContent,
                  isFirst: true,
                  isComplete: true,
                  contextSuggestions: contextSuggestions,
                  conversationId: conversationId,
                },
                (response) => {
                  const lastError = chrome.runtime.lastError;
                  if (lastError) {
                    // console.error("[API] Error sending to tab:", lastError);
                  }
                }
              );
            } else {
              // Fall back to active tab
              chrome.tabs.query(
                { active: true, currentWindow: true },
                function (tabs) {
                  if (!tabs || tabs.length === 0) {
                    // console.error("[API] No active tabs found to send content to");
                    return;
                  }
  
                  // console.log(
                  //   "[API] Sending extracted content to tab with context suggestions:",
                  //   contextSuggestions.length > 0 ? "Yes" : "No",
                  //   "and conversation ID:",
                  //   conversationId ? "Yes" : "No"
                  // );
                  
                  chrome.tabs.sendMessage(
                    tabs[0].id,
                    {
                      action: "streamChunk",
                      chunk: extractedContent,
                      isFirst: true,
                      isComplete: true,
                      contextSuggestions: contextSuggestions,
                      conversationId: conversationId,
                    },
                    (response) => {
                      const lastError = chrome.runtime.lastError;
                      if (lastError) {
                        // console.error("[API] Error sending to tab:", lastError);
                      }
                    }
                  );
                }
              );
            }
  
            break;
          }
        } else {
          const lines = text.split("\n");
          // console.log(`[API] Parsed ${lines.length} lines from chunk`);
  
          for (const line of lines) {
            if (!line.trim()) continue;
            try {
              const parsedData = JSON.parse(line);
              // console.log(`[API] Parsed JSON data from line:`, parsedData);
  
              // Handle streaming chunks
              if (parsedData.chunk) {
                chunkCount++;
                // console.log(`[API] Processing chunk #${chunkCount}`);
                // console.log("Stream chunk:", parsedData.chunk);
  
                if (sourceTabId) {
                  // Send directly to source tab if available
                  chrome.tabs.sendMessage(
                    sourceTabId,
                    {
                      action: "streamChunk",
                      chunk: parsedData.chunk,
                      isFirst: parsedData.is_first || false,
                      isComplete: parsedData.complete || false,
                      contextSuggestions: parsedData.context_suggestions || contextSuggestions,
                      conversationId: parsedData.conversation_id || conversationId
                    },
                    (response) => {
                      const lastError = chrome.runtime.lastError;
                      if (lastError) {
                        // console.error("[API] Error sending chunk to tab:", lastError);
                      }
                    }
                  );
                } else {
                  // Fall back to active tab
                  chrome.tabs.query(
                    { active: true, currentWindow: true },
                    function (tabs) {
                      if (!tabs || tabs.length === 0) {
                        // console.error("[API] No active tabs found to send chunk to");
                        return;
                      }
  
                      chrome.tabs.sendMessage(
                        tabs[0].id,
                        {
                          action: "streamChunk",
                          chunk: parsedData.chunk,
                          isFirst: parsedData.is_first || false,
                          isComplete: parsedData.complete || false,
                          contextSuggestions: parsedData.context_suggestions || contextSuggestions,
                          conversationId: parsedData.conversation_id || conversationId
                        },
                        (response) => {
                          const lastError = chrome.runtime.lastError;
                          if (lastError) {
                            // console.error("[API] Error sending chunk to tab:", lastError);
                          }
                        }
                      );
                    }
                  );
                }
  
                // Accumulate for final return
                if (parsedData.is_first) {
                  accumulatedData = parsedData.chunk;
                } else {
                  accumulatedData += parsedData.chunk;
                }
  
                // Check for context suggestions in streaming response
                if (parsedData.context_suggestions) {
                  // console.log("[API] Found context suggestions in streaming chunk:", parsedData.context_suggestions);
                  contextSuggestions = parsedData.context_suggestions;
                }
  
                // Check for conversation ID in streaming response
                if (parsedData.conversation_id) {
                  // console.log("[API] Found conversation ID in streaming chunk:", parsedData.conversation_id);
                  conversationId = parsedData.conversation_id;
                }
  
                // If this is the complete chunk, send the context suggestions and conversation ID
                if (parsedData.complete) {
                  // console.log("[API] Complete chunk received, sending context data to tab");
                  
                  if (sourceTabId) {
                    // Send directly to source tab if available
                    chrome.tabs.sendMessage(
                      sourceTabId,
                      {
                        action: "streamChunk",
                        chunk: parsedData.chunk,
                        isFirst: false,
                        isComplete: true,
                        contextSuggestions: contextSuggestions,
                        conversationId: conversationId,
                      },
                      (response) => {
                        const lastError = chrome.runtime.lastError;
                        if (lastError) {
                          // console.error("[API] Error sending context data to tab:", lastError);
                        }
                      }
                    );
                  } else {
                    // Fall back to active tab
                    chrome.tabs.query(
                      { active: true, currentWindow: true },
                      function (tabs) {
                        if (!tabs || tabs.length === 0) {
                          // console.error("[API] No active tabs found to send context data to");
                          return;
                        }
  
                        chrome.tabs.sendMessage(
                          tabs[0].id,
                          {
                            action: "streamChunk",
                            chunk: parsedData.chunk,
                            isFirst: false,
                            isComplete: true,
                            contextSuggestions: contextSuggestions,
                            conversationId: conversationId,
                          },
                          (response) => {
                            const lastError = chrome.runtime.lastError;
                            if (lastError) {
                              // console.error("[API] Error sending context data to tab:", lastError);
                            }
                          }
                        );
                      }
                    );
                  }
                }
              }
            } catch (error) {
              // console.error("[API] Error parsing JSON data from line:", error);
            }
          }
        }
      }
  
      // console.log("[API] Stream completed, returning accumulated data:", {
      //   length: accumulatedData.length,
      //   preview: accumulatedData.substring(0, 100) + (accumulatedData.length > 100 ? "..." : ""),
      //   contextSuggestions: contextSuggestions.length > 0 ? contextSuggestions : "None",
      //   conversationId: conversationId || "None"
      // });
      return { 
        success: true, 
        data: accumulatedData,
        contextSuggestions: contextSuggestions,
        conversationId: conversationId
      };
    } catch (error) {
      // console.error("[API] Stream enhance prompt error:", error);
      return { success: false, error: error.message };
    }
  }
  
  export async function promptAnalysis({ prompt, platform, style, sourceTabId }) {
    try {
      const response = await fetch("https://thinkvelocity.in/python-api/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt, platform, style }),
      });
      const data = await response.json();
      // console.log("Raw promptAnalysis API response:", data); // Add this log
      return { success: true, data };
    } catch (error) {
      // console.error("Error in promptAnalysis:", error);
      return { success: false, error: error.message };
    }
  }
  
  export async function validateCredits(message) {
    // console.log("🔍 validateCredits called with message:", message);
    try {
      const storage = await chrome.storage.local.get(["userId", "token"]);
      const userId = storage.userId;
      const token = storage.token;
      // console.log("👤 User authentication data:", { userId, tokenLength: token?.length });
  
      if (!userId || !token) {
        // console.error("❌ Authentication failed: Missing userId or token");
        throw new Error("User authentication required");
      }
  
      // Get feature credits first
      // console.log("📡 Fetching credits from new API endpoint...");
      const creditsResponse = await fetch(
        "https://thinkvelocity.in/post/token/fetch-credits", // Updated endpoint
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      const creditsData = await creditsResponse.json();
      // console.log("📋 Credits data received from new API:", creditsData);
      
      if (!creditsData.success) {
        // console.error("❌ Credits API error:", creditsData.message || "Failed to fetch credits");
        throw new Error(creditsData.message || "Failed to fetch credits");
      }
  
      let totalRequiredCredits = 0;
  
      // Basic prompt credits
      const basicPromptCredit = creditsData.credits.basic_prompt; // Updated to match new response structure
      // console.log("🔢 Basic prompt credit from new API:", basicPromptCredit);
      
      if (!basicPromptCredit) {
        // console.error("❌ Basic prompt feature not found in new API response");
        throw new Error("Basic prompt feature not found");
      }
      totalRequiredCredits += basicPromptCredit;
      // console.log("🧮 Total required credits (after basic):", totalRequiredCredits);
  
      // Style credits if style is selected
      if (message.style && message.style !== "") {
        const styleCredit = creditsData.credits.style_prompt;
        // console.log("🎨 Style credit from new API:", styleCredit);
        if (!styleCredit) {
          // console.error("❌ Style feature not found in new API response");
          throw new Error("Style feature not found");
        }
        totalRequiredCredits += styleCredit;
        // console.log("🧮 Total required credits (after style):", totalRequiredCredits);
      }
  
      // Platform credits if platform is selected
      if (message.platform && message.platform !== "") {
        const platformCredit = creditsData.credits.platform;
        // console.log("📱 Platform credit from new API:", platformCredit);
        if (!platformCredit) {
          // console.error("❌ Platform feature not found in new API response");
          throw new Error("Platform feature not found");
        }
        totalRequiredCredits += platformCredit;
        // console.log("🧮 Total required credits (after platform):", totalRequiredCredits);
      }
  
      // Get user's token balance
      // console.log("📡 Fetching user balance from new API endpoint...");
      const balanceResponse = await fetch(
        `https://thinkvelocity.in/post/token/fetch-tokens/${userId}`, // Updated endpoint
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      
      const balanceData = await balanceResponse.json();
      // console.log("💰 User balance data from new API:", balanceData);
      
      if (!balanceData.success) {
        // console.error("❌ Balance API error:", balanceData.message || "Failed to fetch tokens");
        throw new Error(balanceData.message || "Failed to fetch tokens");
      }
  
      const availableTokens = balanceData.tokens; // Updated to match new response structure
      // console.log("📊 Available tokens from new API:", availableTokens);
  
      if (availableTokens < totalRequiredCredits) {
        // console.error("❌ Insufficient tokens:", {
        //   available: availableTokens,
        //   required: totalRequiredCredits
        // });
        throw new Error("Insufficient tokens available");
      }
  
      // console.log("✅ Credit validation successful with new APIs");
      return {
        success: true,
        requiredCredits: totalRequiredCredits,
        availableTokens: availableTokens,
      };
    } catch (error) {
      // console.error("❌ Credit validation failed:", error);
      throw error;
    }
  }
  
  export async function deductCredits(creditsToDeduct) {
    // console.log("🔽 deductCredits called with credits to deduct:", creditsToDeduct);
    try {
      const storage = await chrome.storage.local.get(["userId", "token"]);
      const userId = storage.userId;
      const token = storage.token;
      // console.log("👤 User data for deduction:", { userId, tokenAvailable: !!token });
      
      if (!userId || !token) {
        // console.error("❌ Authentication failed in deductCredits");
        throw new Error("User authentication required");
      }
    
      // Fetch current token balance (optional, since the new endpoint doesn't require it)
      // console.log("📡 Fetching current balance before deduction from new API...");
      const balanceResponse = await fetch(
        `https://thinkvelocity.in/post/token/fetch-tokens/${userId}`, // Updated endpoint
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      
      const balanceData = await balanceResponse.json();
      // console.log("💰 Current balance data from new API:", balanceData);
      
      if (!balanceData.success) {
        // console.error("❌ Balance API error:", balanceData.message || "Failed to fetch tokens");
        throw new Error(balanceData.message || "Failed to fetch tokens");
      }
    
      // Deduct tokens using the new endpoint
      // console.log("📡 Deducting tokens with new API endpoint...");
      const requestBody = {
        user_id: userId,
        amount: creditsToDeduct
      };
      // console.log("📤 Deduction request body:", requestBody);
      
      const deductResponse = await fetch(
        "https://thinkvelocity.in/post/token/deduct-tokens", // Updated endpoint
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(requestBody),
        }
      );
    
      const deductData = await deductResponse.json();
      // console.log("✅ Deduction response from new API:", deductData);
      
      if (!deductData.success) {
        // console.error("❌ Deduction API error:", deductData.message || "Failed to deduct tokens");
        throw new Error(deductData.message || "Failed to deduct tokens");
      }
      
      // console.log("✅ Credits successfully deducted with new API");
      return { success: true, data: deductData };
    } catch (error) {
      // console.error("❌ Error in deductCredits:", error);
      throw error;
    }
  }
  
  export async function savePromptToHistory(message) {
    // console.log("📝 savePromptToHistory called with message:", message);
    try {
      const storage = await chrome.storage.local.get(["userId", "token"]);
      const userId = storage.userId;
      const token = storage.token;
      // console.log("👤 User authentication data:", { userId, tokenLength: token?.length });
  
      if (!userId || !token) {
        // console.error("❌ Authentication failed: Missing userId or token in savePromptToHistory");
        throw new Error("User authentication required");
      }
  
      // Log request details
      const requestBody = {
        user_id: userId,
        prompt: message.prompt, // Updated field name from prompt_text to prompt
        ai_type: message.platform,
        style: message.style,
        tokens_used: message.tokens_used || 0, // Add tokens_used, default to 0 if not provided
      };
      // console.log("📤 savePromptToHistory - Request body:", requestBody);
      // console.log("🔗 Using new API endpoint: https://thinkvelocity.in/post/prompt/save-prompt");
  
      const response = await fetch(
        "https://thinkvelocity.in/post/prompt/save-prompt", // Updated endpoint
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(requestBody),
        }
      );
  
      // Log response details
      const data = await response.json();
      // console.log("📥 savePromptToHistory - Response status:", response.status);
      // console.log("📥 savePromptToHistory - Response data:", data);
  
      if (!response.ok) {
        // console.error("❌ HTTP error in savePromptToHistory:", {
        //   status: response.status,
        //   message: data.message || "Unknown error"
        // });
        throw new Error(
          `HTTP error! Status: ${response.status}, Message: ${
            data.message || "Unknown error"
          }`
        );
      }
  
      if (!data.success) {
        // console.error("❌ API error in savePromptToHistory:", data.message || "Failed to save prompt: Unknown error");
        throw new Error(data.message || "Failed to save prompt: Unknown error");
      }
  
      // console.log("✅ Prompt successfully saved to history with ID:", data.prompt_id || "unknown");
      return data;
    } catch (error) {
      // console.error("❌ Error saving prompt to history:", {
      //   error: error.message,
      //   stack: error.stack,
      // });
      throw error;
    }
  }
  
  export async function saveResponseToHistory(
    enhancedPrompt,
    originalPromptId,
    message
  ) {
    // console.log("💬 saveResponseToHistory called with:", {
    //   enhancedPromptLength: enhancedPrompt?.length,
    //   originalPromptId,
    //   message
    // });
    
    try {
      const storage = await chrome.storage.local.get(["userId", "token"]);
      const userId = storage.userId;
      const token = storage.token;
      // console.log("👤 User authentication data:", { userId, tokenLength: token?.length });
  
      if (!userId || !token) {
        // console.error("❌ Authentication failed: Missing userId or token in saveResponseToHistory");
        throw new Error("User authentication required");
      }
  
      const requestBody = {
        user_id: userId,
        enhanced_prompt: enhancedPrompt, // Updated field name from prompt_text to enhanced_prompt
        input_prompt_id: originalPromptId, // Updated field name from original_prompt_id to input_prompt_id
        ai_type: message.platform,
        style: message.style,
        // tokens_used field is removed as per the new API
      };
      
      // console.log("📤 saveResponseToHistory - Request body:", {
      //   ...requestBody,
      //   enhanced_prompt: enhancedPrompt?.substring(0, 100) + (enhancedPrompt?.length > 100 ? "..." : "")
      // });
      // console.log("🔗 Using new API endpoint: https://thinkvelocity.in/post/prompt/save-response");
  
      const response = await fetch(
        "https://thinkvelocity.in/post/prompt/save-response", // Updated endpoint
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(requestBody),
        }
      );
  
      const data = await response.json();
      // console.log("📥 saveResponseToHistory - Response status:", response.status);
      // console.log("📥 saveResponseToHistory - Response data:", data);
      
      if (!response.ok) {
        // console.error("❌ HTTP error in saveResponseToHistory:", {
        //   status: response.status,
        //   message: data.message || "Unknown error"
        // });
        throw new Error(
          `HTTP error! Status: ${response.status}, Message: ${
            data.message || "Unknown error"
          }`
        );
      }
  
      if (!data.success) {
        // console.error("❌ API error in saveResponseToHistory:", data.message || "Failed to save response: Unknown error");
        throw new Error(data.message || "Failed to save response: Unknown error");
      }
  
      // console.log("✅ Response successfully saved to history with ID:", data.response_id || "unknown");
      return data;
    } catch (error) {
      // console.error("❌ Error saving response to history:", {
      //   error: error.message,
      //   stack: error.stack
      // });
      throw error;
    }
  }
  
  export async function addContext(message) {
    // console.log("[API] Add Context Request:", message);
    // console.log("[API] Context content:", message.context);
    // console.log("[API] Using conversation ID:", message.conversationId);
    // console.log("[API] Style:", message.style);
  
    try {
      // console.log("[API] Sending request to add-context endpoint...");
      const response = await fetch(
        "https://thinkvelocity.in/dev/add-context",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            context: message.context,
            conversation_id: message.conversationId,
            style: message.style
          }),
        }
      );
      
      if (!response.ok) {
        const errorText = await response.text();
        // console.error("[API] HTTP error response from add-context:", errorText);
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      
      const data = await response.json();
      // console.log("[API] Add context response received:", data);
      
      // Log specific parts of the response
      if (data.data && data.data.enhanced_prompt) {
        // console.log("[API] Enhanced prompt after adding context:", data.data.enhanced_prompt.substring(0, 100) + "...");
      }
      
      if (data.data && data.data.conversation_id) {
        // console.log("[API] Conversation ID after adding context:", data.data.conversation_id);
      }
      
      return { success: true, data };
    } catch (error) {
      // console.error("[API] Add context error:", error);
      return { success: false, error: error.message };
    }
  }