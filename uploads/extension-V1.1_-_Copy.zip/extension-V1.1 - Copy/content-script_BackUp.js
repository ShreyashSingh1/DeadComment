//Check Auth State
(function () {
  if (window.location.hostname.includes("thinkvelocity.in")) {
    console.log("User is on thinkvelocity.in");

    function sendUserData() {
      const token = localStorage.getItem("token");
      const userName = localStorage.getItem("userName");
      const userId = localStorage.getItem("userId");
      const userEmail = localStorage.getItem("userEmail");

      if (token && userName && userId && userEmail) {
        chrome.runtime.sendMessage(
          { action: "storeUserData", token, userName, userId, userEmail },
          (response) => {
            console.log("User data sent to background:", response);
            checkAuthAndInjectButton();
          }
        );
        // Enable button after login
        chrome.storage.local.set({ enabled: true });
      }

      if (!token && !userName && !userId && !userEmail) {
        console.warn(
          "User data is missing. Removing from chrome.storage.local."
        );
        chrome.storage.local.remove(
          ["token", "userName", "userId", "userEmail"],
          () => {
            console.log("User data removed from chrome.storage.local");
          }
        );
        // Disable button after logout
        chrome.storage.local.set({ enabled: false });
      }
    }
    sendUserData();
    // Modify the storage event listener to use a more reliable method
    window.addEventListener("storage", sendUserData);

    // Add a mutation observer to watch for changes in localStorage
    const documentObserver = new MutationObserver(() => {
      sendUserData();
    });
    documentObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }
})();

// Function to inject the button only if authenticated and enabled
function checkAuthAndInjectButton() {
  chrome.storage.local.get(
    ["enabled", "token", "userName", "userId", "userEmail"],
    (data) => {
      if (
        data.enabled &&
        data.token &&
        data.userName &&
        data.userId &&
        data.userEmail
      ) {
        injectButton();
      } else {
        console.log("Button not injected: Either not logged in or disabled.");
        removeButton();
      }
    }
  );
}

// Function to create the custom button
function createCustomButton() {
  // Inject rotation CSS only once
  (function injectRotationCSS() {
    if (!document.getElementById("rotation-style")) {
      const style = document.createElement("style");
      style.id = "rotation-style";
      style.innerHTML = `
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        .rotating {
          animation: spin 1s linear infinite;
        }
      `;
      document.head.appendChild(style);
    }
  })();

  const buttonContainer = document.createElement("div");
  buttonContainer.style.cssText = `
    position: relative;
    display: inline-block;
  `;
  buttonContainer.className = "custom-injected-button";

  //Determine platform
  const currentURL = window.location.href;
  const platformKey = Object.keys(window.platforms).find((key) =>
    window.platforms[key].urlPattern.test(currentURL)
  );
  const platform = platformKey || "default"; // Default in case no match
  console.log("platform", platform);
  const platformConfig = window.platforms[platformKey] || {};

  // Create button
  const button = document.createElement("button");
  button.style.cssText = `
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 9999px;
    background-color: black;
    height: 36px;
    width: 36px;
    transition: opacity 0.2s;
  `;
  button.addEventListener("mouseenter", () => {
    button.style.opacity = "0.7";
  });
  button.addEventListener("mouseleave", () => {
    button.style.opacity = "1";
  });

  const innerDiv = document.createElement("div");
  innerDiv.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  `;

  const svg = `<svg width="30" height="106" viewBox="0 0 106 106" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g filter="url(#filter0_i_9956_1898)">
  <path d="M90 22.0542C89.5323 23.2563 89.1107 24.4798 88.5869 25.6574C86.616 30.0896 83.8646 33.9401 80.0635 36.9671C79.0667 37.7609 77.9858 38.4501 76.9254 39.1607C74.3277 40.9009 72.0108 42.9341 70.2556 45.565C68.5004 48.1951 67.5573 51.1199 67.1697 54.2438C66.7383 57.7173 66.9767 61.1763 67.4119 64.63C67.4256 64.7399 67.4604 64.8467 67.4997 65.0207C69.227 63.4592 70.9179 61.9304 72.6724 60.3436C72.0767 61.419 71.5083 62.4028 70.9799 63.4088C69.8983 65.4703 68.9999 67.6089 68.3512 69.8521C67.2386 73.7018 65.1329 76.9113 62.2189 79.6215C59.9648 81.7181 57.7971 83.9048 55.8723 86.3205C54.6839 87.8118 53.5842 89.3673 52.9113 91.1739C52.6396 91.9051 52.4806 92.679 52.2603 93.469C52.1249 92.9057 51.9727 92.3447 51.8577 91.7769C51.3793 89.4131 51.2067 87.041 51.7434 84.6612C51.9856 83.585 52.4095 82.5859 53.0248 81.667C54.5144 79.4414 55.2985 76.9441 55.7421 74.3269C56.5436 69.5987 56.1924 64.9276 55.0261 60.2971C54.4818 58.1363 54.086 55.9481 54.033 53.7103C53.9263 49.182 55.5937 45.3818 58.7068 42.1785C61.0086 39.8102 63.6774 37.9319 66.599 36.4565C69.8885 34.7949 73.2491 33.2738 76.5863 31.7099C78.7018 30.7185 80.8227 29.7431 82.8193 28.5158C85.4238 26.9137 87.6287 24.8652 89.5187 22.461C89.6405 22.3061 89.7654 22.1534 89.8888 22C89.9251 22.0183 89.9622 22.0366 89.9985 22.055L90 22.0542Z" fill="url(#paint0_linear_9956_1898)"/>
  </g>
  <g filter="url(#filter1_i_9956_1898)">
  <path d="M54.5564 68.5584C53.2583 68.205 51.9451 67.8974 50.6644 67.4891C47.5725 66.503 44.7114 65.0643 42.1887 62.9761C40.3138 61.4244 38.9635 59.4644 37.7442 57.3808C35.9503 54.3156 34.183 51.2314 32.2703 48.2425C29.198 43.4417 25.4733 39.234 20.6405 36.149C19.2713 35.2751 17.7931 34.5737 16.3648 33.7951C16.2437 33.7295 16.1166 33.6746 16 33.5456C16.3739 33.5723 16.7486 33.5921 17.1217 33.6265C22.2172 34.0951 27.2483 34.895 32.1295 36.5062C36.9184 38.0868 40.8316 40.8772 43.7993 44.9949C45.4562 47.2938 46.7354 49.8018 47.6936 52.4655C48.7464 55.3918 49.7107 58.3508 50.7356 61.287C51.4743 63.402 52.3213 65.4696 53.6587 67.2884C53.9501 67.6845 54.2763 68.0554 54.5867 68.4378C54.5768 68.4783 54.567 68.518 54.5564 68.5584Z" fill="url(#paint1_linear_9956_1898)"/>
  </g>
  <circle cx="53" cy="53" r="52" stroke="url(#paint2_linear_9956_1898)" stroke-width="2"/>
  <defs>
  <filter id="filter0_i_9956_1898" x="51.4124" y="22" width="38.5876" height="73.469" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
  <feFlood flood-opacity="0" result="BackgroundImageFix"/>
  <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
  <feOffset dy="2"/>
  <feGaussianBlur stdDeviation="1"/>
  <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
  <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.25 0"/>
  <feBlend mode="normal" in2="shape" result="effect1_innerShadow_9956_1898"/>
  </filter>
  <filter id="filter1_i_9956_1898" x="16" y="33.5456" width="38.5867" height="37.0128" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
  <feFlood flood-opacity="0" result="BackgroundImageFix"/>
  <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
  <feOffset dy="2"/>
  <feGaussianBlur stdDeviation="1"/>
  <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
  <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.25 0"/>
  <feBlend mode="normal" in2="shape" result="effect1_innerShadow_9956_1898"/>
  </filter>
  <linearGradient id="paint0_linear_9956_1898" x1="61.3201" y1="19" x2="98.2666" y2="93.4949" gradientUnits="userSpaceOnUse">
  <stop stop-color="#008ACB"/>
  <stop offset="1" stop-color="#004565"/>
  </linearGradient>
  <linearGradient id="paint1_linear_9956_1898" x1="25.9074" y1="32.0759" x2="36.3402" y2="75.0132" gradientUnits="userSpaceOnUse">
  <stop stop-color="#008ACB"/>
  <stop offset="1" stop-color="#004565"/>
  </linearGradient>
  <linearGradient id="paint2_linear_9956_1898" x1="20.5" y1="5" x2="81.5" y2="106" gradientUnits="userSpaceOnUse">
  <stop stop-color="#008ACB"/>
  <stop offset="1" stop-color="#004565"/>
  </linearGradient>
  </defs>
  </svg>`;

  innerDiv.innerHTML = svg;
  button.appendChild(innerDiv);

  if (!platformConfig.textAreaSelector) {
    console.error(`No textAreaSelector found for platform: ${platformKey}`);
    return;
  }
  // Create both hover box, loading box and analysis box
  const hoverBox = window.createHoverBox(platform);
  const loadingBox = document.createElement("div");
  const analysisBox = window.createAnalysisBox();

  // Style the loading box similar to hover box but with specific styles for loading state
  loadingBox.style.cssText = `
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%);
    margin-bottom: 8px;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 1000;
    pointer-events: none;
    min-width: 200px;
  `;

  // Default selected style
  let selectedStyle = "Descriptive";
  // Listen for style changes from hover box
  hoverBox.addEventListener("styleSelected", (event) => {
    selectedStyle = event.detail.selectedStyle;
    console.log("Updated Selected Style:", selectedStyle);
  });

  //button onclick EventListener to handle button's functions
  button.addEventListener("click", (event) => {
    console.log("Custom button clicked!");
    console.log("enhance Selected Style:", selectedStyle);

    // Hide analysis box when starting a new enhancement
    if (analysisBox) {
      analysisBox.style.opacity = "0";
      analysisBox.style.pointerEvents = "none";
    }

    innerDiv.classList.add("rotating");

    const chatInputBox = document.querySelector(
      platformConfig.textAreaSelector
    );
    console.log("chatInputBox:", chatInputBox);
    if (!chatInputBox) {
      console.error(`Chat input box not found for platform: ${platformKey}`);
      innerDiv.classList.remove("rotating");
      return;
    }

    let userPrompt =
      chatInputBox.tagName === "TEXTAREA"
        ? chatInputBox.value.trim()
        : chatInputBox.hasAttribute("contenteditable")
        ? chatInputBox.innerText.trim()
        : "";

    if (!userPrompt) {
      console.warn("User prompt is empty!");
      innerDiv.classList.remove("rotating");
      return;
    }

    event.stopPropagation();
    event.preventDefault();

    // Define loading messages
    const loadingMessages = [
      `Enhancing your prompt to match your needs...`,
      `Crafting the perfect prompt for ${platform}...`,
      `Working my magic on your prompt...`,
      `Transforming your prompt with ${selectedStyle} style...`,
      `Adding a touch of Velocity to your writing...`,
      `Optimizing your prompt for better results...`,
      `Crafting your enhanced prompt...`,
      `Making your prompt more impactful...`,
    ];

    // Hide hover box and show loading box
    hoverBox.style.opacity = "0";
    hoverBox.style.pointerEvents = "none";
    loadingBox.style.opacity = "1";

    const updateLoadingMessage = () => {
      const randomIndex = Math.floor(Math.random() * loadingMessages.length);
      loadingBox.innerHTML = `
        <div style="
          padding: 12px 16px;
          text-align: center;
          font-size: 16px;
          font-weight: 600;
          color: #333;
          background: linear-gradient(to right, #f8f9fa, #ffffff);
          border-radius: 8px;
          box-shadow: 0 2px 6px rgba(0,0,0,0.1);
          margin: 8px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
          line-height: 1.4;
          display: flex;
          align-items: center;
          gap: 8px;
        ">
          ${loadingMessages[randomIndex]}
        </div>
      `;
    };

    updateLoadingMessage();
    const messageInterval = setInterval(updateLoadingMessage, 1500);

    // Send both requests in parallel
    Promise.all([
      new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            action: "enhancePrompt",
            prompt: userPrompt,
            style: selectedStyle,
            AIType: platform,
          },
          resolve
        );
      }),
      new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            action: "promptAnalysis",
            prompt: userPrompt,
            style: selectedStyle,
            AIType: platform,
          },
          resolve
        );
      }),
    ]).then(([enhanceResponse, analysisResponse]) => {
      // Clear loading message interval
      clearInterval(messageInterval);

      console.log("Enhance Response:", enhanceResponse);
      console.log("Analysis Response:", analysisResponse);

      innerDiv.classList.remove("rotating");

      if (enhanceResponse.success) {
        // Update text input with enhanced prompt
        if (chatInputBox.tagName === "TEXTAREA") {
          chatInputBox.value = enhanceResponse.data.data.enhanced_prompt;
        } else if (chatInputBox.hasAttribute("contenteditable")) {
          chatInputBox.innerText = enhanceResponse.data.data.enhanced_prompt;
        }

        // Hide loading box
        loadingBox.style.opacity = "0";
        loadingBox.style.pointerEvents = "none";

        // Show analysis box with animation
        analysisBox.style.opacity = "1";
        analysisBox.style.pointerEvents = "auto";

        // Combine both responses for analysis box
        const combinedAnalysis = {
          breakdown: enhanceResponse.data.data.breakdown,
          analysis: analysisResponse.data.data,
        };

        // Show and update analysis box with combined data
        analysisBox.updateContent(combinedAnalysis);
      } else {
        console.error("API Error:", enhanceResponse.error);
      }
    });
  });

  // Append all boxes
  buttonContainer.appendChild(hoverBox);
  buttonContainer.appendChild(loadingBox);
  buttonContainer.appendChild(analysisBox);
  buttonContainer.appendChild(button);
  let hideTimeout;
  // Modify the hover box visibility handling
  button.addEventListener("mouseenter", () => {
    button.style.opacity = "0.7";
    hoverBox.style.opacity = "1";
    hoverBox.style.pointerEvents = "auto";

    // Set timeout to hide after 3s if no interaction
    hideTimeout = setTimeout(() => {
      if (!hoverBox.matches(":hover")) {
        hoverBox.style.opacity = "0";
        hoverBox.style.pointerEvents = "none";
      }
    }, 3000);
  });

  // Prevent hiding if user moves mouse into hover box
  hoverBox.addEventListener("mouseenter", () => {
    clearTimeout(hideTimeout);
  });

  // Hide when user leaves hover box
  hoverBox.addEventListener("mouseleave", () => {
    hoverBox.style.opacity = "0";
    hoverBox.style.pointerEvents = "none";
  });
  return buttonContainer;
}

// Function to locate the correct button container
function findButtonContainer(config) {
  let container = document.querySelector(config.buttonContainerSelector);
  if (!container) {
    const existingButton = document.querySelector(
      config.existingButtonSelector
    );
    if (existingButton) {
      container = existingButton.closest('div[class*="flex"]');
    }
  }
  return container;
}

// Function to inject the button
function injectButton() {
  console.log("Inject button function started...");
  if (!window.platforms) {
    console.error("platforms.js is still not loaded!");
    return;
  }

  chrome.storage.local.get("enabled", ({ enabled }) => {
    if (!enabled) return;

    const currentURL = window.location.href;
    let platformKey = Object.keys(window.platforms).find((key) =>
      window.platforms[key].urlPattern.test(currentURL)
    );

    if (!platformKey) {
      console.log("No matching platform found.");
      return;
    }

    const config = window.platforms[platformKey];
    const flexContainer = findButtonContainer(config);

    if (!flexContainer.querySelector(".custom-injected-button")) {
      const button = createCustomButton();

      // Add event listener to text area for Enter key
      const chatInputBox = document.querySelector(config.textAreaSelector);
      if (chatInputBox) {
        chatInputBox.addEventListener("keydown", async (event) => {
          // Check if Enter was pressed without Shift (for new line)
          if (event.key === "Enter" && !event.shiftKey) {
            console.log("Enter key pressed");
            const userPrompt =
              chatInputBox.tagName === "TEXTAREA"
                ? chatInputBox.value.trim()
                : chatInputBox.hasAttribute("contenteditable")
                ? chatInputBox.innerText.trim()
                : "";
            console.log("userPrompt:", userPrompt);

            if (userPrompt) {
              // Get the button container and create analysis box
              const analysisBoxContainer = document.querySelector(
                ".velocity-analysis-box"
              );
              // const analysisBox = window.createAnalysisBox();

              // Request prompt analysis using Promise
              new Promise((resolve) => {
                chrome.runtime.sendMessage(
                  {
                    action: "promptAnalysis",
                    prompt: userPrompt,
                    style: "Descriptive", // Default style
                    AIType: platformKey,
                  },
                  resolve
                );
              }).then((response) => {
                if (response.success) {
                  console.log("analysisResponse:", response);
                  // Show and update analysis box
                  analysisBoxContainer.updateContent({
                    analysis: response.data.data,
                  });
                  analysisBoxContainer.style.opacity = "1";
                  analysisBoxContainer.style.pointerEvents = "auto";
                  analysisBoxContainer.style.visibility = "visible";

                  // analysisBoxContainer.appendChild(analysisBox);
                }
              });
            }
          }
        });
      }

      if (platformKey === "chatgpt") {
        button.style.order = "9999"; // High order value pushes it to the end
        flexContainer.style.display = "flex"; // Ensure flex display
        flexContainer.appendChild(button);
        console.log("Button injected after for ChatGPT.");
      } else if (platformKey === "claude") {
        flexContainer.appendChild(button);
        console.log("Button injected after for Claude.");
      } else if (platformKey === "gemini") {
        flexContainer.appendChild(button);
        console.log("Button injected after for Gemini.");
      } else {
        console.log(`Button injection skipped for platform: ${platformKey}`);
      }
      console.log("Button injected successfully.");

      const messageBox = injectMessageBox();
      flexContainer.style.position = "relative";
      flexContainer.appendChild(messageBox);
    }
  });
}

// Function to remove the injected button
function removeButton() {
  console.log("Removing button...");
  const existingButton = document.querySelector(".custom-injected-button");
  if (existingButton) {
    existingButton.remove();
    console.log("Button removed.");
  }
}

// Observe DOM changes to reinject the button if needed
function observeDOMChanges() {
  const observer = new MutationObserver(() => {
    if (!document.querySelector(".custom-injected-button")) {
      injectButton();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// Auto-inject button when script loads
chrome.storage.local.get("enabled", ({ enabled }) => {
  if (enabled) {
    (function () {
      console.log("Content script loaded.");
      injectButton();
      observeDOMChanges();
    })();
  }
});

// Listen for storage changes and update button state
chrome.storage.onChanged.addListener((changes) => {
  if (
    changes.enabled ||
    changes.token ||
    changes.userName ||
    changes.userId ||
    changes.userEmail
  ) {
    checkAuthAndInjectButton();
  }
});
// Auto-check on script load
checkAuthAndInjectButton();

// Listen for runtime messages to toggle button
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "toggleButton") {
    if (message.enabled) {
      injectButton();
    } else {
      removeButton();
    }
  }
});
