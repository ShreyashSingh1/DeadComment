window.platforms = {
  chatgpt: {
    urlPattern: /^https:\/\/chatgpt\.com/,
    buttonContainerSelector: 'div[class="ml-auto"]',
    existingButtonSelector: '[data-testid="composer-speech-button"]',
    textAreaSelector: ".ProseMirror",
  },
  claude: {
    urlPattern: /^https:\/\/claude\.ai/,
    buttonContainerSelector: 'div[class*="flex gap-2.5 w-full items-center"]',
    existingButtonSelector: 'div[class*="overflow-hidden shrink-0 p-1 -m-1"]',
    textAreaSelector: '.ProseMirror, div[contenteditable="true"]',
  },
  gemini: {
    urlPattern: /^https:\/\/gemini\.google\.com/,
    buttonContainerSelector: ".trailing-actions-wrapper",
    existingButtonSelector: ".send-button-container",
    textAreaSelector: ".ql-editor",
  },
  grok: {
    urlPattern: /^https:\/\/grok\.com/,
    existingButtonSelector: 'button[type="submit"].group.flex.rounded-full',
    textAreaSelector: "textarea",
  },
  // perplexity: {
  //   urlPattern: /^https:\/\/(?:www\.)?perplexity\.ai/,
  //   buttonContainerSelector: "div[class*='ml-sm'][class*='flex'][class*='gap']",
  //   existingButtonSelector: "button[aria-label='Submit']",
  //   textAreaSelector: "div[contenteditable='true']",
  // },
  // mistral: {
  //   urlPattern: /^https:\/\/(?:www\.)?mistral\.ai\/chat/,
  //   buttonContainerSelector: "div[class*='flex'][class*='justify-end']",
  //   existingButtonSelector: "button[type='submit']",
  //   textAreaSelector: "textarea",
  // },
  // deepseek: {
  //   urlPattern: /^https:\/\/(?:www\.)?deepseek\.com/,
  //   buttonContainerSelector: "div[class*='flex'][class*='items-end']",
  //   existingButtonSelector: "button[type='submit']",
  //   textAreaSelector: "div[contenteditable='true']",
  // },
  // leonardo: {
  //   urlPattern: /^https:\/\/app\.leonardo\.ai\/image-generation/,
  //   buttonContainerSelector: "div[class*='flex'][class*='justify-between']",
  //   existingButtonSelector: "button[type='submit']",
  //   textAreaSelector: "textarea[placeholder*='prompt']",
  // },
  // runway: {
  //   urlPattern: /^https:\/\/(?:www\.)?runwayml\.com/,
  //   buttonContainerSelector: "div[class*='flex'][class*='items-end']",
  //   existingButtonSelector: "button[type='submit'], button[aria-label*='Generate']",
  //   textAreaSelector: "textarea, div[contenteditable='true']",
  // }
};