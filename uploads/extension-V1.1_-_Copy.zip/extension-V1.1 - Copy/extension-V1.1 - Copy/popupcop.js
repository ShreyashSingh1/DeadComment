document.addEventListener("DOMContentLoaded", () => {
  const toggleButton = document.getElementById("toggleButton");

  // Get stored state
  chrome.storage.local.get("enabled", ({ enabled }) => {
    toggleButton.checked = enabled !== false;
  });

  toggleButton.addEventListener("change", async (event) => {
    if (!userId || !token) {
      event.preventDefault();
      toggleButton.checked = false;
      showLoginError();
      return;
    }

    const enabled = toggleButton.checked;
    chrome.storage.local.set({ enabled });

    // Notify background script to update content.js injection
    chrome.runtime.sendMessage({ action: "toggleContentScript", enabled });

    // Inject or remove script from the active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        if (enabled) {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            files: ["content-script.js"], // Inject script
          });
        } else {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: () => {
              document.querySelector(".custom-injected-button")?.remove(); // Remove button
            },
          });
        }
      }
    });
  });
});
