const JavaScriptObfuscator = require("javascript-obfuscator");
const fs = require("fs");

const contentScript = fs.readFileSync("content-script.js", "utf8");

const obfuscationResult = JavaScriptObfuscator.obfuscate(contentScript, {
  compact: true,
  //   controlFlowFlattening: true, //not working
  deadCodeInjection: true,
  stringArray: true,
  // stringArrayEncoding: ["base64"], // or ['rc4'] for stronger encryption
  stringArrayEncoding: ["rc4"],
  stringArrayThreshold: 1, // Obfuscates ALL strings
  renameGlobals: true,
  rotateStringArray: true,
  stringArrayIndexesType: ["hexadecimal-number"],
  stringArrayIndexShift: true,
  stringArrayRotate: true,
  stringArrayShuffle: true,
  simplify: true,
  // selfDefending: true, // Prevents debugging //not working
});

fs.writeFileSync(
  "content-script-obfuscated.js",
  obfuscationResult.getObfuscatedCode()
);
// console.log("Obfuscation complete!");