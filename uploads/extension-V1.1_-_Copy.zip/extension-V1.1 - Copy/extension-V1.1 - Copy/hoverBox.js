function createHoverBox(platform) {
  const hoverBox = document.createElement("div");

  // Platform-specific styles with dark mode support
  const platformStyles = {
    chatgpt: {
      position: "bottom",
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 8px;
        margin-left: 20px;
        position: absolute; /* Add this */
        z-index: 99999; /* Add this */
      `,
      hoverBoxCssDark: `
        background-color: #333;
        color: white;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-bottom: 8px;
        margin-left: 20px;
        position: absolute; /* Add this */
        z-index: 99999; /* Add this */
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    claude: {
      position: "bottom",
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 8px;
      `,
      hoverBoxCssDark: `
        background-color: #333;
        color: white;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-bottom: 8px;
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    gemini: {
      position: "bottom",
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 8px;
        border-width: 0px;
      `,
      hoverBoxCssDark: `
        background-color: #333;
        color: white;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-bottom: 8px;
        border-width: 0px;
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 6px 8px;
        border-radius: 4px;
        border-style: solid;
        text-align: left;
        transition: background-color 0.2s;
        border-width: 0px;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 6px 8px;
        border-radius: 4px;
        border-style: solid;
        border-width: 0px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        border-style: solid;
        border-width: 0px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 6px 8px;
        border-radius: 4px;
        border-style: solid;
        border-width: 0px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    leonardo: {
      position: "top",  // Position above for image generation platforms
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 -10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-top: 8px;
        border: 1px solid #e5e7eb;
      `,
      hoverBoxCssDark: `
        background-color: #1f2937;
        color: white;
        padding: 12px;
        box-shadow: 0 -10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-top: 8px;
        border: 1px solid #374151;
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    runway: {
      position: "top",  // Position above for image generation platforms
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 -10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-top: 8px;
        border: 1px solid #e5e7eb;
      `,
      hoverBoxCssDark: `
        background-color: #1f2937;
        color: white;
        padding: 12px;
        box-shadow: 0 -10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-top: 8px;
        border: 1px solid #374151;
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 6px 10px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    mistral: {
      position: "bottom",
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 8px;
        border: 1px solid #e5e7eb;
      `,
      hoverBoxCssDark: `
        background-color: #1f2937;
        color: white;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-bottom: 8px;
        border: 1px solid #374151;
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    deepseek: {
      position: "bottom",
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 8px;
        border: 1px solid #e5e7eb;
      `,
      hoverBoxCssDark: `
        background-color: #1f2937;
        color: white;
        padding: 12px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.5);
        margin-bottom: 8px;
        border: 1px solid #374151;
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.2);
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: rgba(0, 138, 203, 0.5);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
        transition: background-color 0.2s;
      `,
    },
    default: {
      position: "bottom",
      hoverBoxCssLight: `
        background-color: white;
        color: black;
        padding: 12px;
        box-shadow: 0 4px 6px -1px rgb(255, 255, 255);
        border: 1px solid #D1D5DB;
        margin-bottom: 16px;
    
      `,
      hoverBoxCssDark: `
        background-color: #333;
        color: white;
        padding: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.5);
        border: 1px solid #444;
        margin-bottom: 16px;
    
      `,
      buttonActiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: #2563EB;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
  ;
      `,
      buttonActiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: #1E90FF;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
      `,
      buttonInactiveCssLight: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: black;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
    
      `,
      buttonInactiveCssDark: `
        width: 100%;
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: transparent;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        text-align: left;
      
      `,
    }
  };

  // Function to apply styles based on dark mode
  function applyStyles(isDarkMode) {
    const styles = platformStyles[platform] || platformStyles.default;
    
    // For ChatGPT, Grok, Claude and Gemini, we use fixed positioning to avoid clipping issues
    if (platform === "chatgpt" || platform === "grok" || platform === "claude" || platform === "gemini") {
      hoverBox.style.cssText = `
        position: fixed;
        width: 144px;
        font-size: 14px;
        border-radius: 8px;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s;
        pointer-events: none;
        z-index: 999999; /* Super high z-index to ensure it appears above everything */
        ${isDarkMode ? styles.hoverBoxCssDark : styles.hoverBoxCssLight}
      `;
    } else {
      // Original positioning for other platforms
      hoverBox.style.cssText = `
        position: absolute;
        left: 100%;
        margin-left: 20px; 
        width: 144px;
        font-size: 14px;
        border-radius: 8px;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s;
        pointer-events: none;
        ${styles.position === "bottom" ? "bottom: 100%;" : "top: 100%;"}
        ${isDarkMode ? styles.hoverBoxCssDark : styles.hoverBoxCssLight}
      `;
    }
    
    // Update buttons
    hoverBox.querySelectorAll("button").forEach(button => {
      const isActive = button.style.cssText.includes("background-color: rgba(0, 138, 203") ||
                       button.style.cssText.includes("background-color: #2563EB") ||
                       button.style.cssText.includes("background-color: #1E90FF");
      button.style.cssText = isActive 
        ? (isDarkMode ? styles.buttonActiveCssDark : styles.buttonActiveCssLight)
        : (isDarkMode ? styles.buttonInactiveCssDark : styles.buttonInactiveCssLight);
    });
  }

  // Initial style application
  chrome.storage.local.get(["darkMode"], (result) => {
    const isDarkMode = result.darkMode === true;
    applyStyles(isDarkMode);
  });

  // Listen for dark mode changes
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "darkMode" in changes) {
      applyStyles(changes.darkMode.newValue);
    }
  });

  // Icon definitions
  const iconColor = (isDarkMode) => isDarkMode ? "#1E90FF" : "#008ACB";
  const styleIcons = {
    Descriptive: `<svg width="16" height="16" viewBox="0 0 24 24" fill="${iconColor(false)}"><path d="M3 6h18v2H3V6zm0 5h18v2H3v-2zm0 5h18v2H3v-2z"/></svg>`,
    Creative: `<svg width="16" height="16" viewBox="0 0 24 24" fill="${iconColor(false)}"><path d="M20.71 4.04c.39.39.39 1.02 0 1.41L18 8.16 15.84 6l2.71-2.71c.39-.39 1.02-.39 1.41 0l.75.75zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>`,
    Professional: `<svg width="16" height="16" viewBox="0 0 24 24" fill="${iconColor(false)}"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg>`,
    Concise: `<svg width="16" height="16" viewBox="0 0 24 24" fill="${iconColor(false)}"><path d="M3 6h18v2H3V6zm0 5h18v2H3v-2zm0 5h18v2H3v-2z"/></svg>`,
  };

  // Create selectable styles with icons
  const styleOptions = ["Descriptive", "Creative", "Concise", "Professional"];
  let selectedStyle = "Descriptive";

  chrome.storage.local.get(["darkMode"], (result) => {
    const isDarkMode = result.darkMode === true;
    const styles = platformStyles[platform] || platformStyles.default;

    styleOptions.forEach((style) => {
      const button = document.createElement("button");
      button.type = "button";
      
      button.style.cssText = style === selectedStyle
        ? (isDarkMode ? styles.buttonActiveCssDark : styles.buttonActiveCssLight)
        : (isDarkMode ? styles.buttonInactiveCssDark : styles.buttonInactiveCssLight);

      button.innerHTML = `
        ${styleIcons[style]}
        <span style="display: inline-block; white-space: nowrap;">${style}</span>
      `;

      button.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        selectedStyle = style;

        chrome.storage.local.get(["darkMode"], (result) => {
          const currentDarkMode = result.darkMode === true;
          hoverBox.querySelectorAll("button").forEach((btn) => {
            const btnText = btn.innerText || "";
            btn.style.cssText = styles.buttonInactiveCssLight;
            if (styleIcons[btnText]) {
              btn.innerHTML = `
                ${styleIcons[btnText]}
                <span style="display: inline-block; white-space: nowrap;">${btnText}</span>
              `;
            }
            btn.style.cssText = currentDarkMode 
              ? styles.buttonInactiveCssDark 
              : styles.buttonInactiveCssLight;
          });
          
          button.style.cssText = currentDarkMode 
            ? styles.buttonActiveCssDark 
            : styles.buttonActiveCssLight;
          button.innerHTML = `
            ${styleIcons[style]}
            <span style="display: inline-block; white-space: nowrap;">${style}</span>
          `;
        });

        hoverBox.dispatchEvent(
          new CustomEvent("styleSelected", { detail: { selectedStyle } })
        );
        return false;
      };

      button.addEventListener("mouseenter", () => {
        if (style !== selectedStyle) {
          button.style.backgroundColor = isDarkMode ? "#444" : "#E5E7EB";
        }
      });

      button.addEventListener("mouseleave", () => {
        if (style !== selectedStyle) {
          button.style.backgroundColor = "transparent";
        }
      });

      hoverBox.appendChild(button);
    });
  });

  return hoverBox;
}

window.createHoverBox = createHoverBox;