document.addEventListener("DOMContentLoaded", function () {
  // Verify Chrome extension context
  if (!chrome || !chrome.storage) {
      console.error("Chrome storage not available - not running in extension context");
      return;
  }

  // Cache DOM elements with safety checks
  const darkModeToggle = document.getElementById("darkModeToggle");
  const body = document.body;

  if (!darkModeToggle || !body) {
      console.error("Required DOM elements not found");
      return;
  }

  // Initialize dark mode from chrome.storage
  chrome.storage.local.get(["darkMode"], function(result) {
      const isDarkMode = result.darkMode === true; // Default to false if undefined
      
      // Apply initial state
      body.classList.toggle("dark-mode", isDarkMode);
      updateIcon(isDarkMode);

      // Event listener with debouncing
      let timeoutId;
      darkModeToggle.addEventListener("click", () => {
          clearTimeout(timeoutId);
          timeoutId = setTimeout(() => {
              const newDarkMode = body.classList.toggle("dark-mode");
              
              chrome.storage.local.set({ darkMode: newDarkMode }, () => {
                  if (chrome.runtime.lastError) {
                      console.warn("Failed to save dark mode preference:", chrome.runtime.lastError);
                  }
                  updateIcon(newDarkMode);
              });
          }, 100); // 100ms debounce
      });
  });

  function updateIcon(isDarkMode) {
      const icon = darkModeToggle.querySelector("img");
      if (!icon) {
          console.warn("Dark mode icon not found");
          return;
      }

      // Update icon and accessibility
      const iconPath = isDarkMode ? "./assets/sun.png" : "./assets/moon.png";
      icon.src = iconPath;
      icon.alt = isDarkMode ? "Switch to light mode" : "Switch to dark mode";
      darkModeToggle.setAttribute("aria-label", icon.alt);
      
      // Handle image load errors
      icon.onerror = () => {
          console.error(`Failed to load icon: ${iconPath}`);
          icon.src = isDarkMode ? 
              "https://cdn-icons-png.flaticon.com/512/869/869869.png" :  // Fallback sun
              "https://cdn-icons-png.flaticon.com/512/7699/7699366.png";  // Fallback moon
      };
  }

  // Check if the video has been shown
  chrome.storage.local.get(["videoShown"], function (data) {
    if (!data.videoShown) {
      showIntroVideo(); // Function to show the intro video
    } else {
      // Start tutorial if video has already been shown
      startTutorialIfNeeded();
    }
  });

  // Restart tutorial when clicking info button
  const infoButton = document.getElementById("infoButton");
  if (infoButton) {
    infoButton.addEventListener("click", function () {
      // Reset tutorial state to allow it to show again
      chrome.storage.local.set({ tutorialShown: false, lastTutorialStep: 0 }, function () {
        initializeTutorial();
      });
    });
  }
});

function renderResponse(responseText) {
    const responseContainer = document.createElement('div');
    responseContainer.className = 'response-container';
    
    // Limit the response text to the first 2-3 lines
    const lines = responseText.split('\n');
    const displayedText = lines.slice(0, 3).join('\n') + (lines.length > 3 ? '...' : '');
    
    responseContainer.textContent = displayedText;
    document.querySelector('.responses-grid').appendChild(responseContainer);
}

// Function to show the intro video
function showIntroVideo() {
  const videoContainer = document.createElement("div");
  videoContainer.style.position = "fixed";
  videoContainer.style.top = "0";
  videoContainer.style.left = "0";
  videoContainer.style.width = "100%";
  videoContainer.style.height = "100%";
  videoContainer.style.zIndex = "9999"; // Ensure it's on top
  videoContainer.style.backgroundColor = "rgba(0, 0, 0, 0.8)"; // Dark background
  videoContainer.style.display = "flex";
  videoContainer.style.flexDirection = "column"; // Stack video and controls vertically
  videoContainer.style.justifyContent = "center";
  videoContainer.style.alignItems = "center";

  const video = document.createElement("video");
  video.src = "./assets/Intro_D3.webm"; // Path to your video
  video.style.width = "100vh"; // Full width
  video.style.height = "150vh"; // Full height
  video.style.objectFit = "cover"; // Cover the entire area
  video.controls = false; // Disable default controls

  // Create a custom control panel
  const controlPanel = document.createElement("div");
  controlPanel.style.display = "flex";
  controlPanel.style.justifyContent = "center";
  controlPanel.style.alignItems = "center";
  controlPanel.style.marginTop = "10px"; // Space between video and controls
  controlPanel.style.backgroundColor = "rgba(0, 0, 0, 0.7)"; // Semi-transparent background
  controlPanel.style.padding = "10px";
  controlPanel.style.borderRadius = "5px";

  // Play/Pause button
  const playPauseButton = document.createElement("button");
  playPauseButton.textContent = "Play";
  playPauseButton.style.marginRight = "10px";
  playPauseButton.style.color = "white";
  playPauseButton.style.backgroundColor = "transparent";
  playPauseButton.style.border = "1px solid white";
  playPauseButton.style.borderRadius = "5px";
  playPauseButton.style.padding = "5px 10px";
  playPauseButton.onclick = () => {
    if (video.paused) {
      video.play();
      playPauseButton.textContent = "Pause";
    } else {
      video.pause();
      playPauseButton.textContent = "Play";
    }
  };

  // Volume control
  const volumeControl = document.createElement("input");
  volumeControl.type = "range";
  volumeControl.min = "0";
  volumeControl.max = "1";
  volumeControl.step = "0.1";
  volumeControl.value = "1"; // Default volume
  volumeControl.style.marginLeft = "10px";
  volumeControl.oninput = () => {
    video.volume = volumeControl.value;
  };

  // Append controls to the control panel
  controlPanel.appendChild(playPauseButton);
  controlPanel.appendChild(volumeControl);

  // Append video and control panel to the container
  videoContainer.appendChild(video);
  videoContainer.appendChild(controlPanel);
  document.body.appendChild(videoContainer);

  video.addEventListener("ended", function () {
    // Remove video container after it ends
    document.body.removeChild(videoContainer);
    // Set videoShown to true after the video is completed
    chrome.storage.local.set({ videoShown: true }, function () {
      startTutorialIfNeeded(); // Start the tutorial after the video
    });
  });

  video.play().catch((error) => {
    console.error("Error playing video:", error);
    document.body.removeChild(videoContainer);
  });
}

// Function to start the tutorial if needed
function startTutorialIfNeeded() {
  chrome.storage.local.get(["tutorialShown"], function (data) {
    if (!data.tutorialShown) {
      initializeTutorial();
    }
  });
}

function initializeTutorial() {
  chrome.storage.local.get(["userEmail", "lastTutorialStep"], function (authData) {
    let lastStep = authData.lastTutorialStep || 0;

    let tutorialSteps = [
      {
        element: "#promptInput",
        intro: "Start by typing your prompt here.",
        position: "bottom",
      },
      {
        element: "#chatgpt-option",
        intro: "Pick an AI model that suits your needs.",
        position: "bottom",
      },
      {
        element: 'label[for="descriptive"]',
        intro: "Choose a style to shape your response.",
        position: "bottom",
      },
      {
        element: "#sendButton",
        intro: 'Hit "Generate" to get results.',
        position: "bottom",
      },
      {
        element: "#signupButton",
        intro: 'Check your prompt history here.',
        position: "bottom",
      },
    ];

    const tutorial = introJs().setOptions({
      showProgress: true,
      showBullets: false,
      exitOnOverlayClick: false,
      exitOnEsc: false,
      nextLabel: "Next",
      prevLabel: "Prev",
      tooltipClass: "customTooltip",
      showButtons: true,
      tooltipPosition: "left",
      steps: tutorialSteps,
    });

    tutorial.onbeforechange(function () {
      let currentStep = tutorial._currentStep;
      let totalSteps = tutorialSteps.length - 1;

      // Disable pointer events for all elements
      document.body.classList.add("disable-pointer-events");

      // Enable pointer events for the current tutorial element
      const currentElement = tutorialSteps[currentStep].element;
      const activeElement = document.querySelector(currentElement);
      if (activeElement) {
        activeElement.classList.add("allow-pointer-events");
      }

      // Modify buttons dynamically
      setTimeout(() => {
        const nextButton = document.querySelector(".introjs-nextbutton");
        const buttonContainer = document.querySelector(".introjs-tooltipbuttons");

        if (nextButton && buttonContainer) {
          if (currentStep === totalSteps) {
            nextButton.style.display = "none"; // Hide default next button
            
            // Create the final button if not already created
            if (!document.querySelector(".introjs-finalbutton")) {
              const finalButton = document.createElement("button");
              finalButton.textContent = "Finish";
              finalButton.className = "introjs-button introjs-finalbutton";
              finalButton.addEventListener("click", () => tutorial.exit());

              buttonContainer.appendChild(finalButton);
            }
          } else {
            nextButton.style.display = "inline-block"; // Show Next button for other steps

            // Remove Final button if it exists
            const finalButton = document.querySelector(".introjs-finalbutton");
            if (finalButton) finalButton.remove();
          }
        }
      }, 100); // Small delay to ensure elements are available
    });

    tutorial.onchange(function () {
      // Enable pointer events for the current tutorial element
      const currentStep = tutorial._currentStep;
      const currentElement = tutorialSteps[currentStep].element;
      const activeElement = document.querySelector(currentElement);
      if (activeElement) {
        activeElement.classList.add("allow-pointer-events");
      }
    });

    tutorial.onexit(function () {
      // Remove the disable class when the tutorial exits
      document.body.classList.remove("disable-pointer-events");
      const activeElement = document.querySelector(".allow-pointer-events");
      if (activeElement) {
        activeElement.classList.remove("allow-pointer-events");
      }
      // Set tutorialShown to true after the tutorial is completed
      chrome.storage.local.set({ tutorialShown: true });
    });

    // Add event listener to the Generate button
    const generateButton = document.getElementById("sendButton");
    if (generateButton) {
      generateButton.addEventListener("click", () => {
        tutorial.nextStep(); // Call the next step in the tutorial
      });
    }

    tutorial.start().goToStep(lastStep + 1);
  });
}