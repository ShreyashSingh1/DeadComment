function showWelcomeMessage() {
  chrome.storage.local.get(["firstInstall", "welcomeDismissed"], (data) => {
    if (!data.firstInstall || data.welcomeDismissed) return;

    // Ensure only one welcome box is added by removing the existing one
    const existingWelcomeBox = document.getElementById("welcomeTutorialBox");
    if (existingWelcomeBox) {
      existingWelcomeBox.remove();
    }

    const welcomeBox = document.createElement("div");
    welcomeBox.id = "welcomeTutorialBox";
    welcomeBox.style = `
      position: fixed; 
      top: 20px; 
      right: 20px; 
      background: #1e1e1e; 
      color: #f0f0f0; 
      padding: 10px; 
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4); 
      border-radius: 12px; 
      z-index: 9999999;  /* Ensure this is higher than other messages */
      font-family: 'Arial', sans-serif; 
      max-width: 280px; 
      border: 1px solid rgba(255, 255, 255, 0.1);
    `;

    welcomeBox.innerHTML = `
      <h2 style="margin: 0 0 5px; font-size: 18px; font-weight: 600; color: #ffffff;">
        Welcome!
      </h2>
      <p style="font-size: 14px; margin-bottom: 10px; color: #bbbbbb;">
        Thank you for installing our extension.
      </p>
      <button id="closeWelcome" style="
        background-color: #007bff; 
        color: #ffffff; 
        border: none; 
        padding: 5px 15px; 
        border-radius: 6px; 
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.3s ease;
        outline: none;
        box-shadow: 0 2px 10px rgba(0, 123, 255, 0.3);
      " onmouseover="this.style.backgroundColor='#0056b3'" onmouseout="this.style.backgroundColor='#007bff'">
        Start Tutorial
      </button>
    `;

    document.body.appendChild(welcomeBox);

    document.getElementById("closeWelcome").addEventListener("click", () => {
      // console.log("clicked");

      // Send a message to the background script to open the extension popup
      chrome.runtime.sendMessage({ action: "open_extension_popup" });

      // Remove welcome message from all windows
      chrome.runtime.sendMessage({ action: "remove_welcome_message" });
    });
  });
}
