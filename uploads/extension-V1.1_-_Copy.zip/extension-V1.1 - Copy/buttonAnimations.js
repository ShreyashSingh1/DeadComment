// buttonAnimations.js
// Optimized circular glow animations while maintaining compatibility with existing code

(function() {
  // Configuration constants
  const TYPING_TIMEOUT = 2500; // Increased from 800ms to 2500ms as requested
  const IDLE_TIMEOUT = 3000;  // Changed from 8000ms to 3000ms as requested
  
  // State tracking variables
  let typingTimer;
  let idleTimer;
  let idleShakeInterval;
  let isTyping = false;
  let initialMessageShown = false;
  
  // Track message display state
  let activeMessageBox = null;
  let activeMessageTimer = null;
  
  // Inject animation styles
  function injectAnimationStyles() {
    if (document.getElementById("velocity-animation-styles")) return;

    const styleEl = document.createElement("style");
    styleEl.id = "velocity-animation-styles";
    styleEl.innerHTML = `
      /* Idle state - circular inward pulse animation with subtle shake and bounce effect */
      @keyframes veloInnerPulseAndBounce {
        0% {
          box-shadow: inset 0 0 5px rgba(0, 136, 255, 0.3);
          transform: scale(1) translateY(0) translateX(0);
          border-radius: 50%;
        }
        15% {
          box-shadow: inset 0 0 10px rgba(0, 136, 255, 0.5);
          transform: scale(1.02) translateY(-2px) translateX(-0.25px);
          border-radius: 50%;
        }
        30% {
          box-shadow: inset 0 0 12px rgba(0, 136, 255, 0.6);
          transform: scale(1.03) translateY(-3px) translateX(0.5px);
          border-radius: 50%;
        }
        40% {
          box-shadow: inset 0 0 15px rgba(0, 136, 255, 0.7);
          transform: scale(1.05) translateY(-4px) translateX(-0.5px);
          border-radius: 50%;
        }
        50% {
          box-shadow: inset 0 0 12px rgba(0, 136, 255, 0.6);
          transform: scale(1.03) translateY(-2px) translateX(0.25px);
          border-radius: 50%;
        }
        60% {
          box-shadow: inset 0 0 10px rgba(0, 136, 255, 0.5);
          transform: scale(1.02) translateY(0) translateX(-0.25px);
          border-radius: 50%;
        }
        70% {
          box-shadow: inset 0 0 8px rgba(0, 136, 255, 0.45);
          transform: scale(1.015) translateY(-2px) translateX(0.25px);
          border-radius: 50%;
        }
        80% {
          box-shadow: inset 0 0 7px rgba(0, 136, 255, 0.4);
          transform: scale(1.01) translateY(-4px) translateX(-0.5px);
          border-radius: 50%;
        }
        90% {
          box-shadow: inset 0 0 6px rgba(0, 136, 255, 0.35);
          transform: scale(1.005) translateY(-2px) translateX(0.25px);
          border-radius: 50%;
        }
        100% {
          box-shadow: inset 0 0 5px rgba(0, 136, 255, 0.3);
          transform: scale(1) translateY(0) translateX(0);
          border-radius: 50%;
        }
      }
      
      /* Faster shake animation */
      @keyframes veloShake {
        0%, 100% {
          transform: translateX(0);
        }
        10%, 30%, 50%, 70%, 90% {
          transform: translateX(-2px);
        }
        20%, 40%, 60%, 80% {
          transform: translateX(1px);
        }
      }
      
      /* Combined pulse bounce and shake effect */
      .velocity-inner-pulse-bounce-shake {
        animation: veloInnerPulseAndBounce 2s infinite cubic-bezier(.36,.07,.19,.97), 
                   veloShake 0.5s infinite ease-in-out; /* Reduced from 1.2s to 0.5s for faster shake */
      }
      
      .velocity-inner-pulse-bounce {
        animation: veloInnerPulseAndBounce 2s infinite cubic-bezier(.36,.07,.19,.97);
      }
      
      /* Typing pulse animation - inside to outward (replacing veloInnerTypingPulse) */
      @keyframes veloInnerToOuterPulse {
        0% {
          transform: scale(1);
          border-radius: 50%;
        }
        50% {
          transform: scale(1.05);
          border-radius: 50%;
        }
        100% {
          transform: scale(1);
          border-radius: 50%;
        }
      }
      
      .velocity-inner-to-outer-pulse {
        animation: veloInnerToOuterPulse 1.2s infinite cubic-bezier(.45,.05,.55,.95);
      }
      
      .velocity-enhanced-inner-glow {
        animation: veloEnhancedInnerGlow 1.5s ease-in-out;
      }
      
      /* Button press animation with outward wave effect and bounce - updated for continuous effect */
      @keyframes veloButtonPressOutwardWave {
        0% { 
          box-shadow: 0 0 0 0 rgba(0, 136, 255, 0.5);
          transform: scale(1) translateY(0);
          border-radius: 50%;
        }
        25% {
          box-shadow: 0 0 0 3px rgba(0, 136, 255, 0.4);
          transform: scale(0.95) translateY(2px);
          border-radius: 50%;
        }
        50% {
          box-shadow: 0 0 0 5px rgba(0, 136, 255, 0.3);
          transform: scale(1.05) translateY(-3px);
          border-radius: 50%;
        }
        75% {
          box-shadow: 0 0 0 3px rgba(0, 136, 255, 0.2);
          transform: scale(1.02) translateY(-1px);
          border-radius: 50%;
        }
        100% {
          box-shadow: 0 0 0 0px rgba(0, 136, 255, 0.4);
          transform: scale(1) translateY(0);
          border-radius: 50%;
        }
      }
      
      .velocity-press-outward-wave {
        animation: veloButtonPressOutwardWave 1.5s infinite ease-out;
      }
      
      /* Processing animation - rotation */
      @keyframes veloRotate {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      
      .velocity-rotate {
        animation: veloRotate 1s linear infinite;
      }
      
      /* Processing wave animation - continuous outward waves */
      @keyframes veloProcessingOutwardWave {
        0% {
          box-shadow: 0 0 0 0 rgba(0, 136, 255, 0.7);
          border-radius: 50%;
        }
        50% {
          box-shadow: 0 0 0 15px rgba(0, 136, 255, 0);
          border-radius: 50%;
        }
        100% {
          box-shadow: 0 0 0 0 rgba(0, 136, 255, 0.7);
          border-radius: 50%;
        }
      }
      
      .velocity-processing-outward-wave {
        animation: veloProcessingOutwardWave 1.5s infinite ease-out;
      }
      
      /* Success animation - reverse effect */
      @keyframes veloSuccessReverse {
        0% {
          transform: scale(1.3);
          box-shadow: 0 0 0 8px rgba(0, 136, 255, 0);
          border-radius: 50%;
        }
        100% {
          transform: scale(1);
          box-shadow: 0 0 0 8px rgba(0, 136, 255, 0);
          border-radius: 50%;
        }
      }
      .velocity-success-reverse {
        animation: veloSuccessReverse 1s ease-in-out;
      }
      
      /* Finish wave animation - reverse */
      @keyframes veloFinishWaveReverse {
        0% {
          box-shadow: 0 0 0 10px rgba(0, 136, 255, 0);
          transform: scale(1.05);
          border-radius: 50%;
        }
        50% {
          box-shadow: 0 0 0 0 rgba(0, 136, 255, 0.4);
          transform: scale(1);
          border-radius: 50%;
        }
        100% {
          box-shadow: 0 0 0 10px rgba(0, 136, 255, 0);
          transform: scale(1.05);
          border-radius: 50%;
        }
      }
      
      .velocity-finish-wave-reverse {
        animation: veloFinishWaveReverse 1.5s cubic-bezier(.36,.07,.19,.97);
      }
      
      /* Message box animation */
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .velocity-message-box {
        position: fixed;
        animation: fadeIn 0.3s ease-in-out;
        z-index: 999999 !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
      }
      
      /* Half-size inner circle glow animation for typing - inside to outside */
      @keyframes veloHalfCircleGlow {
        0% {
          background: radial-gradient(
            circle at center,
            rgba(0, 136, 255, 0.9) 0%,
            rgba(0, 136, 255, 0.5) 25%,
            rgba(0, 136, 255, 0.1) 55%,
            transparent 80%
          );
          transform: scale(0.7);
          opacity: 0.6;
        }
        50% {
          background: radial-gradient(
            circle at center,
            rgba(0, 136, 255, 0.9) 0%,
            rgba(0, 136, 255, 0.6) 25%,
            rgba(0, 136, 255, 0.3) 45%,
            rgba(0, 136, 255, 0.1) 65%,
            transparent 80%
          );
          transform: scale(1.0);
          opacity: 0.9;
        }
        100% {
          background: radial-gradient(
            circle at center,
            rgba(0, 136, 255, 0.9) 0%,
            rgba(0, 136, 255, 0.5) 25%,
            rgba(0, 136, 255, 0.1) 55%,
            transparent 80%
          );
          transform: scale(0.7);
          opacity: 0.6;
        }
      }
      
      .velocity-half-circle-glow {
        position: relative !important;
        z-index: 0 !important;
      }
      
      .velocity-half-circle-glow::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        margin: 0%;
        background-position: center;
        z-index: -1;
        pointer-events: none;
        animation: veloHalfCircleGlow 1.5s infinite cubic-bezier(.25,.1,.25,1);
      }
      
      /* Add this after the existing animations in injectAnimationStyles() function */
      @keyframes veloTypingStopEase {
        0% {
          box-shadow: inset 0 0 12px rgba(0, 136, 255, 0.7);
          transform: scale(1.05);
          border-radius: 50%;
        }
        100% {
          box-shadow: inset 0 0 5px rgba(0, 136, 255, 0.4);
          transform: scale(1);
          border-radius: 50%;
        }
      }
      
      .velocity-typing-stop-ease {
        animation: veloTypingStopEase 2s cubic-bezier(0.22, 1, 0.36, 1); /* Increased from 0.8s to 2s for 1 more sec */
      }
      
      /* Also add SVG version of the ease effect */
      @keyframes veloSvgTypingStopEase {
        0% {
          filter: drop-shadow(0 0 8px rgba(0, 136, 255, 0.8));
          transform: scale(1.05);
        }
        100% {
          filter: drop-shadow(0 0 3px rgba(0, 136, 255, 0.5));
          transform: scale(1);
        }
      }         
      
      .velocity-svg-typing-stop-ease {
        animation: veloSvgTypingStopEase 2s cubic-bezier(0.22, 1, 0.36, 1); /* Increased from 0.8s to 2s for 1 more sec */
      }
      
      /* Multi-ring outward pulse animation for loading state - inspired by your image */
      @keyframes veloMultiRingPulse {
        0% {
          opacity: 1;
          transform: scale(1);
          border-width: 3px;
        }
        100% {
          opacity: 0;
          transform: scale(2);
          border-width: 1px;
        }
      }
      
      /* Multiple concentric rings animation */
      .velocity-multi-ring-container {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        border-radius: 50%;
        overflow: visible;
      }
      
      .velocity-multi-ring {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        border: 3px solid rgba(77, 171, 247, 0.8);
        box-sizing: border-box;
        opacity: 0;
      }
    `;
    document.head.appendChild(styleEl);
  }

  // Remove all message boxes
  function removeAllMessageBoxes() {
    const existingMsgs = document.querySelectorAll('.velocity-message-box, [data-velocity-message="true"]');
    existingMsgs.forEach(msg => {
      if (msg && msg.parentNode) {
        msg.parentNode.removeChild(msg);
      }
    });
    
    if (activeMessageTimer) {
      clearTimeout(activeMessageTimer);
      activeMessageTimer = null;
    }
    
    activeMessageBox = null;
  }

  // Create message boxes
  function createMessageBox(message, type = 'info', button, state = null) {
    if (state) {
      activeMessageState = state;
    }
    
    removeAllMessageBoxes();
    
    const msgBox = document.createElement('div');
    msgBox.className = 'velocity-message-box';
    msgBox.dataset.velocityMessage = "true";
    if (state) {
      msgBox.dataset.state = state;
    }
    
    activeMessageBox = msgBox;
    
    chrome.storage.local.get(["darkMode"], (result) => {
      const isDarkMode = result.darkMode === true;
      
      let bgColor, textColor, borderColor;
      
      if (isDarkMode) {
        switch(type) {
          case 'success':
            bgColor = '#082f49';
            textColor = '#e0f2fe';
            borderColor = '#0369a1';
            break;
          case 'warning':
            bgColor = '#78350f';
            textColor = '#fef3c7';
            borderColor = '#92400e';
            break;
          case 'info':
          default:
            bgColor = '#082f49';
            textColor = '#e0f2fe';
            borderColor = '#0369a1';
        }
      } else {
        switch(type) {
          case 'success':
            bgColor = '#e0f2fe';
            textColor = '#0369a1';
            borderColor = '#bae6fd';
            break;
          case 'warning':
            bgColor = '#fef3c7';
            textColor = '#92400e';
            borderColor = '#fde68a';
            break;
          case 'info':
          default:
            bgColor = '#e0f2fe';
            textColor = '#0369a1';
            borderColor = '#bae6fd';
        }
      }
      
      msgBox.style.cssText = `
        background-color: ${bgColor};
        color: ${textColor};
        border: 1px solid ${borderColor};
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        max-width: 220px;
        position: fixed;
        z-index: 999999;
        pointer-events: none;
        animation: fadeIn 0.3s ease-in-out;
        transform: translateZ(0);
      `;
      
      if (button) {
        updateMessageBoxPosition(msgBox, button);
      } else {
        msgBox.style.cssText += `
          bottom: 20px;
          left: 50%;
          transform: translateX(-50%);
        `;
      }
      
      msgBox.textContent = message;
      document.body.appendChild(msgBox);
    });
    
    return msgBox;
  }

  // Update message box position
  function updateMessageBoxPosition(msgBox, button) {
    if (!msgBox || !button) return;
    
    const rect = button.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;
    
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const messageWidth = 220;
    
    const styleProps = {
      backgroundColor: msgBox.style.backgroundColor,
      color: msgBox.style.color,
      border: msgBox.style.border
    };
    
    if (rect.right + messageWidth + 20 < viewportWidth) {
      msgBox.style.cssText = `
        background-color: ${styleProps.backgroundColor || '#e0f2fe'};
        color: ${styleProps.color || '#0369a1'};
        border: ${styleProps.border || '1px solid #bae6fd'};
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        max-width: ${messageWidth}px;
        position: fixed;
        z-index: 999999;
        pointer-events: none;
        animation: fadeIn 0.3s ease-in-out;
        transform: translateZ(0);
        left: ${rect.right + 15}px;
        top: ${Math.max(10, Math.min(viewportHeight - 70, rect.top))}px;
      `;
    }
    else if (rect.top > 80) {
      msgBox.style.cssText = `
        background-color: ${styleProps.backgroundColor || '#e0f2fe'};
        color: ${styleProps.color || '#0369a1'};
        border: ${styleProps.border || '1px solid #bae6fd'};
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        max-width: ${messageWidth}px;
        position: fixed;
        z-index: 999999;
        pointer-events: none;
        animation: fadeIn 0.3s ease-in-out;
        transform: translateZ(0);
        left: ${Math.max(10, Math.min(viewportWidth - messageWidth - 10, rect.left + (rect.width / 2) - (messageWidth / 2)))}px;
        top: ${rect.top - 60}px;
      `;
    }
    else if (rect.left > messageWidth + 20) {
      msgBox.style.cssText = `
        background-color: ${styleProps.backgroundColor || '#e0f2fe'};
        color: ${styleProps.color || '#0369a1'};
        border: ${styleProps.border || '1px solid #bae6fd'};
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        max-width: ${messageWidth}px;
        position: fixed;
        z-index: 999999;
        pointer-events: none;
        animation: fadeIn 0.3s ease-in-out;
        transform: translateZ(0); 
        left: ${rect.left - messageWidth - 15}px;
        top: ${Math.max(10, Math.min(viewportHeight - 70, rect.top))}px;
      `;
    }
    else {
      msgBox.style.cssText = `
        background-color: ${styleProps.backgroundColor || '#e0f2fe'};
        color: ${styleProps.color || '#0369a1'};
        border: ${styleProps.border || '1px solid #bae6fd'};
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        max-width: ${messageWidth}px;
        position: fixed;
        z-index: 999999;
        pointer-events: none;
        animation: fadeIn 0.3s ease-in-out;
        transform: translateZ(0);
        left: ${Math.max(10, Math.min(viewportWidth - messageWidth - 10, rect.left + (rect.width / 2) - (messageWidth / 2)))}px;
        top: ${rect.bottom + 10}px;
      `;
    }
  }

  // Idle state handling
  function startIdleTimer(button) {
    clearTimeout(idleTimer);
    clearInterval(idleShakeInterval);
    
    // Make sure half-circle glow is removed in idle state
    button.classList.remove('velocity-half-circle-glow');
    button.classList.remove('velocity-inner-to-outer-pulse', 'velocity-enhanced-inner-glow', 'velocity-inner-pulse-bounce');
    
    // Show welcome message on first detection
    if (!initialMessageShown) {
      setTimeout(() => {
        const welcomeMsg = createMessageBox("Hey I'm Velocity! I can help you to enhance your prompt.", 'info', button, 'welcome');
        initialMessageShown = true;
        
        activeMessageTimer = setTimeout(() => {
          if (welcomeMsg && welcomeMsg.parentNode) {
            welcomeMsg.parentNode.removeChild(welcomeMsg);
            activeMessageBox = null;
          }
        }, 5000);
      }, 1000);
    }
    
    // Start idle animations after IDLE_TIMEOUT (3sec)
    idleTimer = setTimeout(() => {
      button.classList.add('velocity-inner-pulse-bounce');
      
      const inputBox = window.currentInputBox || document.querySelector(platformConfig?.textAreaSelector);
      let inputHasContent = false;
      
      if (inputBox) {
        if (inputBox.tagName === "TEXTAREA") {
          inputHasContent = inputBox.value.trim().length > 0;
        } else if (inputBox.hasAttribute("contenteditable")) {
          inputHasContent = inputBox.innerText.trim().length > 0;
        }
      }
      
      if (!inputHasContent) {
        const msgBox = createMessageBox('Have a question? I can help optimize your prompt!', 'info', button, 'idle');
        
        activeMessageTimer = setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
            activeMessageBox = null;
          }
        }, 5000);
      }
      
      let pulseCount = 0;
      idleShakeInterval = setInterval(() => {
        pulseCount++;
        if (pulseCount % 2 === 0) {
          button.classList.add('velocity-inner-pulse-bounce');
          
          if (pulseCount % 2 === 0) {
            const inputBox = window.currentInputBox || document.querySelector(platformConfig?.textAreaSelector);
            let inputHasContent = false;
            
            if (inputBox) {
              if (inputBox.tagName === "TEXTAREA") {
                inputHasContent = inputBox.value.trim().length > 0;
              } else if (inputBox.hasAttribute("contenteditable")) {
                inputHasContent = inputBox.innerText.trim().length > 0;
              }
            }
            
            if (inputHasContent) {
              const msgBox = createMessageBox("Here I'm ready to enhance your prompt!", 'info', button, 'idleWhileTyping');
              
              activeMessageTimer = setTimeout(() => {
                if (msgBox && msgBox.parentNode) {
                  msgBox.parentNode.removeChild(msgBox);
                  activeMessageBox = null;
                }
              }, 3000);
            } else {
              const msgBox = createMessageBox('Have a question? I can help optimize your prompt!', 'info', button, 'idle');
              
              activeMessageTimer = setTimeout(() => {
                if (msgBox && msgBox.parentNode) {
                  msgBox.parentNode.removeChild(msgBox);
                  activeMessageBox = null;
                }
              }, 3000);
            }
          }
        } else {
          button.classList.remove('velocity-inner-pulse-bounce');
        }
      }, 5000);
    }, IDLE_TIMEOUT);
  }

  // Temporarily disable idle animations
  function temporarilyDisableIdleShake(duration = 10000) {
    clearTimeout(idleTimer);
    clearInterval(idleShakeInterval);
    
    const buttons = document.querySelectorAll('.custom-injected-button button');
    buttons.forEach(button => {
      button.classList.remove('velocity-inner-pulse-bounce');
    });
    
    removeAllMessageBoxes();
    
    idleDisableTimer = setTimeout(() => {
      const button = document.querySelector('.custom-injected-button button');
      if (button) {
        startIdleTimer(button);
      }
    }, duration);
  }

  // Create multiple concentric rings for wave-out effect
  function createMultiRingPulse(button) {
    // Remove any existing rings
    const existingRings = document.querySelector('.velocity-multi-ring-container');
    if (existingRings) {
      existingRings.remove();
    }
    
    const ringContainer = document.createElement('div');
    ringContainer.className = 'velocity-multi-ring-container';
    
    // Create multiple rings with staggered animations
    const numRings = 3;
    
    for (let i = 0; i < numRings; i++) {
      const ring = document.createElement('div');
      ring.className = 'velocity-multi-ring';
      
      // Apply the animation with delay based on ring index
      ring.style.animation = `veloMultiRingPulse 1.5s ${i * 0.5}s infinite ease-out`;
      
      ringContainer.appendChild(ring);
    }
    
    const buttonParent = button.parentNode;
    if (buttonParent) {
      buttonParent.style.position = 'relative';
      buttonParent.appendChild(ringContainer);
    }
    
    return ringContainer;
  }
  
  // Handle loading messages
  function showLoadingMessage(button, loadingMessages) {
    if (!button || !loadingMessages || !Array.isArray(loadingMessages) || loadingMessages.length === 0) {
      return null;
    }
    
    removeAllMessageBoxes();
    
    let currentIndex = 0;
    const message = loadingMessages[currentIndex];
    
    const msgBox = createMessageBox(message, 'info', button, 'loading');
    
    let lastButtonRect = button.getBoundingClientRect();
    
    const positionTracker = setInterval(() => {
      if (msgBox && msgBox.parentNode) {
        const currentRect = button.getBoundingClientRect();
        
        if (Math.abs(currentRect.left - lastButtonRect.left) > 2 || 
            Math.abs(currentRect.top - lastButtonRect.top) > 2) {
          
          updateMessageBoxPosition(msgBox, button);
          lastButtonRect = currentRect;
        }
      } else {
        clearInterval(positionTracker);
      }
    }, 100);
    
    const messageInterval = setInterval(() => {
      currentIndex = (currentIndex + 1) % loadingMessages.length;
      const nextMessage = loadingMessages[currentIndex];
      
      if (msgBox && msgBox.parentNode) {
        msgBox.textContent = nextMessage;
        updateMessageBoxPosition(msgBox, button);
      } else {
        const newMsgBox = createMessageBox(nextMessage, 'info', button, 'loading');
        if (newMsgBox) {
          return {
            messageBox: newMsgBox,
            interval: messageInterval,
            positionTracker: positionTracker,
            clear: function() {
              clearInterval(messageInterval);
              clearInterval(positionTracker);
              if (newMsgBox && newMsgBox.parentNode) {
                newMsgBox.parentNode.removeChild(newMsgBox);
                
                if (activeMessageBox === newMsgBox) {
                  activeMessageBox = null;
                }
              }
            }
          };
        }
      }
    }, 1500);
    
    return {
      messageBox: msgBox,
      interval: messageInterval,
      positionTracker: positionTracker,
      clear: function() {
        clearInterval(messageInterval);
        clearInterval(positionTracker);
        if (msgBox && msgBox.parentNode) {
          msgBox.parentNode.removeChild(msgBox);
          
          if (activeMessageBox === msgBox) {
            activeMessageBox = null;
          }
        }
      }
    };
  }
  
  // Track button positions
  function setupGlobalButtonTracking() {
    function updateAllMessagePositions() {
      const buttons = document.querySelectorAll('.custom-injected-button button');
      const messageBoxes = document.querySelectorAll('.velocity-message-box, [data-velocity-message="true"]');
      
      if (!messageBoxes.length) return;
      
      buttons.forEach(button => {
        messageBoxes.forEach(msgBox => {
          if (msgBox.parentNode && msgBox.style.opacity !== "0") {
            updateMessageBoxPosition(msgBox, button);
          }
        });
      });
    }
    
    window.addEventListener('resize', updateAllMessagePositions);
    window.addEventListener('scroll', updateAllMessagePositions);
    
    if ('ResizeObserver' in window) {
      const observer = new ResizeObserver(updateAllMessagePositions);
      document.body && observer.observe(document.body);
    }
    
    return {
      update: updateAllMessagePositions
    };
  }
  
  // Initialize global position tracking
  const globalPositionTracker = setupGlobalButtonTracking();

  // Handle typing detection
  function setupTypingDetection(inputElement, button) {
    if (!inputElement || !button) return;
    
    // Start idle timer with welcome message
    startIdleTimer(button);
    
    // Ensure half-circle glow is removed at startup
    button.classList.remove('velocity-half-circle-glow');
    
    inputElement.addEventListener('input', () => {
      clearTimeout(typingTimer);
      clearTimeout(idleTimer);
      clearInterval(idleShakeInterval);
      
      button.classList.remove('velocity-inner-pulse-bounce');
      
      if (!isTyping) {
        isTyping = true;
        button.classList.remove('velocity-enhanced-inner-glow');        // Only add half-circle glow during actual typing
        button.classList.add('velocity-half-circle-glow');
        
        removeAllMessageBoxes();
      }
      
      typingTimer = setTimeout(() => {
        isTyping = false;
        // Immediately remove the half-circle glow when typing stops
        button.classList.remove('velocity-half-circle-glow');
        
        // Add the new ease-out animation when typing stops
        button.classList.add('velocity-typing-stop-ease');
        
        // Show message box immediately when typing stops
        const msgBox = createMessageBox(
          'Once you are done typing, click the button to enhance your prompt!', 
          'info', 
          button, 
          'typingStopped'
        );
        
        // Set a message timer to auto-hide after 2 seconds
        activeMessageTimer = setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
            activeMessageBox = null;
          }
        }, 2000); // Show message for 2 seconds when typing stops
        
        // After the ease animation completes, transition to enhanced inner glow
        setTimeout(() => {
          button.classList.remove('velocity-typing-stop-ease');
          button.classList.add('velocity-enhanced-inner-glow');
          
          // After enhanced glow animation completes (1.5s duration)
          setTimeout(() => {
            button.classList.remove('velocity-enhanced-inner-glow');
            
            // Start idle timer 
            idleTimer = setTimeout(() => {
              startIdleTimer(button);
            }, IDLE_TIMEOUT);
          }, 1500);
        }, 2000); // Increased from 800ms to 2000ms to match animation duration
      }, TYPING_TIMEOUT);
    });
    
    // Add click animation
    button.addEventListener('mousedown', () => {
      // Explicitly remove half-circle glow on mouse down
      button.classList.remove('velocity-half-circle-glow');
      button.classList.add('velocity-press-outward-wave');
      
      // We no longer remove the press-outward-wave animation here
      // Let it continue until the success state or until explicitly removed
    });
  }

  // Handle button states
  function handleButtonStates(button) {
    button.addEventListener('click', () => {
      const inputBox = window.currentInputBox || document.querySelector(platformConfig?.textAreaSelector);
      let inputHasContent = false;
      
      if (inputBox) {
        if (inputBox.tagName === "TEXTAREA") {
          inputHasContent = inputBox.value.trim().length > 0;
        } else if (inputBox.hasAttribute("contenteditable")) {
          inputHasContent = inputBox.innerText.trim().length > 0;
        }
      }
      
      if (!inputHasContent) {
        const msgBox = createMessageBox('Please enter some text before enhancing!', 'warning', button);
        
        activeMessageTimer = setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
            activeMessageBox = null;
          }
        }, 3000);
        
        return;
      }
      
      // Force cancel any typing timers
      clearTimeout(typingTimer);
      isTyping = false;
      
      removeAllMessageBoxes();
      
      // Explicitly remove half-circle glow when button is clicked
      document.querySelectorAll('.velocity-half-circle-glow').forEach(el => {
        el.classList.remove('velocity-half-circle-glow');
      });
      
      button.classList.remove('velocity-half-circle-glow');
      button.classList.remove('velocity-inner-to-outer-pulse');
      button.classList.remove('velocity-enhanced-inner-glow');
      button.classList.remove('velocity-inner-pulse-bounce');
      
      // Apply outward wave effect on button press
      button.classList.add('velocity-press-outward-wave');
      
      // Show processing message
      const msgBox = createMessageBox('Enhancing your prompt...', 'info', button, 'buttonPressed');
      
      // Set timeout to remove message
      activeMessageTimer = setTimeout(() => {
        if (msgBox && msgBox.parentNode) {
          msgBox.parentNode.removeChild(msgBox);
          activeMessageBox = null;
        }
      }, 2000);
      
      // Add processing state effects
      const innerDiv = button.querySelector('div');
      if (innerDiv) {
        innerDiv.classList.add('velocity-rotate');
      }
      
      // Create multi-ring pulse animation for loading state - similar to the provided image
      const multiRingContainer = createMultiRingPulse(button);
      
      // IMPORTANT: We remove the timeout that was stopping the outward wave animation
      // Now the outward wave animation will continue during the entire loading phase
    });
    
    // Success state function
    window.markPromptSuccess = function() {
      // Explicitly remove half-circle glow on success from all elements
      document.querySelectorAll('.velocity-half-circle-glow').forEach(el => {
        el.classList.remove('velocity-half-circle-glow');
      });
      
      button.classList.remove('velocity-half-circle-glow');
      
      // IMPORTANT: Remove the press-outward-wave animation here when loading completes
      button.classList.remove('velocity-press-outward-wave');
      
      const innerDiv = button.querySelector('div');
      if (innerDiv) {
        innerDiv.classList.remove('velocity-rotate');
      }
      
      // Remove processing animations
      const multiRingContainer = document.querySelector('.velocity-multi-ring-container');
      if (multiRingContainer) {
        multiRingContainer.remove();
      }
      
      if (button.loadingHandler) {
        button.loadingHandler.clear();
        button.loadingHandler = null;
      }
      
      if (button.loadingMessageHandler) {
        button.loadingMessageHandler.clear();
        button.loadingMessageHandler = null;
      }
      
      removeAllMessageBoxes();
      
      if (innerDiv) {
        innerDiv.classList.add('velocity-success-reverse');
      }
      
      button.classList.add('velocity-finish-wave-reverse');
      
      const msgBox = createMessageBox('Please Answer the question to enhance your prompt!', 'success', button, 'enhanced');
      
      activeMessageTimer = setTimeout(() => {
        if (msgBox && msgBox.parentNode) {
          msgBox.parentNode.removeChild(msgBox);
          activeMessageBox = null;
        }
      }, 3000);
      
      setTimeout(() => {
        if (innerDiv) {
          innerDiv.classList.remove('velocity-success-reverse');
        }
        
        button.classList.remove('velocity-finish-wave-reverse');
        
        temporarilyDisableIdleShake(10000);
      }, 1000);
    };
  }

  // Initialize animations
  function initButtonAnimations(platformConfig) {
    if (!platformConfig || !platformConfig.textAreaSelector) return;
    
    injectAnimationStyles();
    
    removeAllMessageBoxes();
    
    initialMessageShown = false;
    
    const observer = new MutationObserver(() => {
      const button = document.querySelector('.custom-injected-button button');
      const inputBox = document.querySelector(platformConfig.textAreaSelector);
      
      if (button && inputBox) {
        setupTypingDetection(inputBox, button);
        handleButtonStates(button);
        observer.disconnect();
        
        removeAllMessageBoxes();
        
        setTimeout(() => {
          if (button && !initialMessageShown) {
            const welcomeMsg = createMessageBox("Hey I'm Velocity! I can help you to enhance your prompt.", 'info', button, 'welcome');
            initialMessageShown = true;
            
            activeMessageTimer = setTimeout(() => {
              if (welcomeMsg && welcomeMsg.parentNode) {
                welcomeMsg.parentNode.removeChild(welcomeMsg);
                activeMessageBox = null;
              }
              
              startIdleTimer(button);
            }, 5000);
          } else {
            startIdleTimer(button);
          }
        }, 1000);
      }
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // Export to window
  window.velocityAnimations = {
    initButtonAnimations,
    injectAnimationStyles,
    createMessageBox,
    temporarilyDisableIdleShake,
    createMultiRingPulse,
    showLoadingMessage,
    updateMessageBoxPosition,
    updateAllPositions: function() {
      if (globalPositionTracker) {
        globalPositionTracker.update();
      }
    },
    forceShowMessage: function(message, type, button, duration) {
      removeAllMessageBoxes();
      
      const msgBox = createMessageBox(message, type || 'info', button);
      if (msgBox) {
        setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
            activeMessageBox = null;
          }
        }, duration || 3000);
      }
      return msgBox;
    },
    restartMessageCycle: function(button) {
      if (button) {
        clearTimeout(idleTimer);
        clearInterval(idleShakeInterval);
        removeAllMessageBoxes();
        startIdleTimer(button);
      }
    },
    removeAllMessageBoxes: removeAllMessageBoxes
  };
})();

// SVG Pulse Effect Module - For inner SVG animations
(function() {
  // Initialize SVG pulse effect for typing
  function initSvgPulseEffect(platformConfig, svgContainer) {
    if (!platformConfig || !platformConfig.textAreaSelector || !svgContainer) return;
  
    // Add required styles if not present
    if (!document.getElementById('velocity-svg-pulse-styles')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'velocity-svg-pulse-styles';
      styleEl.innerHTML = `
        /* SVG typing center glow - updated to inside-to-outward */
        @keyframes veloSvgTypingGlow {
          0% {
            filter: drop-shadow(0 0 0 rgba(0, 0, 255, 0.4)); /* Blue start */
            transform: scale(1);
          }
          50% {
            filter: drop-shadow(0 0 10px rgba(255, 0, 0, 0.8)); /* Red outward */
            transform: scale(1.2);
          }
          100% {
            filter: drop-shadow(0 0 0 rgba(0, 0, 255, 0.4)); /* Back to blue */
            transform: scale(1);
          }
        }
        
        /* SVG idle pulse with enhanced bounce */
        @keyframes veloSvgIdlePulseAndBounce {
          0% {
            filter: drop-shadow(0 0 2px rgba(0, 173, 255, 0.4));
            transform: scale(1) translateY(0);
          }
          40% {
            filter: drop-shadow(0 0 5px rgba(0, 173, 255, 0.7));
            transform: scale(1.05) translateY(-3px);
          }
          60% {
            filter: drop-shadow(0 0 4px rgba(0, 173, 255, 0.6));
            transform: scale(1.02) translateY(0);
          }
          80% {
            filter: drop-shadow(0 0 3px rgba(0, 173, 255, 0.5));
            transform: scale(1.01) translateY(-1px);
          }
          100% {
            filter: drop-shadow(0 0 2px rgba(0, 173, 255, 0.4));
            transform: scale(1) translateY(0);
          }
        }
        
        /* SVG enhanced inner glow after typing */
        @keyframes veloSvgEnhancedInnerGlow {
          0% {
            filter: drop-shadow(0 0 2px rgba(0, 173, 255, 0.4));
            transform: scale(1);
          }
          50% {
            filter: drop-shadow(0 0 8px rgba(0, 173, 255, 0.9));
            transform: scale(1.08);
          }
          100% {
            filter: drop-shadow(0 0 2px rgba(0, 173, 255, 0.4));
            transform: scale(1);
          }
        }
        
        /* Updated SVG press outward wave with bounce effect */
        @keyframes veloSvgButtonPressOutwardWave {
          0% { 
            filter: drop-shadow(0 0 3px rgba(0, 136, 255, 0.5));
            transform: scale(1) translateY(0);
          }
          25% {
            filter: drop-shadow(0 0 5px rgba(0, 136, 255, 0.4));
            transform: scale(0.95) translateY(2px);
          }
          50% {
            filter: drop-shadow(0 0 10px rgba(0, 136, 255, 0.3));
            transform: scale(1.05) translateY(-3px);
          }
          75% {
            filter: drop-shadow(0 0 7px rgba(0, 136, 255, 0.2));
            transform: scale(1.02) translateY(-1px);
          }
          100% {
            filter: drop-shadow(0 0 8px rgba(0, 136, 255, 0.4));
            transform: scale(1) translateY(0);
          }
        }
        
        .velocity-svg-press-outward-wave {
          animation: veloSvgButtonPressOutwardWave 1.5s infinite ease-out;
        }
        
        /* Success wave for SVG */
        @keyframes veloSvgSuccessWaveReverse {
          0% {
            filter: drop-shadow(0 0 8px rgba(0, 136, 255, 0.7));
            transform: scale(1.1);
          }
          50% {
            filter: drop-shadow(0 0 2px rgba(0, 136, 255, 0.4));
            transform: scale(1);
          }
          100% {
            filter: drop-shadow(0 0 8px rgba(0, 136, 255, 0.7));
            transform: scale(1.1);
          }
        }
        
        .velocity-svg-success-wave-reverse {
          animation: veloSvgSuccessWaveReverse 1.5s ease-in-out;
        }
        
        .velocity-svg-typing-glow {
          animation: veloSvgTypingGlow 1s infinite cubic-bezier(.45,.05,.55,.95);
        }
        
        .velocity-svg-idle-pulse-bounce {
          animation: veloSvgIdlePulseAndBounce 2s infinite cubic-bezier(.36,.07,.19,.97);
        }
        
        .velocity-svg-enhanced-inner-glow {
          animation: veloSvgEnhancedInnerGlow 1.5s ease-in-out;
        }
        
        /* Added multi-ring wave effect for SVG loading state */
        @keyframes veloSvgMultiRingWave {
          0% {
            filter: drop-shadow(0 0 2px rgba(77, 171, 247, 0.8));
            transform: scale(1);
          }
          100% {
            filter: drop-shadow(0 0 15px rgba(77, 171, 247, 0));
            transform: scale(1.3);
          }
        }
        
        .velocity-svg-multi-ring-wave {
          animation: veloSvgMultiRingWave 1.5s infinite ease-in-out;
        }
      `;
      document.head.appendChild(styleEl);
    }
  
    // Find the input box
    const inputBox = document.querySelector(platformConfig.textAreaSelector);
    if (!inputBox) return;
  
    let typingTimer;
    let idleTimer;
    const TYPING_TIMEOUT = 2500; // Changed to match main animations
    const IDLE_TIMEOUT = 3000; // Changed to match main animations
    let isTyping = false;
    let initialWelcomeShown = false;
  
    // Find the button element (parent of svgContainer)
    const button = svgContainer.closest('button') || svgContainer.parentNode.closest('button');
    
    // Find SVG elements in the container
    const svgElements = svgContainer.querySelectorAll('svg, path, g');
    
    // Message refresh interval for repeated messages
    let messageRefreshInterval = null;
    
    // Start idle animations with inner pulse + bounce effect
    function startSvgIdleEffects() {
      // Add idle pulse + bounce effect to SVG elements
      svgElements.forEach(el => {
        el.classList.remove('velocity-svg-typing-glow', 'velocity-svg-enhanced-inner-glow', 'velocity-svg-success-wave-reverse', 'velocity-svg-multi-ring-wave', 'velocity-svg-press-outward-wave');
        el.classList.add('velocity-svg-idle-pulse-bounce');
      });
      
      // Clear any existing message refresh interval
      if (messageRefreshInterval) {
        clearInterval(messageRefreshInterval);
      }
      
      // Make sure any existing messages are removed
      if (window.velocityAnimations && window.velocityAnimations.removeAllMessageBoxes) {
        window.velocityAnimations.removeAllMessageBoxes();
      }
      
      // Show initial welcome message if not shown yet
      if (!initialWelcomeShown && window.velocityAnimations && window.velocityAnimations.createMessageBox) {
        const welcomeMsg = window.velocityAnimations.createMessageBox(
          'Hey I am velocity! I can help you to enhance your prompt.', 
          'info', 
          button, 
          'welcome'
        );
        
        initialWelcomeShown = true;
        
        // Auto-hide welcome message after 5 seconds
        setTimeout(() => {
          if (welcomeMsg && welcomeMsg.parentNode) {
            welcomeMsg.parentNode.removeChild(welcomeMsg);
            if (window.velocityAnimations) {
              window.velocityAnimations.activeMessageBox = null;
            }
          }
        }, 5000);
      }
      
      // Set up a recurring interval to show messages
      messageRefreshInterval = setInterval(() => {
        // Check if input box has content
        let inputHasContent = false;
        if (inputBox) {
          if (inputBox.tagName === "TEXTAREA") {
            inputHasContent = inputBox.value.trim().length > 0;
          } else if (inputBox.hasAttribute("contenteditable")) {
            inputHasContent = inputBox.innerText.trim().length > 0;
          }
        }
        
        if (window.velocityAnimations && window.velocityAnimations.createMessageBox) {
          if (!inputHasContent) {
            // Show idle message only when input is empty
            const msgBox = window.velocityAnimations.createMessageBox('Have a question? I can help optimize your prompt!', 'info', button, 'idle');
            
            setTimeout(() => {
              if (msgBox && msgBox.parentNode) {
                msgBox.parentNode.removeChild(msgBox);
                if (window.velocityAnimations) {
                  window.velocityAnimations.activeMessageBox = null;
                }
              }
            }, 3000);
          } else {
            // Show typing idle message when input has content
            const msgBox = window.velocityAnimations.createMessageBox("Here I'm ready to enhance your prompt!", 'info', button, 'idleWhileTyping');
            
            setTimeout(() => {
              if (msgBox && msgBox.parentNode) {
                msgBox.parentNode.removeChild(msgBox);
                if (window.velocityAnimations) {
                  window.velocityAnimations.activeMessageBox = null;
                }
              }
            }, 3000);
          }
        }
      }, 5000);
    }
    
    // Show welcome message immediately after initialization
    setTimeout(() => {
      if (!initialWelcomeShown && window.velocityAnimations && window.velocityAnimations.createMessageBox) {
        const welcomeMsg = window.velocityAnimations.createMessageBox(
          'Hey I am velocity! I can help you to enhance your prompt.', 
          'info', 
          button, 
          'welcome'
        );
        
        initialWelcomeShown = true;
        
        setTimeout(() => {
          if (welcomeMsg && welcomeMsg.parentNode) {
            welcomeMsg.parentNode.removeChild(welcomeMsg);
            if (window.velocityAnimations) {
              window.velocityAnimations.activeMessageBox = null;
            }
          }
        }, 5000);
      }
    }, 1000);
    
    // Start idle timer
    idleTimer = setTimeout(() => {
      startSvgIdleEffects();
    }, IDLE_TIMEOUT);
    
    // Handle typing detection with faster center glow
    inputBox.addEventListener('input', () => {
      clearTimeout(typingTimer);
      clearTimeout(idleTimer);
      
      // Clear message refresh interval
      if (messageRefreshInterval) {
        clearInterval(messageRefreshInterval);
        messageRefreshInterval = null;
      }
      
      // Remove any active messages
      if (window.velocityAnimations && window.velocityAnimations.removeAllMessageBoxes) {
        window.velocityAnimations.removeAllMessageBoxes();
      }
      
      // Remove idle effects
      svgElements.forEach(el => {
        el.classList.remove('velocity-svg-idle-pulse-bounce', 'velocity-svg-enhanced-inner-glow', 'velocity-svg-success-wave-reverse', 'velocity-svg-multi-ring-wave', 'velocity-svg-press-outward-wave');
      });
      
      // Add faster typing center glow
      if (!isTyping) {
        isTyping = true;
        
        // Add typing glow effect to SVG elements
        svgElements.forEach(el => {
          el.classList.add('velocity-svg-typing-glow');
        });
      }
      
      // Set a timer to detect when user stops typing
      typingTimer = setTimeout(() => {
        // User stopped typing
        isTyping = false;
        
        // Remove typing animations
        svgElements.forEach(el => {
          el.classList.remove('velocity-svg-typing-glow');
          // Add the ease-out effect when typing stops
          el.classList.add('velocity-svg-typing-stop-ease');
        });
        
        // Show message immediately after stopping typing
        if (window.velocityAnimations && window.velocityAnimations.createMessageBox) {
          const msgBox = window.velocityAnimations.createMessageBox(
            'Once you are done typing, click the button to enhance your prompt!', 
            'info', 
            button, 
            'typingStopped'
          );
          
          // Auto-hide message after 2 seconds
          setTimeout(() => {
            if (msgBox && msgBox.parentNode) {
              msgBox.parentNode.removeChild(msgBox);
              if (window.velocityAnimations) {
                window.velocityAnimations.activeMessageBox = null;
              }
            }
          }, 2000);
        }
        
        // After ease animation completes, transition to enhanced inner glow
        setTimeout(() => {
          svgElements.forEach(el => {
            el.classList.remove('velocity-svg-typing-stop-ease');
            el.classList.add('velocity-svg-enhanced-inner-glow');
          });
          
          // After enhanced glow animation completes
          setTimeout(() => {
            svgElements.forEach(el => {
              el.classList.remove('velocity-svg-enhanced-inner-glow');
            });
            
            // Restart idle effects after a delay
            idleTimer = setTimeout(() => {
              if (!isTyping) {
                startSvgIdleEffects();
              }
            }, IDLE_TIMEOUT);
          }, 1500);
        }, 2000); // Increased to 2s to match main animations
      }, TYPING_TIMEOUT);
    });
    
    // Handle button click - apply press outward wave effect plus rotation
    if (button) {
      button.addEventListener('click', () => {
        // Clear all SVG animations when button is clicked
        clearTimeout(typingTimer);
        clearTimeout(idleTimer);
        
        // Clear message refresh interval
        if (messageRefreshInterval) {
          clearInterval(messageRefreshInterval);
          messageRefreshInterval = null;
        }
        
        // Remove any active messages
        if (window.velocityAnimations && window.velocityAnimations.removeAllMessageBoxes) {
          window.velocityAnimations.removeAllMessageBoxes();
        }
        
        // Apply loading state animations - press outward wave and rotation
        svgElements.forEach(el => {
          el.classList.remove('velocity-svg-idle-pulse-bounce', 'velocity-svg-typing-glow', 'velocity-svg-enhanced-inner-glow', 'velocity-svg-success-wave-reverse', 'velocity-svg-multi-ring-wave');
          // Add both press outward wave and rotation
          el.classList.add('velocity-svg-press-outward-wave');
          el.classList.add('velocity-rotate');
        });
        
        // We don't remove the press-outward-wave class until success/loading completes
      });
    }
    
    // Add reversed success animation for SVG
    window.addSvgSuccessAnimation = function() {
      // Clear all other animations
      svgElements.forEach(el => {
        // Remove press outward wave when success state is reached
        el.classList.remove('velocity-svg-idle-pulse-bounce', 'velocity-svg-typing-glow', 'velocity-svg-enhanced-inner-glow', 'velocity-svg-multi-ring-wave', 'velocity-rotate', 'velocity-svg-press-outward-wave');
        el.classList.add('velocity-svg-success-wave-reverse');
      });
      
      // Clear message refresh interval
      if (messageRefreshInterval) {
        clearInterval(messageRefreshInterval);
        messageRefreshInterval = null;
      }
      
      // Remove any active messages
      if (window.velocityAnimations && window.velocityAnimations.removeAllMessageBoxes) {
        window.velocityAnimations.removeAllMessageBoxes();
      }
      
      // Show success message using the centralized system
      if (window.velocityAnimations && window.velocityAnimations.createMessageBox) {
        const msgBox = window.velocityAnimations.createMessageBox('Here is your enhanced prompt!', 'success', button, 'enhanced');
        
        setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
            if (window.velocityAnimations) {
              window.velocityAnimations.activeMessageBox = null;
            }
          }
        }, 2000);
      }
      
      // Remove success animations after they complete
      setTimeout(() => {
        svgElements.forEach(el => {
          el.classList.remove('velocity-svg-success-wave-reverse');
        });
        
        // Restart idle effects and messages after a short delay
        setTimeout(() => {
          startSvgIdleEffects();
        }, 5000);
      }, 1500);
    };
  }
  
  // Expose to window
  window.velocitySvgPulse = {
    initSvgPulseEffect
  };
})();