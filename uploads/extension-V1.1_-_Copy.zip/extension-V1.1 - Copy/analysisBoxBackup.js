function createAnalysisBox() {
  const analysisBox = document.createElement("div");
  analysisBox.classList.add("velocity-analysis-box");

  // Add draggable styles
  const baseStyles = `
    position: fixed;
    z-index: 99999;
    cursor: move;
    user-select: none;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
  `;

  // Platform-specific styles
  const platformStyles = {
    chatgpt: {
      position: "bottom",
      boxCss: `
        width: 230px;
        background-color: white;
        color: black;
        padding: 16px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: -30px;
      `,
      sectionTitleCss: `
        color: #374151;
        font-weight: 600;
        font-size: 15px;
        text-align: center;
      `,
      sectionContentCss: `
        color: #4B5563;
      `,
      closeButtonCss: `
        color: #666;
      `,
    },
    claude: {
      position: "bottom",
      boxCss: `
        width: 250px;
        background-color: white;
        color: black;
        padding: 16px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        border: 1px solid #d1d5db;
        margin-bottom: -5px;
      `,
      sectionTitleCss: `
        color: #111827;
        font-weight: 500;
      `,
      sectionContentCss: `
        color: #374151;
      `,
      closeButtonCss: `
        color: #4B5563;
      `,
    },
    gemini: {
      position: "bottom",
      boxCss: `
        width: 170px;
        background-color: white;
        color: black;
        padding: 16px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: -8px;
        border: 1px solid #e5e7eb;
      `,
      sectionTitleCss: `
        color: #202124;
        font-weight: 600;
        text-align: left;
      `,
      sectionContentCss: `
        color: #5f6368;
        text-align: left;
      `,
      closeButtonCss: `
        color: #5f6368;
      `,
    },
    default: {
      position: "bottom",
      boxCss: `
        background-color: white;
        color: black;
        padding: 16px;
        box-shadow: 0 10px 15px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 8px;
      `,
      sectionTitleCss: `
        color: #374151;
        font-weight: 600;
      `,
      sectionContentCss: `
        color: #4B5563;
      `,
      closeButtonCss: `
        color: #666;
      `,
    },
  };

  // Get current platform
  const currentURL = window.location.href;
  const platformKey = Object.keys(window.platforms).find((key) =>
    window.platforms[key].urlPattern.test(currentURL)
  );
  const styles = platformStyles[platformKey] || platformStyles.default;

  // Combine base styles with platform-specific styles
  analysisBox.style.cssText = `
    ${baseStyles}
    ${styles.boxCss}
    z-index: 99999;
    opacity: 0;  // Start hidden
    pointer-events: none;  // Disable interactions when hidden
    visibility: hidden;  // Hide completely when not in use
  `;

  // Initialize position variables
  let isDragging = false;
  let currentX = window.innerWidth - 250; // Initialize to right side
  let currentY = window.innerHeight / 2; // Initialize to center
  let initialX;
  let initialY;
  let xOffset = window.innerWidth - 250; // Set initial X offset to right side
  let yOffset = window.innerHeight / 2 - 100; // Adjust Y offset to account for box height

  function dragStart(e) {
    if (e.target.tagName === "BUTTON") return;

    isDragging = true;

    if (e.type === "touchstart") {
      initialX = e.touches[0].clientX - xOffset;
      initialY = e.touches[0].clientY - yOffset;
    } else {
      initialX = e.clientX - xOffset;
      initialY = e.clientY - yOffset;
    }
  }

  function drag(e) {
    if (!isDragging) return;

    e.preventDefault();

    if (e.type === "touchmove") {
      currentX = e.touches[0].clientX - initialX;
      currentY = e.touches[0].clientY - initialY;
    } else {
      currentX = e.clientX - initialX;
      currentY = e.clientY - initialY;
    }

    xOffset = currentX;
    yOffset = currentY;

    analysisBox.style.transform = `translate(0, 0)`; // Remove the initial centering transform
    analysisBox.style.left = `${currentX}px`;
    analysisBox.style.top = `${currentY}px`;
  }

  function dragEnd() {
    initialX = currentX;
    initialY = currentY;
    isDragging = false;
  }

  // Add event listeners for both mouse and touch events
  analysisBox.addEventListener("mousedown", dragStart, false);
  analysisBox.addEventListener("touchstart", dragStart, false);
  document.addEventListener("mousemove", drag, false);
  document.addEventListener("touchmove", drag, false);
  document.addEventListener("mouseup", dragEnd, false);
  document.addEventListener("touchend", dragEnd, false);

  // Store initial position when the box becomes visible
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === "style" && analysisBox.style.opacity === "1") {
        const rect = analysisBox.getBoundingClientRect();
        currentX = rect.left;
        currentY = rect.top;
      }
    });
  });

  observer.observe(analysisBox, {
    attributes: true,
    attributeFilter: ["style"],
  });

  // Add close button
  const closeButton = document.createElement("button");
  closeButton.innerHTML = "×";
  closeButton.style.cssText = `
    position: absolute;
    top: 8px;
    right: 8px;
    background: none;
    border: none;
    font-size: 20px;
    cursor: pointer;
    padding: 4px;
    line-height: 1;
    ${styles.closeButtonCss}
  `;
  closeButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    hideAnalysisBox();
  });
  closeButton.type = "button";
  analysisBox.appendChild(closeButton);

  // Create sections for each analysis component
  const createSection = (title, content) => {
    const section = document.createElement("div");
    section.style.marginBottom = "12px";

    const titleElement = document.createElement("div");
    titleElement.textContent = title;
    titleElement.style.cssText = `
      margin-bottom: 4px;
      ${styles.sectionTitleCss}
    `;

    const contentElement = document.createElement("div");
    contentElement.innerHTML = content;
    contentElement.style.cssText = `
      ${styles.sectionContentCss}
      white-space: pre-line;
      line-height: 1.2;
    `;

    section.appendChild(titleElement);
    section.appendChild(contentElement);
    return section;
  };

  const hideAnalysisBox = () => {
    analysisBox.style.opacity = "0";
    analysisBox.style.pointerEvents = "none";
    analysisBox.style.visibility = "hidden";
  };

  // Method to update content
  analysisBox.updateContent = (data) => {
    // Clear previous content except close button
    while (analysisBox.childNodes.length > 1) {
      analysisBox.removeChild(analysisBox.lastChild);
    }

    const sections = [
      {
        title: "User Prompt Analysis",
        content: [
          `Clarity: ${createProgressBar(data.analysis.clarity)}`,
          `Completeness: ${createProgressBar(data.analysis.completeness)}`,
          `Effectiveness: ${createProgressBar(data.analysis.effectiveness)}`,
          `Specificity: ${createProgressBar(data.analysis.specificity)}`,
        ].join("\n"),
      },
      { title: "Recommendation", content: data.analysis.recommendation },
    ];

    sections.forEach((section) => {
      analysisBox.appendChild(createSection(section.title, section.content));
    });

    // Show the analysis box
    analysisBox.style.opacity = "1";
    analysisBox.style.pointerEvents = "auto";
    analysisBox.style.visibility = "visible";

    // Initialize position if not already set
    if (!xOffset && !yOffset) {
      const rect = analysisBox.getBoundingClientRect();
      xOffset = window.innerWidth - 250 - rect.width;
      yOffset = window.innerHeight / 2 - rect.height / 2;
      analysisBox.style.transform = `translate(0, 0)`;
      analysisBox.style.left = `${xOffset}px`;
      analysisBox.style.top = `${yOffset}px`;
    }

    // Add input detection to hide box when user makes significant changes
    const platform = window.platforms[platformKey] || {};
    if (platform.textAreaSelector) {
      const textArea = document.querySelector(platform.textAreaSelector);
      if (textArea) {
        let initialContent = textArea.value || textArea.innerText || "";
        let changeThreshold = 10; // Number of characters that need to change

        const inputHandler = () => {
          const currentContent = textArea.value || textArea.innerText || "";
          const contentDiff = Math.abs(
            currentContent.length - initialContent.length
          );

          if (contentDiff >= changeThreshold) {
            hideAnalysisBox();
            // Remove the listener after significant change
            textArea.removeEventListener("input", inputHandler);
          }
        };

        textArea.addEventListener("input", inputHandler);
      }
    }
  };

  return analysisBox;
}

function createProgressBar(value) {
  // Calculate percentage based on value out of 10
  const percentage = Math.round((value / 10) * 100);
  // Calculate color based on value
  let color;
  if (value <= 3) {
    color = "#ef4444"; // Red
  } else if (value <= 7) {
    color = "#fbbf24"; // Yellow
  } else {
    color = "#22c55e"; // Green
  }

  return `\n<div style="
    display: inline-block;
    width: 150px;
    height: 8px;
    background: #e5e7eb;
    border-radius: 4px;
    margin: 0 8px;
    overflow: hidden;
  "><div style="
    width: ${percentage}%;
    height: 100%;
    background: ${color};
    border-radius: 4px;
    transition: width 0.3s ease;
  "></div></div>${value * 10}%`;
}

// Attach function to window so it can be accessed in content scripts
window.createAnalysisBox = createAnalysisBox;
