// (function () {
//   console.log("Content script injected on thinkvelocity.in");

//   function sendUserData() {
//     const token = localStorage.getItem("token");
//     const userName = localStorage.getItem("userName");
//     const userId = localStorage.getItem("userId");
//     const userEmail = localStorage.getItem("userEmail");

//     if (token && userName && userId && userEmail) {
//       chrome.runtime.sendMessage(
//         { action: "storeUserData", token, userName, userId, userEmail },
//         (response) => {
//           console.log("User data sent to background:", response);
//         }
//       );
//     }
//   }

//   // Run immediately
//   sendUserData();

//   // Watch for changes in localStorage
//   window.addEventListener("storage", () => {
//     console.log("LocalStorage changed, updating...");
//     sendUserData();
//   });
// })();
