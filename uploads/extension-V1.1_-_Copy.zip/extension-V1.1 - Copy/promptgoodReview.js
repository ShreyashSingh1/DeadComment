// promptGoodReview.js - Simple metrics display with dragging functionality

// Single global instance to prevent duplicates
let promptGoodReviewInstance = null;

// Add these constants at the top of the file after the existing let promptGoodReviewInstance declaration
const dimensions = {
  containerWidth: '60px',
  containerHeight: '60px',
  center: { x: 30, y: 30 },
  radius: 28,
  numberOfDashes: 20,
  viewBox: '0 0 60 60',
  valueSize: '20px',
  labelSize: '12px'
};

function createProgressIndicator(value, maxValue, color, label, isDarkMode) {
  const getValueColor = (val) => {
    if (val <= 3) return '#EF4444';
    if (val <= 7) return '#EAB308';
    return '#22C55E';
  };

  let dashes = '';
  for (let i = 0; i < dimensions.numberOfDashes; i++) {
    const angle = (Math.PI * i) / (dimensions.numberOfDashes - 1);
    const x1 = dimensions.center.x + (dimensions.radius - 4) * Math.cos(angle);
    const y1 = dimensions.center.y + (dimensions.radius - 4) * Math.sin(angle);
    const x2 = dimensions.center.x + dimensions.radius * Math.cos(angle);
    const y2 = dimensions.center.y + dimensions.radius * Math.sin(angle);

    const progress = value / maxValue;
    const isActive = i / (dimensions.numberOfDashes - 1) <= progress;

    dashes += `
      <line
        x1="${x1}"
        y1="${y1}"
        x2="${x2}"
        y2="${y2}"
        stroke="${isActive ? getValueColor(value) : (isDarkMode ? '#4b5563' : '#d1d5db')}"
        stroke-width="2"
        stroke-linecap="round"
      />
    `;
  }

  return `
    <div style="
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
      width: auto;
      box-sizing: border-box;
      text-align: center;
      position: relative;
      padding: 0 2px;
    " data-metric="${label.toLowerCase()}">
      <div style="
        position: relative;
        width: ${dimensions.containerWidth};
        height: ${dimensions.containerHeight};
        display: flex;
        justify-content: center;
        align-items: center;
      ">
        <svg viewBox="${dimensions.viewBox}" style="
          position: absolute;
          overflow: visible;
          width: 100%;
          height: 100%;
          top: 0;
          transform: rotate(180deg);
        ">
          ${dashes}
        </svg>
        <div style="
          position: absolute;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
          top: 0;
          z-index: 1;
        ">
          <span style="
            font-size: ${dimensions.valueSize};
            font-weight: 600;
            color: ${getValueColor(value)};
            text-align: center;
          ">${value}</span>
        </div>
      </div>
      <span style="
        margin-top: 0.25rem;
        font-size: ${dimensions.labelSize};
        color: ${isDarkMode ? '#9ca3af' : '#6b7280'};
      ">${label}</span>
    </div>
  `;
}

function createPromptGoodReview() {
    // If an instance already exists, remove it first
    if (promptGoodReviewInstance && promptGoodReviewInstance.parentNode) {
        promptGoodReviewInstance.parentNode.removeChild(promptGoodReviewInstance);
    }

    // Create the main container
    const reviewPopup = document.createElement("div");
    reviewPopup.id = "prompt-good-review-popup";
    reviewPopup.classList.add("prompt-good-review");
    
    // Store as global instance
    promptGoodReviewInstance = reviewPopup;
  
    // Base styles similar to analysisBox
    const baseStyles = `
      position: fixed;
      z-index: 99999;
      cursor: move;
      user-select: none;
      max-width: 350px;
      width: 96%%;
      overflow: hidden;
      border-radius: 1.2rem;
      font-family: system-ui, -apple-system, sans-serif;
      padding: 10px;
      opacity: 0;
      transition: opacity 0.3s;
      pointer-events: none;
      visibility: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
    `;
  
    // Platform-specific styles (simplified version)
    const platformStyles = {
      default: {
        boxCssLight: `
          ${baseStyles}
          background-color: #ffffff;
          box-shadow: 0 0 15px rgba(0, 173, 255, 0.4);
          border: 1px solid rgba(0, 138, 203, 1);
        `,
        boxCssDark: `
          ${baseStyles}
          background-color: #171717;
          box-shadow: 0 0 15px rgba(0, 173, 255, 0.6);
          border: 1px solid #2E2E2E;
        `,
        closeButtonCssLight: `
          color: #6b7280;
          font-size: 1.5rem;
        `,
        closeButtonCssDark: `
          color: #9ca3af;
          font-size: 1.5rem;
        `
      }
    };
  
    // Add visibility state tracking
    let isPopupVisible = false;
    let isDarkMode = false;
  
    // Update the applyStyles function to handle both dark mode and visibility
    function applyStyles(darkMode) {
      isDarkMode = darkMode;
      const styles = platformStyles.default;
  
      reviewPopup.style.cssText = darkMode ? styles.boxCssDark : styles.boxCssLight;
      reviewPopup.style.opacity = isPopupVisible ? '1' : '0';
      reviewPopup.style.pointerEvents = isPopupVisible ? 'auto' : 'none';
      reviewPopup.style.visibility = isPopupVisible ? 'visible' : 'hidden';
  
      const closeButton = reviewPopup.querySelector("button");
      if (closeButton) {
        closeButton.style.cssText = `
          position: absolute;
          top: 6px;
          right: 6px;
          background: none;
          border: none;
          cursor: pointer;
          padding: 2px;
          line-height: 1;
          ${darkMode ? styles.closeButtonCssDark : styles.closeButtonCssLight}
        `;
      }
    }
  
    // Initialize styles based on current dark mode setting
    chrome.storage.local.get(["darkMode"], (result) => {
      applyStyles(result.darkMode === true);
    });
  
    // Listen for dark mode changes
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && "darkMode" in changes) {
        applyStyles(changes.darkMode.newValue);
      }
    });
  
    // Add close button
    const closeButton = document.createElement("button");
    closeButton.innerHTML = "×";
    closeButton.setAttribute('aria-label', 'Close analysis window');
    closeButton.setAttribute('tabindex', '0');
    closeButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      hideReviewPopup();
    });
    closeButton.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        hideReviewPopup();
      }
    });
    reviewPopup.appendChild(closeButton);
  
    // Dragging functionality
    let isDragging = false;
    let currentX = window.innerWidth - 420;  // Initial X position
    let currentY = window.innerHeight / 2;   // Initial Y position
    let initialX;
    let initialY;
  
    function dragStart(e) {
      if (e.target.tagName === "BUTTON") return;
      isDragging = true;
      
      const rect = reviewPopup.getBoundingClientRect();
      currentX = rect.left;
      currentY = rect.top;
      
      initialX = e.type === "touchstart" ? e.touches[0].clientX - currentX : e.clientX - currentX;
      initialY = e.type === "touchstart" ? e.touches[0].clientY - currentY : e.clientY - currentY;
        
      // Set cursor to grabbing during drag
      reviewPopup.style.cursor = 'grabbing';
    }
  
    function drag(e) {
      if (!isDragging) return;
      e.preventDefault();
      
      if (e.type === "touchmove") {
        currentX = e.touches[0].clientX - initialX;
        currentY = e.touches[0].clientY - initialY;
      } else {
        currentX = e.clientX - initialX;
        currentY = e.clientY - initialY;
      }
  
      // Constrain within window bounds
      const maxX = window.innerWidth - reviewPopup.offsetWidth;
      const maxY = window.innerHeight - reviewPopup.offsetHeight;
      currentX = Math.max(0, Math.min(currentX, maxX));
      currentY = Math.max(0, Math.min(currentY, maxY));
  
      // Apply the new position
      reviewPopup.style.left = `${currentX}px`;
      reviewPopup.style.top = `${currentY}px`;
      reviewPopup.style.transform = 'none';  // Remove transform to avoid conflicts
    }
  
    function dragEnd() {
      isDragging = false;
      reviewPopup.style.cursor = 'move';  // Reset cursor
        
      // Update initial positions to current position
      initialX = currentX;
      initialY = currentY;
    }
  
    reviewPopup.addEventListener("mousedown", dragStart, false);
    reviewPopup.addEventListener("touchstart", dragStart, false);
    document.addEventListener("mousemove", drag, false);
    document.addEventListener("touchmove", drag, false);
    document.addEventListener("mouseup", dragEnd, false);
    document.addEventListener("touchend", dragEnd, false);
  
    // Watch for style changes to update position
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "style" && reviewPopup.style.opacity === "1") {
          const rect = reviewPopup.getBoundingClientRect();
          currentX = rect.left;
          currentY = rect.top;
        }
      });
    });
  
    observer.observe(reviewPopup, { attributes: true, attributeFilter: ['style'] });
  
    // Update the hideReviewPopup function
    function hideReviewPopup() {
      isPopupVisible = false;
      applyStyles(isDarkMode);
    }
  
    // Update the updateContent function
    reviewPopup.updateContent = function(data) {
      if (!data) {
        // console.error("[PromptGoodReview] No data provided");
        return;
      }
      
      // Extract the metrics data from the potentially nested structure
      let metricsData = null;
      
      // Function to deeply find the metrics object
      function findMetricsData(obj) {
        if (!obj || typeof obj !== 'object') return null;
        
        // Check if this object directly has metrics
        if (obj.metrics && typeof obj.metrics === 'object') {
            return obj.metrics;
        }
        
        // If it's data.analysis.metrics
        if (obj.analysis && obj.analysis.metrics) {
            return obj.analysis.metrics;
        }
        
        // If it's data.data.metrics
        if (obj.data && obj.data.metrics) {
            return obj.data.metrics;
        }
        
        // If it's data.analysis.data.metrics
        if (obj.analysis && obj.analysis.data && obj.analysis.data.metrics) {
            return obj.analysis.data.metrics;
        }
        
        // If it's data.data.data.metrics (deeply nested API response)
        if (obj.data && obj.data.data && obj.data.data.metrics) {
            return obj.data.data.metrics;
        }
        
        return null;
      }
      
      // Find the metrics data
      metricsData = findMetricsData(data);
      
      if (!metricsData) {
        // console.error("[PromptGoodReview] No metrics found in data:", data);
        return;
      }
  
      // Clear previous content except close button
      while (reviewPopup.childNodes.length > 1) {
        reviewPopup.removeChild(reviewPopup.lastChild);
      }
  
      // Create metrics container and update content
      const metricsContainer = document.createElement("div");
      metricsContainer.style.cssText = `
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        width: 100%;
        margin-top: 0.5rem;
      `;
  
      // Create metric elements with updated colors based on the image
      const metricData = [
        { name: "Context", value: parseInt(metricsData.Context) || 0, color: "#22C55E" }, // Green
        { name: "Action", value: parseInt(metricsData.Action) || 0, color: "#22C55E" },  // Green  
        { name: "Result", value: parseInt(metricsData.Result) || 0, color: "#EAB308" },  // Yellow
        { name: "Example", value: parseInt(metricsData.Example) || 0, color: "#EF4444" }  // Red
      ];
  
      metricData.forEach(metric => {
        const metricBox = document.createElement("div");
        metricBox.style.cssText = `
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 60px;
        `;
        
        // Use the progress indicator with isDarkMode parameter
        metricBox.innerHTML = createProgressIndicator(
          metric.value,
          10,
          metric.color,
          metric.name,
          isDarkMode
        );
        
        metricsContainer.appendChild(metricBox);
      });
  
      reviewPopup.appendChild(metricsContainer);
      
      // Add feedback message
      const feedbackMessage = document.createElement("div");
      feedbackMessage.textContent = "That's a well-crafted prompt!";
      feedbackMessage.style.cssText = `
        font-size: 1.2rem;
        font-weight: 600;
        color: ${isDarkMode ? '#e5e7eb' : '#1f2937'};
        text-align: center;
        margin: 15px 0;
      `;
      reviewPopup.appendChild(feedbackMessage);
  
      // Add save button
      const saveButtonContainer = document.createElement("div");
      saveButtonContainer.style.cssText = `
        display: flex;
        justify-content: center;
        margin-top: 0.5rem;
        width: 100%;
      `;

      const saveButton = document.createElement("button");
      saveButton.textContent = "Save";
      saveButton.style.cssText = `
        background: #4f7cff;
        color: white;
        border: none;
        border-radius: 6px;
        padding: 8px 20px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 120px;
      `;

      saveButton.addEventListener("mouseover", () => {
        saveButton.style.backgroundColor = isDarkMode ? '#3b6bec' : '#3b68dd';
      });

      saveButton.addEventListener("mouseout", () => {
        saveButton.style.backgroundColor = "#4f7cff";
      });

      saveButton.addEventListener("click", (e) => {
        e.preventDefault();
        
        // Hide the popup
        hideReviewPopup();
        
        // Properly remove the element from DOM after animation
        setTimeout(() => {
          if (reviewPopup.parentNode) {
            reviewPopup.parentNode.removeChild(reviewPopup);
            promptGoodReviewInstance = null; // Reset the global instance
          }
        }, 300);
      });

      saveButtonContainer.appendChild(saveButton);
      reviewPopup.appendChild(saveButtonContainer);
  
      // Make the box visible
      isPopupVisible = true;
      applyStyles(isDarkMode);
      
      // Only position relative to input if it hasn't been dragged yet
      if (!isDragging && initialX === window.innerWidth - 420 && initialY === window.innerHeight / 2) {
          positionUIRelativeToInput(reviewPopup);
      } else {
          // Maintain current position if already dragged
          reviewPopup.style.left = `${currentX}px`;
          reviewPopup.style.top = `${currentY}px`;
      }
    };
  
    // Function to position UI relative to input box 
    function positionUIRelativeToInput(uiElement) {
      const currentURL = window.location.href;
      const platformKey = Object.keys(window.platforms || {}).find((key) =>
        window.platforms[key].urlPattern.test(currentURL)
      );

      if (!platformKey || !window.platforms[platformKey].textAreaSelector) {
        // console.warn("[PromptGoodReview] Cannot determine platform or textAreaSelector for positioning");
        uiElement.style.position = "fixed";
        uiElement.style.bottom = "20px";
        uiElement.style.right = "20px";
        return;
      }

      const inputBox = document.querySelector(window.platforms[platformKey].textAreaSelector);
      if (!inputBox) {
        // console.warn("[PromptGoodReview] Input box not found for positioning");
        uiElement.style.position = "fixed";
        uiElement.style.bottom = "20px";
        uiElement.style.right = "20px";
        return;
      }

      const rect = inputBox.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      const uiWidth = uiElement.offsetWidth || 400;
      const uiHeight = uiElement.offsetHeight || 300;
      const marginTop = 10;
      
      // Position directly below the input box
      uiElement.style.position = "fixed";
      uiElement.style.transform = "none"; // Remove any transform
      uiElement.style.top = `${rect.bottom + marginTop}px`;
      
      // Center horizontally with the input box
      const leftPosition = rect.left + (rect.width / 2) - (uiWidth / 2);
      uiElement.style.left = `${Math.max(10, leftPosition)}px`;
      
      // Ensure it doesn't go off-screen
      const rightEdge = leftPosition + uiWidth;
      if (rightEdge > viewportWidth - 10) {
        uiElement.style.left = `${viewportWidth - uiWidth - 10}px`;
      }
      
      // If it would go below the viewport, position it above the input instead
      const viewportHeight = window.innerHeight;
      if (rect.bottom + marginTop + uiHeight > viewportHeight) {
        uiElement.style.top = `${rect.top - uiHeight - marginTop}px`;
      }
    }
  
    // Handle window resizing
    window.addEventListener('resize', () => {
      positionUIRelativeToInput(reviewPopup);
    });
    
    // Return the popup
    return reviewPopup;
}

function initPromptGoodReview(data) {
  // Create a new review popup
  const ui = createPromptGoodReview();
  
  // Append to document
  document.body.appendChild(ui);
  
  // Initial positioning
  positionUIRelativeToInputBox(ui, 'right', 20);

  // Update position on window resize or scroll
  window.addEventListener("resize", () => {
    if (ui.style.opacity === "1") {
      positionUIRelativeToInputBox(ui, 'right', 20);
    }
  });
  
  window.addEventListener("scroll", () => {
    if (ui.style.opacity === "1") {
      positionUIRelativeToInputBox(ui, 'right', 20);
    }
  });
  
  ui.show = function(analysisData) {
    const dataToUse = analysisData || data;
    
    if (!dataToUse) {
      // console.warn("[PromptGoodReview] No data provided, will query API");
      // Get current platform and prompt from the UI
      const currentURL = window.location.href;
      const platformKey = Object.keys(window.platforms || {}).find((key) =>
          window.platforms[key].urlPattern.test(currentURL)
      );
      
      if (!platformKey) {
          // console.error("[PromptGoodReview] Cannot determine platform");
          ui.updateContent(null);
          return;
      }
      
      const platform = platformKey || "default";
      const chatInputBox = document.querySelector(window.platforms[platformKey].textAreaSelector);
      
      if (!chatInputBox) {
          // console.error("[PromptGoodReview] Cannot find chat input box");
          ui.updateContent(null);
          return;
      }
      
      const promptText = chatInputBox.tagName === "TEXTAREA" 
          ? chatInputBox.value.trim() 
          : chatInputBox.hasAttribute("contenteditable") 
              ? chatInputBox.innerText.trim() 
              : "";
      
      if (!promptText) {
          // console.error("[PromptGoodReview] No prompt text found");
          ui.updateContent(null);
          return;
      }
      
      // Show loading state
      chrome.storage.local.get(["darkMode"], (result) => {
        const darkModeStatus = result.darkMode === true;
        ui.innerHTML = `
          <div style="padding: 20px; text-align: center; color: ${darkModeStatus ? '#e5e7eb' : '#1f2937'};">
            <p>Analyzing prompt...</p>
          </div>
        `;
        ui.style.opacity = "1";
        ui.style.pointerEvents = "auto";
        ui.style.visibility = "visible";
      });
      
      // Query the API
      chrome.runtime.sendMessage(
          {
              action: "promptAnalysis",
              prompt: promptText,
              platform: platform
          },
          (response) => {
              if (response && response.success) {
                  ui.updateContent(response.data);
              } else {
                  // console.error("[PromptGoodReview] API error:", response?.error || "No response");
                  ui.updateContent(null);
              }
          }
      );
      return;
    }
    
    // Update content with provided data
    ui.updateContent(dataToUse);
    // Only position initially if not dragged
    if (ui.style.left === '' || ui.style.top === '') {
        positionUIRelativeToInput(ui);
    }
  };

  ui.close = function() {
      ui.style.opacity = "0";
      ui.style.pointerEvents = "none";
      ui.style.visibility = "hidden";
      
      setTimeout(() => {
          if (ui.parentNode) {
              ui.parentNode.removeChild(ui);
              promptGoodReviewInstance = null;
          }
      }, 300);
  };

  if (data && data.enhancedPrompt) {
    // Send the enhanced prompt for analysis before showing the UI
    chrome.runtime.sendMessage(
      {
        action: "promptAnalysis",
        prompt: data.enhancedPrompt,
        platform: data.platform || "default",
        style: data.style || "Descriptive"
      },
      (response) => {
        if (response && response.success) {
          // Create enhanced data with new analysis
          const enhancedData = {
            ...data,
            analysis: response.data.data
          };
          ui.updateContent(enhancedData);
        } else {
          // console.error("Enhanced prompt analysis error:", response?.error);
          ui.updateContent(data);
        }
      }
    );
  } else {
    ui.updateContent(data);
  }

  return ui;
}

// Helper function to position UI relative to input box
function positionUIRelativeToInputBox(uiElement, alignment = 'right', spacing = 20) {
  const currentURL = window.location.href;
  const platformKey = Object.keys(window.platforms || {}).find((key) =>
    window.platforms[key].urlPattern.test(currentURL)
  );

  if (!platformKey || !window.platforms[platformKey].textAreaSelector) {
    // console.warn("Cannot determine platform or textAreaSelector for positioning UI");
    uiElement.style.position = "fixed";
    uiElement.style.bottom = "20px";
    uiElement.style.right = "20px";
    return;
  }

  const inputBox = document.querySelector(window.platforms[platformKey].textAreaSelector);
  if (!inputBox) {
    // console.warn("Input box not found for positioning UI");
    uiElement.style.position = "fixed";
    uiElement.style.bottom = "20px";
    uiElement.style.right = "20px";
    return;
  }

  const rect = inputBox.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const uiWidth = uiElement.offsetWidth || 400;
  const uiHeight = uiElement.offsetHeight || 300;

  // Always ensure the UI is positioned as "fixed" to maintain correct positioning
  uiElement.style.position = "fixed";

  // Reset any transform to avoid interfering with positioning
  uiElement.style.transform = "none";

  // Determine horizontal positioning based on alignment parameter
  if (alignment === 'right') {
    // Position to the right of the input box with spacing
    uiElement.style.left = `${rect.right + spacing}px`;
    
    // Ensure it doesn't go off-screen horizontally
    if (rect.right + spacing + uiWidth > viewportWidth) {
      uiElement.style.left = `${rect.left - uiWidth - spacing}px`;
      
      // If still off-screen on the left, position at the edge
      if (rect.left - uiWidth - spacing < 0) {
        uiElement.style.left = "0px";
      }
    }
  } else if (alignment === 'left') {
    // Position to the left of the input box with spacing
    uiElement.style.left = `${rect.left - uiWidth - spacing}px`;
    
    // If off-screen on the left, position to the right
    if (rect.left - uiWidth - spacing < 0) {
      uiElement.style.left = `${rect.right + spacing}px`;
      
      // If still off-screen on the right, position at the edge
      if (rect.right + spacing + uiWidth > viewportWidth) {
        uiElement.style.left = `${viewportWidth - uiWidth}px`;
      }
    }
  } else {
    // Center horizontally under the input box
    const leftPosition = rect.left + (rect.width / 2) - (uiWidth / 2);
    uiElement.style.left = `${Math.max(0, leftPosition)}px`;
    
    // Ensure it doesn't overflow the right edge
    if (leftPosition + uiWidth > viewportWidth) {
      uiElement.style.left = `${viewportWidth - uiWidth}px`;
    }
  }

  // Align the UI bottom with the input box bottom
  uiElement.style.top = `${rect.bottom - uiHeight}px`;

  // If this positioning would put the UI above the viewport, align top with input top
  if (rect.bottom - uiHeight < 0) {
    uiElement.style.top = `${rect.top}px`;
  }

  // If the UI overflows the bottom of the viewport, position it to fit
  const viewportHeight = window.innerHeight;
  if (parseFloat(uiElement.style.top) + uiHeight > viewportHeight) {
    uiElement.style.top = `${viewportHeight - uiHeight}px`;
  }
}

// Ensure the global function is only defined once
window.initPromptGoodReview = initPromptGoodReview;