// content.js
// Check Auth State
(function () {
  if (window.location.hostname.includes("thinkvelocity.in")) {
    function sendUserData() {
      const token = localStorage.getItem("token");
      const userName = localStorage.getItem("userName");
      const userId = localStorage.getItem("userId");
      const userEmail = localStorage.getItem("userEmail");

      if (token && userName && userId && userEmail) {
        chrome.runtime.sendMessage(
          { action: "storeUserData", token, userName, userId, userEmail },
          (response) => {
            checkAuthAndInjectButton();
          }
        );
        chrome.storage.local.set({ enabled: true });
      }

      if (!token && !userName && !userId && !userEmail) {
        chrome.storage.local.remove(
          ["token", "userName", "userId", "userEmail"],
          () => {}
        );
        chrome.storage.local.set({ enabled: false });
      }
    }
    sendUserData();
    window.addEventListener("storage", sendUserData);

    const documentObserver = new MutationObserver(() => {
      sendUserData();
    });
    documentObserver.observe(document.body, { childList: true, subtree: true });
  }
})();

// Function to inject the button only if authenticated and enabled
function checkAuthAndInjectButton() {
  chrome.storage.local.get(
    ["enabled", "token", "userName", "userId", "userEmail"],
    (data) => {
      if (
        data.enabled &&
        data.token &&
        data.userName &&
        data.userId &&
        data.userEmail
      ) {
        injectButton();
      } else {
        removeButton();
      }
    }
  );
}

function injectButton() {
  if (!window.platforms) {
    return;
  }

  chrome.storage.local.get("enabled", ({ enabled }) => {
    if (!enabled) return;
    
    const currentURL = window.location.href;
    // Only support these platforms
    const supportedPlatforms = ["chatgpt", "claude", "gemini", "perplexity", "grok"];
    
    let platformKey = Object.keys(window.platforms).find((key) =>
      supportedPlatforms.includes(key) && window.platforms[key].urlPattern.test(currentURL)
    );

    if (!platformKey) {
      return;
    }

    // Special handling for ChatGPT
    if (platformKey === "chatgpt") {
      injectChatGPTButton(window.platforms[platformKey]);
      return;
    }

    const config = window.platforms[platformKey];
    const inputBox = document.querySelector(config.textAreaSelector);
    if (inputBox) {
      window.currentInputBox = inputBox;
    } else {
      const observer = new MutationObserver(() => {
        const delayedInputBox = document.querySelector(config.textAreaSelector);
        if (delayedInputBox) {
          window.currentInputBox = delayedInputBox;
          observer.disconnect();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    
    const flexContainer = findButtonContainer(config);
    if (!flexContainer) {
      if (platformKey === "perplexity") {
        const existingButton = document.querySelector(config.existingButtonSelector);
        if (existingButton) {
          const potentialContainer = existingButton.closest('div[class*="flex"]');
          if (potentialContainer) {
            injectButtonForPerplexity(potentialContainer);
            return;
          }
        }
      }
      return;
    }

    const existingButtonContainer = flexContainer.querySelector(".custom-injected-button");
    if (existingButtonContainer) {
      return;
    }

    const button = createCustomButton();

    if (platformKey === "chatgpt") {
      button.style.order = "9999";
      flexContainer.style.display = "flex";
      flexContainer.style.gap = "5px";
      flexContainer.style.justifyContent = "center";
      flexContainer.style.alignItems = "center";
      flexContainer.appendChild(button);
    } else if (platformKey === "claude") {
      flexContainer.appendChild(button);
    } else if (platformKey === "gemini") {
      button.style.border = "none";
      button.style.outline = "none";
      button.style.boxShadow = "none";
      flexContainer.appendChild(button);
    } else if (platformKey === "grok") {
      button.style.order = "9999";
      button.style.marginLeft = "8px";
      button.style.display = "inline-flex";
      button.style.alignItems = "center";
      button.style.height = "36px";
      flexContainer.style.display = "flex";
      flexContainer.appendChild(button);
    } else if (platformKey === "perplexity") {
      const submitButtonContainer = document.querySelector("div[class*='ml-sm'][class*='flex'][class*='gap']");
      if (submitButtonContainer) {
        button.style.margin = "0 4px 0 0";
        button.style.height = "32px";
        button.style.width = "32px";
        button.style.minWidth = "32px";
        button.style.flexShrink = "0";
        button.style.order = "0";
        button.style.zIndex = "10";
        button.style.position = "relative";
        button.style.cursor = "pointer";
        button.style.pointerEvents = "auto";
        
        const submitButton = submitButtonContainer.querySelector("button[aria-label='Submit']");
        if (submitButton) {
          submitButtonContainer.insertBefore(button, submitButton);
          setTimeout(() => {
            button.style.opacity = "0.9";
            setTimeout(() => {
              button.style.opacity = "1";
            }, 50);
          }, 50);
        } else {
          submitButtonContainer.insertBefore(button, submitButtonContainer.firstChild);
        }
      }
    }

    const messageBox = injectMessageBox();
    flexContainer.style.position = "relative";
    flexContainer.appendChild(messageBox);
  });
}

// New function specifically for ChatGPT button injection
function injectChatGPTButton(config) {
  // Remove existing button if any
  removeButton();
  
  // First try to find the container directly
  let flexContainer = findButtonContainer(config);
  
  if (!flexContainer) {
    // If container not found, set up a more aggressive observer specifically for ChatGPT
    const chatGPTObserver = new MutationObserver((mutations) => {
      // Check for our container after each DOM mutation
      const container = findButtonContainer(config);
      if (container) {
        // If we found it and button isn't already there, inject it
        if (!container.querySelector(".custom-injected-button")) {
          chatGPTObserver.disconnect();
          
          const button = createCustomButton();
          button.style.order = "9999";
          container.style.display = "flex";
          container.style.gap = "5px";
          container.style.justifyContent = "center";
          container.style.alignItems = "center";
          container.appendChild(button);
          
          const messageBox = injectMessageBox();
          container.style.position = "relative";
          container.appendChild(messageBox);
        }
      }
    });
    
    // Observe the entire body for changes
    chatGPTObserver.observe(document.body, { 
      childList: true, 
      subtree: true,
      attributes: true
    });
    
    // Try alternative selectors that might work for ChatGPT
    const alternativeSelectors = [
      'form div[class*="flex"]',
      'form > div > div[class*="flex"]',
      '.flex.flex-col.relative',
      'form .flex.items-center',
      'form div[class*="w-full"] > div[class*="flex"]'
    ];
    
    // Try each alternative selector
    for (const selector of alternativeSelectors) {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        // Check the last few elements as button containers are typically at the bottom
        for (let i = elements.length - 1; i >= Math.max(0, elements.length - 5); i--) {
          const element = elements[i];
          // Look for elements that might be the submit button container
          if (element.querySelector('button[type="submit"]') || 
              element.querySelector('button') ||
              element.querySelector('div[class*="bottom"]')) {
            
            const button = createCustomButton();
            button.style.order = "9999";
            element.style.display = "flex";
            element.style.gap = "5px";
            element.style.justifyContent = "center";
            element.style.alignItems = "center";
            element.appendChild(button);
            
            const messageBox = injectMessageBox();
            element.style.position = "relative";
            element.appendChild(messageBox);
            
            return;
          }
        }
      }
    }
    
    // Set a retry mechanism
    setTimeout(() => {
      const newContainer = findButtonContainer(config);
      if (newContainer && !newContainer.querySelector(".custom-injected-button")) {
        const button = createCustomButton();
        button.style.order = "9999";
        newContainer.style.display = "flex";
        newContainer.style.gap = "5px";
        newContainer.style.justifyContent = "center";
        newContainer.style.alignItems = "center";
        newContainer.appendChild(button);
        
        const messageBox = injectMessageBox();
        newContainer.style.position = "relative";
        newContainer.appendChild(messageBox);
      }
    }, 1500);
    
    return;
  }
  
  // If container was found directly, proceed with normal injection
  const existingButtonContainer = flexContainer.querySelector(".custom-injected-button");
  if (existingButtonContainer) {
    return;
  }

  const button = createCustomButton();
  button.style.order = "9999";
  flexContainer.style.display = "flex";
  flexContainer.style.gap = "5px";
  flexContainer.style.justifyContent = "center";
  flexContainer.style.alignItems = "center";
  flexContainer.appendChild(button);
  
  const messageBox = injectMessageBox();
  flexContainer.style.position = "relative";
  flexContainer.appendChild(messageBox);
}

function injectButtonForPerplexity(container) {
  const existingButtonContainer = container.querySelector(".custom-injected-button");
  if (existingButtonContainer) {
    return;
  }

  const button = createCustomButton();
  button.style.order = "9999";
  button.style.marginLeft = "8px";
  button.style.display = "inline-flex";
  button.style.alignItems = "center"; 
  button.style.height = "36px";
  container.style.display = "flex";
  container.appendChild(button);

  const messageBox = injectMessageBox();
  container.style.position = "relative";
  container.appendChild(messageBox);
}

function createCustomButton() {
  (function injectRotationCSS() {
    if (!document.getElementById("rotation-style")) {
      const style = document.createElement("style");
      style.id = "rotation-style";
      style.innerHTML = `
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        .rotating {
          animation: spin 1s linear infinite;
        }
      `;
      document.head.appendChild(style);
    }
  })();

  // Load the animation system if available
  if (window.velocityAnimations) {
    window.velocityAnimations.injectAnimationStyles();
  }

  if (!document.getElementById("pop-animation-style")) {
    const popStyle = document.createElement("style");
    popStyle.id = "pop-animation-style";
    popStyle.innerHTML = `
      @keyframes textPop {
        0% { text-shadow: none; }
        50% { text-shadow: 0 0 10px rgba(0, 136, 255, 0.8), 
                        0 0 15px rgba(0, 136, 255, 0.6), 
                        0 0 20px rgba(0, 136, 255, 0.4); }
        100% { text-shadow: none; }
      }
      .text-pop-effect {
        animation: textPop 1s ease-in-out;
      }
    `;
    document.head.appendChild(popStyle);
  }

  // Remove any existing hover-box-style if it exists
  const existingHoverStyle = document.getElementById("hover-box-style");
  if (existingHoverStyle) {
    existingHoverStyle.remove();
  }
  
  // Create a style element for the hover box
  const hoverStyle = document.createElement("style");
  hoverStyle.id = "hover-box-style";
  hoverStyle.innerHTML = `
    /* Only make hover boxes visible when explicitly set to opacity 1 */
    .velocity-hover-box {
      visibility: hidden !important;
      opacity: 0 !important;
      z-index: 999999 !important;
      margin-left: 25px !important;
      pointer-events: none !important;
    }
    
    .velocity-hover-box.active {
      visibility: visible !important;
      opacity: 1 !important;
      margin-left: 25px !important;
      pointer-events: auto !important;
    }

    /* Platform-specific adjustments */
    .platform-claude .velocity-hover-box,
    .platform-gemini .velocity-hover-box {
      position: fixed !important;
      z-index: 2147483647 !important; /* Maximum z-index value for these platforms */
    }
  `;
  document.head.appendChild(hoverStyle);

  const buttonContainer = document.createElement("div");
  buttonContainer.style.cssText = `
    position: relative;
    display: inline-block;
    border: none;
    outline: none;
    box-shadow: none;
  `;
  buttonContainer.className = "custom-injected-button";

  const currentURL = window.location.href;
  const supportedPlatforms = ["chatgpt", "claude", "gemini", "perplexity", "grok"];
  
  const platformKey = Object.keys(window.platforms).find((key) =>
    supportedPlatforms.includes(key) && window.platforms[key].urlPattern.test(currentURL)
  );
  
  const platform = platformKey || "default";
  const platformConfig = window.platforms[platformKey] || {};
  
  // Add platform class to body for easier CSS targeting
  document.body.classList.add(`platform-${platform}`);

  const button = document.createElement("button");
  button.style.cssText = `
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 9999px;
    background-color: black;
    height: 36px;
    width: 36px;
    transition: opacity 0.2s;
    border: none;
    outline: none;
    box-shadow: none;
    cursor: pointer;
    pointer-events: auto;
    z-index: 10;
  `;
  
  button.addEventListener("mouseenter", () => (button.style.opacity = "0.7"));
  button.addEventListener("mouseleave", () => (button.style.opacity = "1"));

  const innerDiv = document.createElement("div");
  innerDiv.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    border: none;
    outline: none;
    box-shadow: none;
  `;

  const svgTemplate = (gradientId1, gradientId2) => `
    <svg width="36" height="36" viewBox="0 0 106 106" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g filter="url(#filter0_i_9956_1898)">
        <path d="M90 22.0542C89.5323 23.2563 89.1107 24.4798 88.5869 25.6574C86.616 30.0896 83.8646 33.9401 80.0635 36.9671C79.0667 37.7609 77.9858 38.4501 76.9254 39.1607C74.3277 40.9009 72.0108 42.9341 70.2556 45.565C68.5004 48.1951 67.5573 51.1199 67.1697 54.2438C66.7383 57.7173 66.9767 61.1763 67.4119 64.63C67.4256 64.7399 67.4604 64.8467 67.4997 65.0207C69.227 63.4592 70.9179 61.9304 72.6724 60.3436C72.0767 61.419 71.5083 62.4028 70.9799 63.4088C69.8983 65.4703 68.9999 67.6089 68.3512 69.8521C67.2386 73.7018 65.1329 76.9113 62.2189 79.6215C59.9648 81.7181 57.7971 83.9048 55.8723 86.3205C54.6839 87.8118 53.5842 89.3673 52.9113 91.1739C52.6396 91.9051 52.4806 92.679 52.2603 93.469C52.1249 92.9057 51.9727 92.3447 51.8577 91.7769C51.3793 89.4131 51.2067 87.041 51.7434 84.6612C51.9856 83.585 52.4095 82.5859 53.0248 81.667C54.5144 79.4414 55.2985 76.9441 55.7421 74.3269C56.5436 69.5987 56.1924 64.9276 55.0261 60.2971C54.4818 58.1363 54.086 55.9481 54.033 53.7103C53.9263 49.182 55.5937 45.3818 58.7068 42.1785C61.0086 39.8102 63.6774 37.9319 66.599 36.4565C69.8885 34.7949 73.2491 33.2738 76.5863 31.7099C78.7018 30.7185 80.8227 29.7431 82.8193 28.5158C85.4238 26.9137 87.6287 24.8652 89.5187 22.461C89.6405 22.3061 89.7654 22.1534 89.8888 22C89.9251 22.0183 89.9622 22.0366 89.9985 22.055L90 22.0542Z" fill="url(#${gradientId1})"/>
      </g>
      <g filter="url(#filter1_i_9956_1898)">
        <path d="M54.5564 68.5584C53.2583 68.205 51.9451 67.8974 50.6644 67.4891C47.5725 66.503 44.7114 65.0643 42.1887 62.9761C40.3138 61.4244 38.9635 59.4644 37.7442 57.3808C35.9503 54.3156 34.183 51.2314 32.2703 48.2425C29.198 43.4417 25.4733 39.234 20.6405 36.149C19.2713 35.2751 17.7931 34.5737 16.3648 33.7951C16.2437 33.7295 16.1166 33.6746 16 33.5456C16.3739 33.5723 16.7486 33.5921 17.1217 33.6265C22.2172 34.0951 27.2483 34.895 32.1295 36.5062C36.9184 38.0868 40.8316 40.8772 43.7993 44.9949C45.4562 47.2938 46.7354 49.8018 47.6936 52.4655C48.7464 55.3918 49.7107 58.3508 50.7356 61.287C51.4743 63.402 52.3213 65.4696 53.6587 67.2884C53.9501 67.6845 54.2763 68.0554 54.5867 68.4378C54.5768 68.4783 54.567 68.518 54.5564 68.5584Z" fill="url(#${gradientId2})"/>
      </g>
      <defs>
        <filter id="filter0_i_9956_1898" x="51.4124" y="22" width="38.5876" height="73.469" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
          <feFlood flood-opacity="0" result="BackgroundImageFix"/>
          <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
          <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
          <feOffset dy="2"/>
          <feGaussianBlur stdDeviation="1"/>
          <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
          <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
          <feBlend mode="normal" in2="shape" result="effect1_innerShadow_9956_1898"/>
        </filter>
        <filter id="filter1_i_9956_1898" x="16" y="33.5456" width="38.5867" height="37.0128" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
          <feFlood flood-opacity="0" result="BackgroundImageFix"/>
          <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
          <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
          <feOffset dy="2"/>
          <feGaussianBlur stdDeviation="1"/>
          <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
          <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
          <feBlend mode="normal" in2="shape" result="effect1_innerShadow_9956_1898"/>
        </filter>
        <linearGradient id="${gradientId1}" x1="61.3201" y1="19" x2="98.2666" y2="93.4949" gradientUnits="userSpaceOnUse">
          <stop stop-color="#008ACB"/>
          <stop offset="1" stop-color="#004565"/>
        </linearGradient>
        <linearGradient id="${gradientId2}" x1="25.9074" y1="32.0759" x2="36.3402" y2="75.0132" gradientUnits="userSpaceOnUse">
          <stop stop-color="#008ACB"/>
          <stop offset="1" stop-color="#004565"/>
        </linearGradient>
      </defs>
    </svg>
  `;

  function updateSVGColors(isDarkMode) {
    const gradientId1 = `paint0_linear_9956_1898_${isDarkMode ? "dark" : "light"}`;
    const gradientId2 = `paint1_linear_9956_1898_${isDarkMode ? "dark" : "light"}`;
    let svg = svgTemplate(gradientId1, gradientId2);

    if (isDarkMode) {
      svg = svg
        .replace(/stop-color="#008ACB"/g, `stop-color="#FFFFFF"`)
        .replace(/stop-color="#004565"/g, `stop-color="#CCCCCC"`);
    }
    innerDiv.innerHTML = svg;
  }

  chrome.storage.local.get(["darkMode"], (result) => {
    updateSVGColors(result.darkMode === true);
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (area === "local" && "darkMode" in changes) {
      updateSVGColors(changes.darkMode.newValue);
    }
  });

  button.appendChild(innerDiv);

  if (!platformConfig.textAreaSelector) {
    return;
  }

  const hoverBox = window.createHoverBox(platform);
  // Add class for easier selection
  hoverBox.classList.add("velocity-hover-box");
  
  const loadingBox = createLoadingBox();
  
  let reviewUI = null;
  const getAnalysisUI = () => {
    if (reviewUI && reviewUI.parentNode) {
      reviewUI.parentNode.removeChild(reviewUI);
    }
    reviewUI = window.initAnalysisUI ? window.initAnalysisUI() : null;
    if (!reviewUI) {
      // Fallback handling if initAnalysisUI is not available
    }
    return reviewUI;
  };

  let selectedStyle = "Descriptive";
  hoverBox.addEventListener("styleSelected", (event) => {
    selectedStyle = event.detail.selectedStyle;
  });

  button.addEventListener("click", (event) => {
    if (!selectedStyle) {
      selectedStyle = "Descriptive";
    }

    const existingGoodReview = document.getElementById("prompt-good-review-popup");
    if (existingGoodReview) {
      existingGoodReview.style.opacity = "0";
      existingGoodReview.style.pointerEvents = "none";
      setTimeout(() => {
        if (existingGoodReview.parentNode) {
          existingGoodReview.parentNode.removeChild(existingGoodReview);
        }
      }, 300);
    }

    // Stop any ongoing shake animations or idle timers
    button.classList.remove('velocity-shake');
    // Use the new function to disable idle shake if available
    if (window.velocityAnimations && window.velocityAnimations.temporarilyDisableIdleShake) {
      window.velocityAnimations.temporarilyDisableIdleShake(60000); // Disable for 1 minute
    }
    
    // Clear any existing message boxes
    const existingMessages = document.querySelectorAll('.velocity-message-box');
    existingMessages.forEach(msg => {
      if (msg.parentNode) {
        msg.parentNode.removeChild(msg);
      }
    });

    let chatInputBox = document.querySelector(platformConfig.textAreaSelector);
    if (!chatInputBox) {
      return;
    }
    
    const userPrompt = chatInputBox.tagName === "TEXTAREA"
      ? chatInputBox.value.trim()
      : chatInputBox.hasAttribute("contenteditable")
      ? chatInputBox.innerText.trim()
      : "";

    // If prompt is empty, show a popup message instead of rotating
    if (!userPrompt) {
      // Don't add the rotating class
      // Create a popup message
      if (window.velocityAnimations && window.velocityAnimations.createMessageBox) {
        const msgBox = window.velocityAnimations.createMessageBox(
          'Please enter some text before enhancing!', 
          'warning', 
          button
        );
        
        // Auto-hide message after 3 seconds
        setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
          }
        }, 3000);
      }
      return;
    }

    // Only start rotation if there's content
    innerDiv.classList.add("rotating");

    event.stopPropagation();
    event.preventDefault();

    const loadingMessages = [
      `Enhancing your prompt to match your needs...`,
      `Crafting the perfect prompt for ${platform}...`,
      `Working my magic on your prompt...`,
      `Transforming your prompt with ${selectedStyle} style...`,
      `Adding a touch of Velocity to your writing...`,
      `Optimizing your prompt for better results...`,
      `Crafting your enhanced prompt...`,
      `Making your prompt more impactful...`,
    ];

    // Start loading message immediately without initial message to avoid flash
    let loadingHandler = null;
    if (window.velocityAnimations && window.velocityAnimations.showLoadingMessage) {
      loadingHandler = window.velocityAnimations.showLoadingMessage(button, loadingMessages);
      
      // Store the loading handler on the button for position updates
      button.loadingMessageHandler = loadingHandler;
    }

    chrome.runtime.sendMessage(
      {
        action: "streamEnhancePrompt",
        prompt: userPrompt,
        style: selectedStyle,
        platform: platform,
        tabId: chrome.runtime.tab ? chrome.runtime.tab.id : null
      },
      (initialResponse) => {
        if (chrome.runtime.lastError || !initialResponse || !initialResponse.success) {
          if (loadingHandler) {
            loadingHandler.clear();
          }
          innerDiv.classList.remove("rotating");
          return;
        }
      }
    );

    let analysisResponse = null;
    chrome.runtime.sendMessage(
      {
        action: "promptAnalysis",
        prompt: userPrompt,
        style: selectedStyle,
        platform: platform,
      },
      (response) => {
        analysisResponse = response;
      }
    );

    let accumulatedText = "";
    const streamChunkListener = (message, sender, sendResponse) => {
      if (message.action === "streamChunk") {
        let chunkContent = message.chunk;
        if (
          typeof chunkContent === "string" &&
          chunkContent.trim().startsWith("{") &&
          chunkContent.includes('"enhanced_prompt"')
        ) {
          try {
            const parsedChunk = JSON.parse(chunkContent);
            if (parsedChunk.enhanced_prompt) chunkContent = parsedChunk.enhanced_prompt;
          } catch (e) {}
        }

        if (message.isFirst) {
          accumulatedText = chunkContent;
        } else {
          accumulatedText += chunkContent;
        }

        if (chatInputBox.tagName === "TEXTAREA") {
          chatInputBox.value = accumulatedText;
          chatInputBox.dispatchEvent(new Event("input", { bubbles: true }));
        } else if (chatInputBox.hasAttribute("contenteditable")) {
          chatInputBox.innerText = accumulatedText;
          chatInputBox.dispatchEvent(new Event("input", { bubbles: true }));
        }

        if (message.isComplete) {
          if (loadingHandler) {
            loadingHandler.clear();
          }
          
          // Clear loading message handler
          if (button.loadingMessageHandler) {
            button.loadingMessageHandler.clear();
            button.loadingMessageHandler = null;
          }
          
          innerDiv.classList.remove("rotating");

          chatInputBox.classList.add("text-pop-effect");
          setTimeout(() => {
            chatInputBox.classList.remove("text-pop-effect");
          }, 700);
          
          // Add success animation
          if (window.markPromptSuccess) {
            window.markPromptSuccess();
          }

          // Function to show review UI with retries
          const showReviewUIWithRetry = (retries = 3, delay = 500) => {
            if (!analysisResponse || !analysisResponse.success) {
              if (retries > 0) {
                setTimeout(() => showReviewUIWithRetry(retries - 1, delay * 2), delay);
              } else {
                console.error("Analysis response not available after retries");
              }
              return;
            }

            reviewUI = getAnalysisUI();
            if (!reviewUI) {
              if (retries > 0) {
                setTimeout(() => showReviewUIWithRetry(retries - 1, delay * 2), delay);
              } else {
                console.error("Failed to initialize review UI after retries");
              }
              return;
            }

            const analysisData = {
              analysis: analysisResponse.data.data,
              originalPrompt: userPrompt,
              streamEnhancedPrompt: accumulatedText,
              platform: platform,
              style: selectedStyle,
            };

            const enhancedPromptData = {
              contextSuggestions:
                message.contextSuggestions ||
                analysisResponse.data.data.context_suggestions ||
                analysisResponse.data.data.Context_suggestions ||
                [],
              conversationId:
                message.conversationId ||
                analysisResponse.data.data.conversation_id ||
                null,
            };

            document.body.appendChild(reviewUI); // Append to body instead of buttonContainer
            reviewUI.show(analysisData, enhancedPromptData);

            // Ensure visibility
            reviewUI.style.opacity = "1";
            reviewUI.style.pointerEvents = "auto";
            reviewUI.style.visibility = "visible";
          };

          // Start the retry mechanism
          showReviewUIWithRetry();
          chrome.runtime.onMessage.removeListener(streamChunkListener);
        }
      }
      if (sendResponse) sendResponse({ received: true });
      return true;
    };

    chrome.runtime.onMessage.addListener(streamChunkListener);
  });

  buttonContainer.appendChild(hoverBox);
  buttonContainer.appendChild(loadingBox);
  buttonContainer.appendChild(button);

  let hideTimeout;
  button.addEventListener("mouseenter", () => {
    button.style.opacity = "0.7";
    
    // Calculate position for the hover box
    const rect = button.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const hoverBoxWidth = 240; // Approximate width of hover box
    
    // For ChatGPT, Grok, Claude and Gemini, position the hover box absolutely in the viewport
    if (platform === "chatgpt" || platform === "grok" || platform === "claude" || platform === "gemini") {
      // Calculate the best position based on available space
      
      // Check if there's room above
      if (rect.top > 120) {
        // Position above the button
        hoverBox.style.position = "fixed";
        hoverBox.style.left = `${Math.max(10, Math.min(viewportWidth - hoverBoxWidth - 10, rect.left + (rect.width / 2) - (hoverBoxWidth / 2)))}px`;
        hoverBox.style.bottom = `${window.innerHeight - rect.top + 10}px`;
        hoverBox.style.top = "auto";
        hoverBox.style.right = "auto";
        hoverBox.style.marginLeft = "0";
      }
      // Check if there's room to the left
      else if (rect.left > hoverBoxWidth + 20) {
        // Position to the left of the button
        hoverBox.style.position = "fixed";
        hoverBox.style.right = `${window.innerWidth - rect.left + 10}px`;
        hoverBox.style.top = `${rect.top - 10}px`;
        hoverBox.style.left = "auto";
        hoverBox.style.bottom = "auto";
        hoverBox.style.marginLeft = "0";
      }
      // Check if there's room to the right
      else if (viewportWidth - rect.right > hoverBoxWidth + 20) {
        // Position to the right of the button
        hoverBox.style.position = "fixed";
        hoverBox.style.left = `${rect.right + 10}px`;
        hoverBox.style.top = `${rect.top - 10}px`;
        hoverBox.style.right = "auto";
        hoverBox.style.bottom = "auto";
        hoverBox.style.marginLeft = "0";
      }
      // Default to below the button
      else {
        // Position below the button
        hoverBox.style.position = "fixed";
        hoverBox.style.left = `${Math.max(10, Math.min(viewportWidth - hoverBoxWidth - 10, rect.left + (rect.width / 2) - (hoverBoxWidth / 2)))}px`;
        hoverBox.style.top = `${rect.bottom + 10}px`;
        hoverBox.style.right = "auto";
        hoverBox.style.bottom = "auto";
        hoverBox.style.marginLeft = "0";
      }
    } else {
      // For other platforms, use the default relative positioning with improvements
      
      // Check for the best position
      if (rect.right + hoverBoxWidth + 20 < viewportWidth) {
        // Position to the right
        hoverBox.style.position = "absolute";
        hoverBox.style.left = "100%";
        hoverBox.style.top = "0";
        hoverBox.style.marginLeft = "10px";
      } else if (rect.left - hoverBoxWidth - 20 > 0) {
        // Position to the left
        hoverBox.style.position = "absolute";
        hoverBox.style.right = "100%";
        hoverBox.style.top = "0";
        hoverBox.style.left = "auto";
        hoverBox.style.marginRight = "10px";
        hoverBox.style.marginLeft = "0";
      } else if (rect.top > 120) {
        // Position above
        hoverBox.style.position = "absolute";
        hoverBox.style.bottom = "100%";
        hoverBox.style.left = "50%";
        hoverBox.style.top = "auto";
        hoverBox.style.transform = "translateX(-50%)";
        hoverBox.style.marginBottom = "10px";
        hoverBox.style.marginLeft = "0";
      } else {
        // Position below
        hoverBox.style.position = "absolute";
        hoverBox.style.top = "100%";
        hoverBox.style.left = "50%";
        hoverBox.style.transform = "translateX(-50%)";
        hoverBox.style.marginTop = "10px";
        hoverBox.style.marginLeft = "0";
      }
    }
    
    // Show the hover box
    hoverBox.style.opacity = "1";
    hoverBox.style.visibility = "visible";
    hoverBox.style.pointerEvents = "auto";
    hoverBox.classList.add("active");
    hoverBox.style.zIndex = "9999999";
    hoverBox.style.transform = hoverBox.style.transform ? hoverBox.style.transform + " translateZ(0)" : "translateZ(0)";
    
    // Create a DOM observer to maintain hover box position when scrolling/resizing
    if (platform === "chatgpt" || platform === "grok" || platform === "claude" || platform === "gemini") {
      const observer = new MutationObserver(() => {
        if (hoverBox.style.opacity !== "0" && hoverBox.style.pointerEvents !== "none") {
          const updatedRect = button.getBoundingClientRect();
          
          // Recalculate position using the same logic as above to maintain consistency
          if (hoverBox.style.bottom !== "auto") {
            // If it was positioned above
            hoverBox.style.left = `${Math.max(10, Math.min(viewportWidth - hoverBoxWidth - 10, updatedRect.left + (updatedRect.width / 2) - (hoverBoxWidth / 2)))}px`;
            hoverBox.style.bottom = `${window.innerHeight - updatedRect.top + 10}px`;
          } else if (hoverBox.style.right !== "auto") {
            // If it was positioned to the left
            hoverBox.style.right = `${window.innerWidth - updatedRect.left + 10}px`;
            hoverBox.style.top = `${updatedRect.top - 10}px`;
          } else if (parseFloat(hoverBox.style.left) > updatedRect.right) {
            // If it was positioned to the right
            hoverBox.style.left = `${updatedRect.right + 10}px`;
            hoverBox.style.top = `${updatedRect.top - 10}px`;
          } else {
            // If it was positioned below
            hoverBox.style.left = `${Math.max(10, Math.min(viewportWidth - hoverBoxWidth - 10, updatedRect.left + (updatedRect.width / 2) - (hoverBoxWidth / 2)))}px`;
            hoverBox.style.top = `${updatedRect.bottom + 10}px`;
          }
        }
      });
      
      observer.observe(document.body, { 
        childList: true, 
        subtree: true,
        attributes: true
      });
      
      // Disconnect observer after hide timeout
      hideTimeout = setTimeout(() => {
        if (!hoverBox.matches(":hover")) {
          hoverBox.style.opacity = "0";
          hoverBox.style.visibility = "hidden";
          hoverBox.style.pointerEvents = "none";
          hoverBox.classList.remove("active");
          observer.disconnect();
        }
      }, 3000);
    } else {
      // Original timeout behavior for other platforms
      hideTimeout = setTimeout(() => {
        if (!hoverBox.matches(":hover")) {
          hoverBox.style.opacity = "0";
          hoverBox.style.visibility = "hidden";
          hoverBox.style.pointerEvents = "none";
          hoverBox.classList.remove("active");
        }
      }, 3000);
    }
  });
  hoverBox.addEventListener("mouseenter", () => clearTimeout(hideTimeout));
  hoverBox.addEventListener("mouseleave", () => {
    hoverBox.style.transition = "opacity 0.5s ease";
    hoverBox.style.opacity = "0";
    setTimeout(() => {
        hoverBox.style.visibility = "hidden";
        hoverBox.style.pointerEvents = "none";
        hoverBox.classList.remove("active");
    }, 500);
  });

  // Ensure the hover box is hidden on page load
  setTimeout(() => {
    hoverBox.style.opacity = "0";
    hoverBox.style.visibility = "hidden";
    hoverBox.style.pointerEvents = "none";
    hoverBox.classList.remove("active");
  }, 0);

  // Initialize SVG pulse effect for typing detection
  if (window.velocitySvgPulse) {
    window.velocitySvgPulse.initSvgPulseEffect(platformConfig, innerDiv);
  }

  // Initialize animations for this button with the correct platform config
  if (window.velocityAnimations) {
    window.velocityAnimations.initButtonAnimations(platformConfig);
  }
  
  // Create our own implementation of the markPromptSuccess function
  // This is needed in case the animation module's function has issues
  window.markPromptSuccess = function() {
    // Remove rotating class if it exists
    if (innerDiv) {
      innerDiv.classList.remove("rotating");
      innerDiv.classList.add("velocity-success");
      
      // Add success message via velocityAnimations if available
      if (window.velocityAnimations && window.velocityAnimations.createMessageBox) {
        const msgBox = window.velocityAnimations.createMessageBox('Prompt enhanced successfully!', 'success', button);
        
        setTimeout(() => {
          if (msgBox && msgBox.parentNode) {
            msgBox.parentNode.removeChild(msgBox);
          }
        }, 3000);
      }
      
      // Remove success class after animation completes
      setTimeout(() => {
        innerDiv.classList.remove("velocity-success");
      }, 1000);
    }
  };

  return buttonContainer;
}

function createLoadingBox() {
  // Create a stub element that won't actually be used
  // All messages will be handled by the centralized system
  const loadingBox = document.createElement("div");
  const loadingBoxStyles = {
    light: {
      background: "linear-gradient(to right, #f8f9fa, #ffffff)",
      color: "#333",
      boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    },
    dark: {
      background: "linear-gradient(to right, #444, #555)",
      color: "#fff",
      boxShadow: "0 2px 6px rgba(0,0,0,0.5)",
    },
  };

  function applyLoadingBoxStyles(isDarkMode) {
    // Universal styling that works across all platforms
    loadingBox.style.cssText = `
      position: fixed;
      left: auto;
      right: auto;
      top: auto;
      opacity: 0;
      transition: opacity 0.3s ease;
      z-index: 9999999;
      pointer-events: none;
      min-width: 200px;
      max-width: 300px;
      transform: translateZ(0); 
      border-radius: 8px;
      overflow: hidden;
    `;

    const updateLoadingMessage = (message) => {
      loadingBox.innerHTML = `
        <div style="
          padding: 12px 16px;
          text-align: center;
          font-size: 16px;
          font-weight: 600;
          color: ${isDarkMode ? loadingBoxStyles.dark.color : loadingBoxStyles.light.color};
          background: ${isDarkMode ? loadingBoxStyles.dark.background : loadingBoxStyles.light.background};
          border-radius: 8px;
          box-shadow: ${isDarkMode ? loadingBoxStyles.dark.boxShadow : loadingBoxStyles.light.boxShadow};
          margin: 0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
          line-height: 1.4;
          display: flex;
          align-items: center;
          gap: 8px;
          white-space: normal;
          word-break: break-word;
        ">
          ${message}
        </div>
      `;
    };
    return updateLoadingMessage;
  }

  let updateLoadingMessage;
  chrome.storage.local.get(["darkMode"], (result) => {
    updateLoadingMessage = applyLoadingBoxStyles(result.darkMode === true);
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "darkMode" in changes) {
      updateLoadingMessage = applyLoadingBoxStyles(changes.darkMode.newValue);
    }
  });

  return loadingBox;
}

function findButtonContainer(config) {
  let container = document.querySelector(config.buttonContainerSelector);
  if (container) {
    return container;
  }
  
  const existingButton = document.querySelector(config.existingButtonSelector);
  if (existingButton) {
    container = existingButton.closest('div[class*="flex"]');
    if (container) {
      return container;
    }
    const parent = existingButton.parentNode;
    if (parent) {
      return parent;
    }
  }
  
  // Perplexity-specific handling
  if (config.urlPattern.toString().includes("perplexity")) {
    const submitContainer = document.querySelector("div[class*='ml-sm'][class*='flex'][class*='gap']");
    if (submitContainer) {
      return submitContainer;
    }
    
    const submitButton = document.querySelector("button[aria-label='Submit']");
    if (submitButton) {
      const container = submitButton.parentNode;
      if (container) {
        return container;
      }
    }
    
    const inputArea = document.querySelector(config.textAreaSelector);
    if (inputArea) {
      let parent = inputArea.parentNode;
      let count = 0;
      while (parent && count < 5) {
        const submitBtn = parent.querySelector("button[aria-label='Submit']");
        if (submitBtn) {
          const submitContainer = submitBtn.parentNode;
          return submitContainer;
        }
        parent = parent.parentNode;
        count++;
      }
    }
    
    const inputControls = document.querySelector(".flex.items-center.gap-2");
    if (inputControls) {
      return inputControls;
    }
  }
  
  return null;
}

function removeButton() {
  const existingButton = document.querySelector(".custom-injected-button");
  if (existingButton) {
    existingButton.remove();
  }
}

function observeDOMChanges() {
  let isInjecting = false;
  const observer = new MutationObserver(() => {
    if (isInjecting) return;
    isInjecting = true;
    
    const currentURL = window.location.href;
    // Focus more aggressive observation on ChatGPT
    if (currentURL.includes("chat.openai.com") && !document.querySelector(".custom-injected-button")) {
      // For ChatGPT, don't use the delay to avoid missing opportunities
      injectButton();
    } else if (!document.querySelector(".custom-injected-button")) {
      injectButton();
    }
    
    setTimeout(() => { isInjecting = false; }, 1000);
  });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true });
}

chrome.storage.local.get("enabled", ({ enabled }) => {
  if (enabled) {
    (function () {
      injectButton();
      observeDOMChanges();
    })();
  }
});

chrome.storage.onChanged.addListener((changes) => {
  if (
    changes.enabled ||
    changes.token ||
    changes.userName ||
    changes.userId ||
    changes.userEmail
  ) {
    checkAuthAndInjectButton();
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "toggleButton") {
    if (message.enabled) {
      injectButton();
    } else {
      removeButton();
    }
  }
});

function injectMessageBox() {
  // Create a stub element that won't actually be used
  // All messages will be handled by the centralized system
  const messageBoxPlaceholder = document.createElement("div");
  messageBoxPlaceholder.style.display = "none";
  return messageBoxPlaceholder;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "streamChunk") {
    let chunkContent = message.chunk;
    if (
      typeof chunkContent === "string" &&
      chunkContent.trim().startsWith("{") &&
      chunkContent.includes('"enhanced_prompt"')
    ) {
      try {
        const parsedChunk = JSON.parse(chunkContent);
        if (parsedChunk.enhanced_prompt) {
          chunkContent = parsedChunk.enhanced_prompt;
        }
      } catch (e) {}
    }

    const currentURL = window.location.href;
    const supportedPlatforms = ["chatgpt", "claude", "gemini", "perplexity", "grok"];
    
    let platformKey = Object.keys(window.platforms).find((key) =>
      supportedPlatforms.includes(key) && window.platforms[key].urlPattern.test(currentURL)
    );

    if (!platformKey) {
      return;
    }

    const config = window.platforms[platformKey];
    const chatInputBox = document.querySelector(config.textAreaSelector);

    if (!chatInputBox) {
      return;
    }

    let currentText =
      chatInputBox.tagName === "TEXTAREA"
        ? chatInputBox.value
        : chatInputBox.hasAttribute("contenteditable")
        ? chatInputBox.innerText
        : "";

    if (message.isFirst) {
      currentText = chunkContent;
    } else {
      currentText += chunkContent;
    }

    if (chatInputBox.tagName === "TEXTAREA") {
      chatInputBox.value = currentText;
      chatInputBox.dispatchEvent(new Event("input", { bubbles: true }));
    } else if (chatInputBox.hasAttribute("contenteditable")) {
      chatInputBox.innerText = currentText;
      chatInputBox.dispatchEvent(new Event("input", { bubbles: true }));
    }

    if (message.isComplete) {
      chatInputBox.classList.add("text-pop-effect");
      setTimeout(() => {
        chatInputBox.classList.remove("text-pop-effect");
      }, 700);
    }

    if (sendResponse) {
      sendResponse({ received: true });
    }

    return true;
  }
});

// Helper methods for querySelector with :contains - simple version
(function() {
  if (!Element.prototype.matches) {
    Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
  }
  
  if (!NodeList.prototype.forEach) {
    NodeList.prototype.forEach = Array.prototype.forEach;
  }
})();