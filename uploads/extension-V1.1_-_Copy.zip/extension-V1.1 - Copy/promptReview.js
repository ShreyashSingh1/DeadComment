// promptReview.js - Updated with enhanced context suggestions display and fixed refine prompt functionality

function getLowestMetricAndRecommendation(data) {
  if (!data || !data.analysis || !data.analysis.metrics) {
    return {
      lowestMetric: null,
      lowestRecommendation: null
    };
  }

  const metrics = data.analysis.metrics;
  const metricMapping = {
    Context: {
      key: 'context_improvement',
      defaultRec: "The prompt lacks any background information or situation explanation. Include relevant context."
    },
    Action: {
      key: 'action_improvement',
      defaultRec: "Define a clear action or step required in the prompt."
    },
    Result: {
      key: 'result_improvement',
      defaultRec: "The expected outcome is not defined. Specify what result or outcome is expected."
    },
    Example: {
      key: 'example_improvement',
      defaultRec: "No examples are provided in the prompt. Include relevant examples to clarify."
    }
  };

  const metricValues = Object.entries(metrics).map(([key, value]) => ({
    name: key,
    value: parseInt(value) || 0
  }));

  const lowestMetric = metricValues.reduce((min, current) =>
    current.value < min.value ? current : min,
    metricValues[0]
  );

  if (!lowestMetric) {
    return {
      lowestMetric: null,
      lowestRecommendation: null
    };
  }

  const recommendations = data.analysis.recommendations || {};
  const mapping = metricMapping[lowestMetric.name];
  const lowestRecommendation = recommendations[mapping.key] || mapping.defaultRec;

  return {
    lowestMetric: {
      name: lowestMetric.name,
      value: lowestMetric.value
    },
    lowestRecommendation: lowestRecommendation
  };
}

function createProgressIndicator(value, maxValue, color, label, isDarkMode) {
  const getValueColor = (val) => {
    if (val <= 3) return '#EF4444';
    if (val <= 7) return '#EAB308';
    return '#22C55E';
  };

  const dimensions = {
    numberOfDashes: 24,
    radius: 20,
    center: { x: 35, y: 35 },
    viewBox: "0 0 55 55",
    containerWidth: "4px",
    containerHeight: "24px",
    valueSize: "1rem",
    labelSize: "0.7rem"
  };

  let dashes = '';
  for (let i = 0; i < dimensions.numberOfDashes; i++) {
    const angle = (Math.PI * i) / (dimensions.numberOfDashes - 1);
    const x1 = dimensions.center.x + (dimensions.radius - 4) * Math.cos(angle);
    const y1 = dimensions.center.y + (dimensions.radius - 4) * Math.sin(angle);
    const x2 = dimensions.center.x + dimensions.radius * Math.cos(angle);
    const y2 = dimensions.center.y + dimensions.radius * Math.sin(angle);

    const progress = value / maxValue;
    const isActive = i / (dimensions.numberOfDashes - 1) <= progress;

    dashes += `
      <line
        x1="${x1}"
        y1="${y1}"
        x2="${x2}"
        y2="${y2}"
        stroke="${isActive ? getValueColor(value) : (isDarkMode ? '#4b5563' : '#d1d5db')}"
        stroke-width="2"
        stroke-linecap="round"
      />
    `;
  }

  return `
    <div style="
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
      width: auto;
      box-sizing: border-box;
      text-align: center;
      position: relative;
      padding: 0 2px;
    " data-metric="${label.toLowerCase()}">
      <div style="
        position: relative;
        width: ${dimensions.containerWidth};
        height: ${dimensions.containerHeight};
        display: flex;
        justify-content: center;
        align-items: center;
      ">
        <svg viewBox="${dimensions.viewBox}" style="
          position: absolute;
          overflow: visible;
          width: 100%;
          height: 100%;
          top: 50%;
          transform: translateY(50%) scale(2) rotate(180deg);
        ">
          ${dashes}
        </svg>
      </div>
      <div style="width: 100%; text-align: center; margin-top: 0.25rem;">
        <span style="
          font-size: ${dimensions.valueSize};
          font-weight: 600;
          color: ${getValueColor(value)};
          cursor: pointer;
          padding: 0;
          margin: 0;
        ">${value}</span>
      </div>
      <span style="
        margin-top: 0.25rem;
        font-size: ${dimensions.labelSize};
        color: ${isDarkMode ? '#9ca3af' : '#6b7280'};
      ">${label}</span>
    </div>
  `;
}

function createCategoryHighlight(category, color, isDarkMode) {
  return `
    <div class="category-highlight" data-category="${category.toLowerCase()}" style="
      position: absolute;
      bottom: -8px;
      left: 0;
      width: 100%;
      height: 3px;
      background-color: ${color};
      opacity: 0;
      transition: opacity 0.3s ease;
      z-index: 2;
    "></div>
  `;
}

function createAnalysisUI() {
  const container = document.createElement("div");
  container.className = "analysis-ui-container";
  container.style.cssText = `
    width: 100%;
    max-width: 350px;
    background: white;
    height: fit-content;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0, 173, 255, 0.4);
    border: 1px solid rgba(0, 138, 203, 1);
    font-family: system-ui, -apple-system, sans-serif;
    position: fixed;
    top: 50%;
    left: 50%;
    z-index: 10000;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
    display: flex;
    flex-direction: column;
  `;

  // Store context and dark mode state
  let isDarkMode = false;
  const contextObj = {
    suggestions: [],
    conversationId: null
  };
  
  function updateDarkModeStyles() {
    chrome.storage.local.get(["darkMode"], (result) => {
      isDarkMode = result.darkMode === true;
      if (isDarkMode) {
        container.style.background = "#171717";
        container.style.color = "#e5e7eb";
        container.style.boxShadow = "0 0 15px rgba(0, 173, 255, 0.6)";
        container.style.border = "1px solid #2E2E2E";
        headerBar.style.background = "#171717";
        headerTitle.style.color = "#ffffff";
        closeButton.style.color = "#9ca3af";
        
        tabContainer.style.background = "#2E2E2E";
        refineTab.style.background = "#ffffff";
        refineTab.style.color = "#000000";
        analysisTab.style.background = "transparent";
        analysisTab.style.color = "#9ca3af";
        
        metricsSection.style.background = "#171717";
        metricsSection.style.borderBottomLeftRadius = "12px";
        metricsSection.style.borderBottomRightRadius = "12px";
        metricsIndicatorContainer.style.borderBottom = "1px solid #2E2E2E";
        recommendationsContent.style.background = "#171717";
        recommendationsContent.style.color = "#e5e7eb";
        recommendationsTitle.style.color = "#e5e7eb";
        
        inputSections.querySelectorAll('div').forEach(section => {
          if (section.labelElement) {
            section.labelElement.style.color = '#ffffff';
          }
          if (section.inputElement) {
            section.inputElement.style.color = '#ffffff';
            section.inputElement.style.background = "#2E2E2E";
            section.inputElement.style.borderColor = '#3D3D3D';
          }
        });
      } else {
        container.style.background = "white";
        container.style.color = "#4b5563";
        container.style.boxShadow = "0 0 15px rgba(0, 173, 255, 0.4)";
        container.style.border = "1px solid #D1D5DB";
        headerBar.style.background = "white";
        headerTitle.style.color = "#111827";
        closeButton.style.color = "#6b7280";
        
        tabContainer.style.background = "#f3f4f6";
        refineTab.style.background = "#111827";
        refineTab.style.color = "#ffffff";
        analysisTab.style.background = "transparent";
        analysisTab.style.color = "#6b7280";
        
        metricsSection.style.background = "white";
        metricsSection.style.borderBottomLeftRadius = "12px";
        metricsSection.style.borderBottomRightRadius = "12px";
        metricsIndicatorContainer.style.borderBottom = "1px solid #e5e7eb";
        recommendationsContent.style.background = "white"; 
        recommendationsContent.style.color = "#4b5563";
        recommendationsTitle.style.color = "#4b5563";
        
        inputSections.querySelectorAll('div').forEach(section => {
          if (section.labelElement) {
            section.labelElement.style.color = '#4b5563';
          }
          if (section.inputElement) {
            section.inputElement.style.color = '#4b5563';
            section.inputElement.style.background = '#f9fafb';
            section.inputElement.style.borderColor = '#e5e7eb';
          }
        });
      }
      
      if (container.currentData) {
        container.updateAnalysis(container.currentData);
      }
    });
  }
  
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "darkMode" in changes) {
      updateDarkModeStyles();
    }
  });

  const headerBar = document.createElement("div");
  headerBar.style.cssText = `
    padding: 10px 16px;
    background: white;
    cursor: move;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
  `;
  
  const headerTitle = document.createElement("div");
  headerTitle.textContent = "Improve Accuracy";
  headerTitle.style.cssText = `
    font-size: 16px;
    font-weight: 600;
    color: #111827;
  `;
  
  const closeButton = document.createElement("button");
  closeButton.innerHTML = "×";
  closeButton.style.cssText = `
    background: none;
    border: none;
    font-size: 24px;
    color: #6b7280;
    cursor: pointer;
    line-height: 1;
  `;
  closeButton.addEventListener("click", (e) => {
    e.preventDefault();
    container.style.opacity = "0";
    container.style.pointerEvents = "none";
  });
  
  headerBar.appendChild(headerTitle);
  headerBar.appendChild(closeButton);
  container.appendChild(headerBar);

  const tabContainer = document.createElement("div");
  tabContainer.style.cssText = `
    display: flex;
    justify-content: center;
    align-items: center;
    background: #f3f4f6;
    padding: 4px;
    border-radius: 25px;
    margin: 12px 16px;
    gap: 4px;
  `;
  
  let activeTab = "refine";
  
  const refineTab = document.createElement("div");
  refineTab.textContent = "Refine Prompt";
  refineTab.style.cssText = `
    flex: 1;
    text-align: center;
    padding: 8px 12px;
    border-radius: 25px;
    font-size: 14px;
    font-weight: 500;
    color: #ffffff;
    background: #111827;
    cursor: pointer;
    transition: all 0.3s ease;
  `;
  
  const analysisTab = document.createElement("div");
  analysisTab.textContent = "Analysis";
  analysisTab.style.cssText = `
    flex: 1;
    text-align: center;
    padding: 8px 12px;
    border-radius: 25px;
    font-size: 14px;
    font-weight: 500;
    color: #6b7280;
    background: transparent;
    cursor: pointer;
    transition: all 0.3s ease;
  `;
  
  const contentContainer = document.createElement("div");
  contentContainer.style.cssText = `
    height: auto;
    min-height: 200px;
    position: relative;
    overflow: visible;
  `;
  
  refineTab.addEventListener("click", () => {
    if (activeTab !== "refine") {
      activeTab = "refine";
      if (isDarkMode) {
        refineTab.style.background = "#ffffff";
        refineTab.style.color = "#000000";
      } else {
        refineTab.style.background = "#111827";
        refineTab.style.color = "#ffffff";
      }
      analysisTab.style.background = "transparent";
      analysisTab.style.color = isDarkMode ? "#9ca3af" : "#6b7280";
      
      inputSections.style.display = "flex";
      metricsSection.style.display = "none";
      
      setTimeout(() => ensureScrollingEnabled(container), 50);
    }
  });
  
  analysisTab.addEventListener("click", () => {
    if (activeTab !== "analysis") {
      activeTab = "analysis";
      if (isDarkMode) {
        analysisTab.style.background = "#ffffff";
        analysisTab.style.color = "#000000";
      } else {
        analysisTab.style.background = "#111827";
        analysisTab.style.color = "#ffffff";
      }
      refineTab.style.background = "transparent";
      refineTab.style.color = isDarkMode ? "#9ca3af" : "#6b7280";
      
      inputSections.style.display = "none";
      metricsSection.style.display = "block";
      
      setTimeout(() => ensureScrollingEnabled(container), 50);
    }
  });
  
  tabContainer.appendChild(refineTab);
  tabContainer.appendChild(analysisTab);
  container.appendChild(tabContainer);

  makeDraggable(container, container);

  const metricsSection = document.createElement("div");
  metricsSection.style.cssText = `
    display: none;
    padding-left: 15px;
    padding-right: 15px;
    padding-top: 0px;
    padding-bottom: 10px;
    background: ${isDarkMode ? "#171717" : "white"};
    height: auto;
    box-sizing: border-box;
    overflow: auto;
    border-bottom-left-radius: 12px;
    border-bottom-right-radius: 12px;
  `;
  
  const metricsIndicatorContainer = document.createElement("div");
  metricsIndicatorContainer.style.cssText = `
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: flex-start;
    gap: 5px;
    width: 100%;
    position: relative;
    margin-bottom: 20px;
    margin-top: 10px;
    padding-bottom: 0;
    border-bottom: none;
    background-image: linear-gradient(to right, #00ADFF, #99D6FF);
    background-size: 100% 1px;
    background-position: 0 100%;
    background-repeat: no-repeat;
  `;
  
  const recommendationsTitle = document.createElement("div");
  recommendationsTitle.textContent = "Recommendations";
  recommendationsTitle.style.cssText = `
    font-size: 15px;
    font-weight: 600;
    color: #4b5563;
    margin: 15px 0 0px 0;
    text-align: center;
  `;
  
  const recommendationsContent = document.createElement("div");
  recommendationsContent.style.cssText = `
    font-size: 13px;
    color: ${isDarkMode ? "#e5e7eb" : "#4b5563"};
    background: ${isDarkMode ? "#171717" : "white"};
    padding: 10px ;
    line-height: 1.5;
    text-align: center;
    height: fit-content;
    overflow: hidden;
  `;
  
  metricsSection.appendChild(metricsIndicatorContainer);
  metricsSection.appendChild(recommendationsTitle);
  metricsSection.appendChild(recommendationsContent);
  
  const inputSections = document.createElement("div");
  inputSections.style.cssText = `
    padding-left: 16px;
    padding-right: 16px;
    padding-top: 16px;
    padding-bottom: 16px;
    display: flex;
    flex-direction: column;
    color: #00547B;
    height: auto;
    box-sizing: border-box;
    overflow: visible;
  `;
  
  contentContainer.appendChild(metricsSection);
  contentContainer.appendChild(inputSections);
  container.appendChild(contentContainer);
  
  container.updateAnalysis = (data) => {
    container.currentData = data;
    
    while (metricsIndicatorContainer.firstChild) {
      metricsIndicatorContainer.removeChild(metricsIndicatorContainer.firstChild);
    }
    
    if (data && data.analysis && data.analysis.recommendations) {
      const recommendations = data.analysis.recommendations;
      const recText = recommendations.context_improvement || 
                      recommendations.action_improvement || 
                      recommendations.result_improvement || 
                      recommendations.example_improvement ||
                      "No specific recommendations available.";
                      
      recommendationsContent.textContent = recText;
    } else {
      recommendationsContent.textContent = "No recommendations available.";
    }
    
    if (data && data.analysis && data.analysis.metrics) {
      const metrics = data.analysis.metrics;
      
      const metricData = [
        { value: parseInt(metrics.Context) || 0, label: "Clarity", color: "#F97316" },
        { value: parseInt(metrics.Action) || 0, label: "Completeness", color: "#22C55E" },
        { value: parseInt(metrics.Result) || 0, label: "Effectiveness", color: "#EF4444" },
        { value: parseInt(metrics.Example) || 0, label: "Specificity", color: "#EAB308" }
      ];
      
      metricData.forEach((metric, index) => {
        const indicator = document.createElement("div");
        indicator.style.cssText = `
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 100%;
          position: relative;
          z-index: 1;
          padding-bottom: 4px;
        `;
        indicator.innerHTML = createProgressIndicator(metric.value, 10, metric.color, metric.label, isDarkMode);
        indicator.innerHTML += createCategoryHighlight(metric.label, metric.color, isDarkMode);
        
        const isLowestMetric = metricData.every(m => m.value >= metric.value);
        
        indicator.addEventListener("click", () => {
          const recommendations = data.analysis.recommendations;
          let recommendationText = "No specific recommendation available.";
          
          if (metric.label === "Clarity") {
            recommendationText = recommendations.context_improvement || recommendationText;
          } else if (metric.label === "Completeness") {
            recommendationText = recommendations.action_improvement || recommendationText;
          } else if (metric.label === "Effectiveness") {
            recommendationText = recommendations.result_improvement || recommendationText;
          } else if (metric.label === "Specificity") {
            recommendationText = recommendations.example_improvement || recommendationText;
          }
          
          recommendationsContent.textContent = recommendationText;
          
          metricsIndicatorContainer.querySelectorAll(".category-highlight").forEach(highlight => {
            highlight.style.opacity = "0";
          });
          indicator.querySelector(".category-highlight").style.opacity = "1";
        });
        
        if (isLowestMetric) {
          setTimeout(() => {
            indicator.click();
          }, 100);
        }
        
        metricsIndicatorContainer.appendChild(indicator);
      });
    }
    
    setTimeout(() => ensureScrollingEnabled(container), 50);
  };

  container.updateEnhancedPrompt = (enhancedPromptData) => {
    while (inputSections.firstChild) {
      inputSections.removeChild(inputSections.firstChild);
    }
    
    const defaultPrompts = [
      { label: "Specify the purpose of the mail", placeholder: "Enter the purpose" },
      { label: "Who is the mail addressed to?", placeholder: "Enter recipient" }
    ];
    
    if (enhancedPromptData && enhancedPromptData.contextSuggestions && enhancedPromptData.contextSuggestions.length) {
      const suggestionsToUse = enhancedPromptData.contextSuggestions.slice(0, 2);
      contextObj.suggestions = suggestionsToUse;
      contextObj.conversationId = enhancedPromptData.conversationId;
      
      suggestionsToUse.forEach((suggestion) => {
        createInputField(suggestion, suggestion.toLowerCase());
      });
    } else {
      defaultPrompts.forEach((prompt) => {
        createInputField(prompt.label, prompt.placeholder);
      });
    }
    
    const buttonContainer = document.createElement("div");
    buttonContainer.style.cssText = `
      display: flex;
      justify-content: center;
      // padding-top: 8px;
      position: relative;
      margin-top: auto;
    `;
    
    const button = document.createElement("button");
    button.textContent = "Refine Prompt";
    button.style.cssText = `
      background: #0099e6;
      color: white;
      padding: 10px 24px;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
    `;
    
    button.addEventListener("mouseover", () => {
      button.style.backgroundColor = isDarkMode ? '#0077b3' : '#0088cc';
    });
    
    button.addEventListener("mouseout", () => {
      button.style.backgroundColor = "#0099e6";
    });
    
    button.addEventListener("click", async (e) => {
      e.preventDefault();
      
      container.style.opacity = "0";
      container.style.pointerEvents = "none";
      
      const originalData = container.currentData;
      if (!originalData?.originalPrompt) {
        alert("No original prompt data available.");
        container.style.opacity = "1"; 
        container.style.pointerEvents = "auto";
        return;
      }
      
      const contextValues = [];
      const inputs = inputSections.querySelectorAll('input');
      
      inputs.forEach((input) => {
        if (input.value.trim()) {
          contextValues.push(input.value.trim());
        }
      });
      
      const context = contextValues.join("\n\n");
      
      button.textContent = "Enhancing...";
      button.disabled = true;
      
      try {
        const platform = originalData.platform || "default";
        const selectedStyle = originalData.style || "Descriptive";
        const hasConversationId = contextObj.conversationId !== null;
        
        let enhanceResponse;
        
        if (hasConversationId) {
          enhanceResponse = await new Promise(resolve => chrome.runtime.sendMessage({
            action: "addContext",
            context: context,
            conversationId: contextObj.conversationId,
            style: selectedStyle,
          }, resolve));
        } else {
          const refinedPrompt = `${originalData.originalPrompt}\n\n${context}`;
          enhanceResponse = await new Promise(resolve => chrome.runtime.sendMessage({
            action: "enhancePrompt",
            prompt: refinedPrompt,
            style: selectedStyle,
            platform: platform
          }, resolve));
        }
        
        if (!enhanceResponse || !enhanceResponse.success) {
          throw new Error(enhanceResponse?.error || "Failed to enhance prompt");
        }
        
        const refinedPrompt = hasConversationId 
          ? enhanceResponse.data.data.enhanced_prompt 
          : `${originalData.originalPrompt}\n\n${context}`;
        
        const analysisResponse = await new Promise(resolve => chrome.runtime.sendMessage({
          action: "promptAnalysis",
          prompt: refinedPrompt,
          style: selectedStyle,
          platform: platform
        }, resolve));
        
        if (!analysisResponse || !analysisResponse.success) {
          throw new Error(analysisResponse?.error || "Failed to analyze enhanced prompt");
        }
        
        const currentURL = window.location.href;
        const platformKey = Object.keys(window.platforms || {}).find(key => 
          window.platforms[key].urlPattern.test(currentURL)
        );
        
        if (platformKey && window.platforms[platformKey].textAreaSelector) {
          const chatInputBox = document.querySelector(window.platforms[platformKey].textAreaSelector);
          const enhancedPrompt = enhanceResponse.data.data.enhanced_prompt || refinedPrompt;
          
          if (chatInputBox) {
            if (chatInputBox.tagName === "TEXTAREA") {
              chatInputBox.value = enhancedPrompt;
            } else if (chatInputBox.hasAttribute("contenteditable")) {
              chatInputBox.innerText = enhancedPrompt;
            }
            chatInputBox.dispatchEvent(new Event('input', { bubbles: true }));
            
            chatInputBox.classList.add("text-pop-effect");
            setTimeout(() => {
              chatInputBox.classList.remove("text-pop-effect");
            }, 700);
          }
        }
        
        const goodReviewData = {
          analysis: analysisResponse.data.data,
          originalPrompt: originalData.originalPrompt,  
          enhancedPrompt: enhanceResponse.data.data.enhanced_prompt,
          platform,
          style: selectedStyle
        };
        
        container.style.opacity = "0";
        container.style.pointerEvents = "none";
        
        setTimeout(() => {
          container.remove();
          const goodReviewUI = window.initPromptGoodReview(goodReviewData);
          
          goodReviewUI.style.transform = 'none';
          goodReviewUI.style.position = 'fixed';
          goodReviewUI.style.right = '400px';
          goodReviewUI.style.top = '120px';
          goodReviewUI.style.left = 'auto';
          goodReviewUI.style.opacity = '1';
          goodReviewUI.style.pointerEvents = 'auto';
          goodReviewUI.style.visibility = 'visible';
        }, 300);
        
      } catch (error) {
        alert(`Failed to refine and analyze the prompt: ${error.message || "Unknown error"}. Please try again.`);
        container.style.opacity = "1";
        container.style.pointerEvents = "auto";
      } finally {
        button.textContent = "Fix & Enhance";
        button.disabled = false;
      }
    });
    
    buttonContainer.appendChild(button);
    inputSections.appendChild(buttonContainer);
    
    setTimeout(() => ensureScrollingEnabled(container), 50);
  };
  
  function createInputField(label, placeholder) {
    const section = document.createElement("div");
    const labelElement = document.createElement("p");
    labelElement.textContent = label;
    labelElement.style.cssText = `
      font-size: 14px;
      color: ${isDarkMode ? '#ffffff' : '#4b5563'};
      margin: 0 0 8px 0;
      text-align: left;
      line-height: 1.3;
      min-height: 18px;
    `;
    
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = placeholder;
    input.style.cssText = `
      width: 100%;
      padding: 12px;
      background: ${isDarkMode ? '#374151' : '#f9fafb'};
      border: 1px solid ${isDarkMode ? '#4b5563' : '#e5e7eb'};
      border-radius: 6px;
      font-size: 14px;
      color: ${isDarkMode ? '#ffffff' : '#4b5563'};
      transition: border-color 0.2s ease;
      text-align: left;
      box-sizing: border-box;
    `;
    
    section.style.marginBottom = "16px";
    section.style.display = "flex";
    section.style.flexDirection = "column";
    
    section.labelElement = labelElement;
    section.inputElement = input;
    
    ["mousedown", "mouseup", "click", "focus", "blur", "input", "keydown", "keyup"].forEach(eventType => {
      input.addEventListener(eventType, (e) => {
        e.stopPropagation();
        
        if (eventType === "focus") {
          input.style.borderColor = "#3b82f6";
        } else if (eventType === "blur") {
          input.style.borderColor = isDarkMode ? '#4b5563' : '#e5e7eb';
        }
      }, true);
    });
    
    section.appendChild(labelElement);
    section.appendChild(input);
    inputSections.appendChild(section);
  }
  
  updateDarkModeStyles();
  
  return container;
}

function positionUIRelativeToInputBox(uiElement, alignment = 'right', offset = 20) {
  const currentURL = window.location.href;
  const platformKey = Object.keys(window.platforms || {}).find((key) =>
    window.platforms[key].urlPattern.test(currentURL)
  );

  if (!platformKey || !window.platforms[platformKey].textAreaSelector) {
    rightSidePositioning(uiElement);
    return;
  }

  const inputBox = document.querySelector(window.platforms[platformKey].textAreaSelector);
  if (!inputBox) {
    rightSidePositioning(uiElement);
    return;
  }

  const rect = inputBox.getBoundingClientRect();
  
  const uiWidth = 350;
  const uiMaxHeight = Math.min(600, window.innerHeight - 40);

  uiElement.style.transform = "none";
  uiElement.style.bottom = "auto";
  
  uiElement.style.width = `${uiWidth}px`;
  uiElement.style.maxHeight = `${uiMaxHeight}px`;
  uiElement.style.position = "fixed";
  
  if (alignment === 'left') {
    uiElement.style.left = `${rect.left - uiWidth - offset}px`;
    uiElement.style.right = "auto";
  } else {
    uiElement.style.left = "auto";
    uiElement.style.right = `${offset}px`;
  }
  
  uiElement.style.top = `${Math.max(20, rect.top)}px`;
  
  if (parseFloat(uiElement.style.top) + uiMaxHeight > window.innerHeight - 20) {
    uiElement.style.top = `${Math.max(20, window.innerHeight - uiMaxHeight - 20)}px`;
  }
  
  ensureScrollingEnabled(uiElement);
  
  uiElement.style.zIndex = "10000";
}
function rightSidePositioning(uiElement) {
  const uiWidth = 350;
  const uiMaxHeight = Math.min(600, window.innerHeight - 40);
  
  uiElement.style.position = "fixed";
  uiElement.style.width = `${uiWidth}px`;
  uiElement.style.maxHeight = `${uiMaxHeight}px`;
  uiElement.style.right = "20px";
  uiElement.style.top = "20px";
  uiElement.style.left = "auto";
  uiElement.style.transform = "none";
  uiElement.style.zIndex = "10000";
  
  ensureScrollingEnabled(uiElement);
}
function ensureScrollingEnabled(uiElement) {
  const metricsSection = uiElement.querySelector('div[style*="background: #171717"]') || 
                          uiElement.querySelector('div[style*="background: white"]');
  
  if (metricsSection) {
    metricsSection.style.overflow = "visible";
    metricsSection.style.height = "auto";
  }
  
  const recommendationsContent = uiElement.querySelector('div[style*="line-height: 1.5"]');
  if (recommendationsContent) {
    recommendationsContent.style.overflow = "visible";
    recommendationsContent.style.height = "auto";
  }
  
  const formSection = uiElement.querySelector('div[style*="gap: 12px"]');
  if (formSection) {
    formSection.style.overflow = "visible";
  }
  
  // Update the content container height based on content
  const contentContainer = uiElement.querySelector('div[style*="position: relative"]');
  if (contentContainer) {
    const activeSection = uiElement.querySelector('div[style*="display: block"]') || 
                           uiElement.querySelector('div[style*="display: flex"]');
    
    if (activeSection) {
      contentContainer.style.height = "auto";
    }
  }
}

function makeDraggable(container, dragElement) {
  let isDragging = false;
  let initialX;
  let initialY;
  let currentX = 0;
  let currentY = 0;

  const headerBar = container.querySelector("div[style*='cursor: move']");
  if (!headerBar) return;
  
  headerBar.addEventListener("mousedown", dragStart, false);
  document.addEventListener("mousemove", drag, false);
  document.addEventListener("mouseup", dragEnd, false);

  function dragStart(e) {
    if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;

    initialX = e.clientX - container.offsetLeft;
    initialY = e.clientY - container.offsetTop;

    isDragging = true;
    headerBar.style.cursor = "grabbing";
    e.preventDefault();
  }

  function drag(e) {
    if (!isDragging) return;
    e.preventDefault();

    currentX = e.clientX - initialX;
    currentY = e.clientY - initialY;

    const maxX = window.innerWidth - container.offsetWidth;
    const maxY = window.innerHeight - container.offsetHeight;
    
    currentX = Math.max(0, Math.min(currentX, maxX));
    currentY = Math.max(0, Math.min(currentY, maxY));

    container.style.left = `${currentX}px`;
    container.style.top = `${currentY}px`;
    container.style.right = "auto";
    container.style.bottom = "auto";
    container.style.width = "350px";
    container.style.transform = "none";
  }

  function dragEnd() {
    isDragging = false;
    headerBar.style.cursor = "move";
  }
}

function initAnalysisUI(data) {
  const existingUI = document.querySelector(".analysis-ui-container");
  if (existingUI && existingUI.parentNode) {
    existingUI.parentNode.removeChild(existingUI);
  }

  const ui = createAnalysisUI();
  document.body.appendChild(ui);

  positionUIRelativeToInputBox(ui, 'right', 20);

  const updatePosition = () => {
    if (ui.style.opacity === "1") {
      positionUIRelativeToInputBox(ui, 'right', 20);
    }
  };
  window.addEventListener("resize", updatePosition);
  window.addEventListener("scroll", updatePosition);

  ui.show = (analysisData, enhancedPromptData) => {
    try {
      ui.updateAnalysis(analysisData || data);
      if (enhancedPromptData) {
        ui.updateEnhancedPrompt(enhancedPromptData);
      }
      ui.style.opacity = "1";
      ui.style.pointerEvents = "auto";
      ui.style.display = "flex";
      ui.style.visibility = "visible";
      positionUIRelativeToInputBox(ui, 'right', 20);
    } catch (error) {
    }
  };

  if (data) {
    ui.updateAnalysis(data);
  }

  return ui;
}

window.initAnalysisUI = initAnalysisUI;

